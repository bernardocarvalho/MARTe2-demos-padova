/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/asyn-sub/asyn-sub.cpp $
* $Id: asyn-sub.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-core.h" /* SDN core library - API definition (sdn::core) */
#include "core-subscriber.h"

/* Constants */

#define DEFAULT_AFFINITY       0
#define DEFAULT_ITERATIONS 10000
#define DEFAULT_PAYLOAD        0 /* Undefined */

/* Type definition */

/* Global variables */

uint_t count = DEFAULT_ITERATIONS;
bool _terminate = false;

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core, defaults to 0.\n");
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are received, -1 for undefined number of counts (stops with Ctrl-C), defaults to 10000.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -s|--size <topic_size>: Topic size, defaults to 0 (i.e. undefined and therefore must be derived from topic definition file).\n");
  fprintf(stdout, "         -t|--topic <topic_name>: Topic name, defaults to 'undefined'.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates an asynchronous topic subscriber for <topic_name> which receives packets on <iface_name>, etc.\n");
  fprintf(stdout, "The program expects either that there is a <topic_name>.xml file available at ${SDN_TOPIC_PATH} which defines at least topic size or includes\n");
  fprintf(stdout, "an explicit type definition from which size can be derived; alternatively, it uses the <topic_size> command line attribute.\n");
  fprintf(stdout, "\n");

  return;

};

void Subscriber_CB (sdn::core::SubscriberThread* self)
{

  log_trace("%s - Routine invoked at '%lu'", __FUNCTION__, get_time());

  void* topic = self->GetTopicInstance();
  char* topic_name = self->GetTopicName();
  uint_t topic_size = self->GetTopicSize();

  log_info("%s - Received instance '%p' of topic '%s %u'", __FUNCTION__, topic, topic_name, topic_size);

  /* ToDo - Process topic instance after reception */
  // Anything appropriate for the particular datatype ... e.g.
  log_info("%s - Assuming string content '%s'", __FUNCTION__, (char*) topic);

  if (count > 0) count -= 1;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  char topic_name [STRING_MAX_LENGTH] = DEFAULT_TOPIC_NAME;

  uint_t core = DEFAULT_AFFINITY;
  uint_t size = DEFAULT_PAYLOAD;

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &core);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(topic_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--size") == 0))
	    {
	      /* Get topic payload size */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &size);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      log_info("CCS version is '%s'", version);
    }

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      log_info("Program name is '%s'", prog_name);
    }

  sdn::Metadata mdata; sdn::Topic_InitializeMetadata(mdata, topic_name, size);

  if (sdn::Topic_IsMetadataValid(mdata) != true)
    { 
      /* Display usage */ fprintf(stdout, "Error: Unable to locate '%s' topic definition file, in which case <topic_size> must be provided.\n", topic_name); return (0); 
    }

  /* Create subscriber */
  log_info("Create subscriber for '%s' on '%s'", topic_name, iface_name);
  sdn::core::SubscriberThread sub (mdata); /* When created only with topic name, there must be a <topic_name>.xml file 
					      available at ${SDN_TOPIC_PATH} which defines at least topic size or type 
					      definition from which size can be derived. */

  sub.SetInterface(iface_name); /* Optional - If not called, the instance will also be using ${SDN_INTERFACE_NAME} */

  sub.SetAffinity(core); /* Optional - If not called, the thread will be deployed with default CPU mask */
  sub.SetCallback((void (*)(void*)) &Subscriber_CB, (void*) &sub);
  sub.Launch();

  while ((_terminate != true) && (count > 0))
    {

      wait(1000000000L);

    }

  /* Terminate */
  log_info("Terminate program");
  sub.Terminate();

  return (0);

}
