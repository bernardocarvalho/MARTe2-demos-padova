/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/sdn-echo/sdn-echo.cpp $
* $Id: sdn-echo.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-base.h" /* SDN core library - Base classes definition */
#include "sdn-api.h" /* SDN core library - API definition */

/* Constants */

#define DEFAULT_AFFINITY       0
#define DEFAULT_ITERATIONS 10000
#define DEFAULT_PAYLOAD     1024 /* 1kB */
#define DEFAULT_PERIOD   1000000 /* 1kHz */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core, defaults to %u.\n", DEFAULT_AFFINITY);
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are published, -1 for undefined number of counts (stops with Ctrl-C), defaults to %u.\n", DEFAULT_ITERATIONS);
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -p|--period <period_ns>: Publication period, defaults to 1000000 (1kHz).\n");
  fprintf(stdout, "         -s|--size <payload>: Payload, defaults to 1024 (1kB).\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode, statistics and measurmeent data are printed on stdout.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates a SDN publisher streams <payload> bytes packets on <iface_name> with configurable rate, etc.\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  uint_t core = DEFAULT_AFFINITY;
  uint_t count = DEFAULT_ITERATIONS;
  uint64_t period = DEFAULT_PERIOD;
  uint_t size = DEFAULT_PAYLOAD;

  bool verbose = false; /* Set to true to get measurements on stdout so as to load/plot into e.g. Matlab */

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &core);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc)
		{
		  sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (net_is_interface_valid(iface_name) != true) { /* Display usage */ fprintf(stdout, "Error: Invalid interface '%s'.\n", iface_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-p") == 0) || (strcmp(argv[index], "--period") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &period);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--size") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &size);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  if (set_thread_affinity_to_core(core) != STATUS_SUCCESS)
    {
      log_warning("set_thread_affinity_to_core() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Setting thread affinity to core '%d'\n", core);
      log_info("Setting thread affinity to core '%d'", core);
    }

  /* Create payload */
  if (verbose) fprintf(stdout, "%% Create payload buffer of size '%u'\n", size);
  log_info("Create payload buffer of size '%u'", size);

  sdn::Metadata_t mdata; 

  /* Create subscriber */
  sdn::Topic_InitializeMetadata(mdata, "sdn://239.0.0.1:60001/ping", 0u);

  sdn::Topic ping; ping.SetMetadata(mdata);

  ping.AddAttribute<uint64_t>((uint_t) 0, (char*) "identifier");
  ping.AddAttribute<uint64_t>((uint_t) 1, (char*) "send-time");
  ping.AddAttribute<uint64_t>((uint_t) 2, (char*) "recv-time");
  ping.AddAttribute<uint8_t>((uint_t) 3, (char*) "reserved", size - (3*sizeof(uint64_t)));

  ping.SetUID(0u); ping.Configure();

  if (verbose) fprintf(stdout, "%% Create sdn::Subscriber on '%s'\n", iface_name);
  log_info("Create sdn:Subscriber on '%s'", iface_name);
  sdn::Subscriber* p_sub = new sdn::Subscriber (ping); p_sub->SetInterface(iface_name); p_sub->Configure();

  /* Create publisher */
  sdn::Topic_InitializeMetadata(mdata, "sdn://239.0.0.2:60002/ping", 0u);

  sdn::Topic echo; echo.SetMetadata(mdata);

  echo.AddAttribute<uint64_t>((uint_t) 0, (char*) "identifier");
  echo.AddAttribute<uint64_t>((uint_t) 1, (char*) "send-time");
  echo.AddAttribute<uint64_t>((uint_t) 2, (char*) "recv-time");
  echo.AddAttribute<uint8_t>((uint_t) 3, (char*) "reserved", size - (3*sizeof(uint64_t)));

  echo.SetUID(0u); echo.Configure();

  if (verbose) fprintf(stdout, "%% Create sdn::Publisher on '%s'\n", iface_name);
  log_info("Create sdn::Publisher on '%s'", iface_name);
  sdn::Publisher* p_pub = new sdn::Publisher (echo); p_pub->SetInterface(iface_name); p_pub->Configure();

  if (verbose) fprintf(stdout, "%% Staring test with '%d' iterations\n", count);
  log_info("Staring test with '%d' iterations", count);

  while ((_terminate != true) && (count > 0))
    {

      if (p_sub->Do() != STATUS_SUCCESS)
	{
	  log_warning("Unable to receive on '%s'", iface_name);
	}

      p_pub->CopyTopicInstance(p_sub->GetTopicInstance(), p_pub->GetTopicSize());

      if (p_pub->Do() != STATUS_SUCCESS)
	{
	  log_warning("Unable to publish on '%s'", iface_name);
	}

      count -= 1;

    }

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
