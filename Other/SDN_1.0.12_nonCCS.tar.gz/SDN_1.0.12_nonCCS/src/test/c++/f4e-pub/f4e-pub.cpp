/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/f4e-pub/f4e-pub.cpp $
* $Id: f4e-pub.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-api.h" /* SDN core library - API definition */

#include "f4e-topic-definition.h"

/* Constants */

#define DEFAULT_AFFINITY        0
#define DEFAULT_ITERATIONS  10000
#define DEFAULT_PERIOD 1000000000 /* 1Hz */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function definition */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core, defaults to 0.\n");
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are published, -1 for undefined number of counts (stops with Ctrl-C), defaults to 10.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -m|--mcast <mcast_addr>: UDP/IPv4 multicast address, defaults to '%s:%u'.\n", F4E_MCAST_GROUP, F4E_MCAST_PORT);
  fprintf(stdout, "         -p|--period <period_ns>: Publication period, defaults to 1000000000 (1Hz).\n");
  fprintf(stdout, "         -s|--size <topic_size>: Topic size in bytes, defaults to %lu.\n", sizeof(F4ETopicDefinition));
  fprintf(stdout, "         -t|--topic <topic_name>: Use <topic_name>, defaults to '%s'.\n", F4E_TOPIC_NAME);
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates SDN topic <topic_name>.\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  sdn::Metadata_t mdata; sdn::Topic_InitializeMetadata(mdata);

  sstrncpy(mdata.name, (char*) F4E_TOPIC_NAME, STRING_MAX_LENGTH);
  mdata.size = sizeof(F4ETopicDefinition);
  sstrncpy(mdata.mcast_group, (char*) F4E_MCAST_GROUP, MAX_IP_ADDR_LENGTH);
  mdata.mcast_port = F4E_MCAST_PORT;

  uint_t core = DEFAULT_AFFINITY;
  uint_t count = DEFAULT_ITERATIONS;
  uint64_t period = DEFAULT_PERIOD;

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &core);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-m") == 0) || (strcmp(argv[index], "--mcast") == 0))
	    {
	      /* Get topic MCAST address */
	      if ((index + 1) < (uint_t) argc) 
		{
		  char topic_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

		  sstrncpy((char*) topic_addr, argv[index + 1], STRING_MAX_LENGTH);

		  char* p_char = topic_addr; while (*p_char != ':') p_char += 1; *p_char = 0; /* Put a zero in lieu of ':' */

		  /* Parse MCAST group */
		  sstrncpy(mdata.mcast_group, (char*) topic_addr, MAX_IP_ADDR_LENGTH);

		  char* p_port = p_char + 1;

		  /* Parse MCAST port */
		  sscanf(p_port, "%u", &(mdata.mcast_port));
		}

	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-p") == 0) || (strcmp(argv[index], "--period") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &period);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--size") == 0))
	    {
	      /* Get topic size */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &(mdata.size));
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy((char*) mdata.name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      log_info("CCS version is '%s'", version);
    }

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      log_info("Program name is '%s'", prog_name);
    }

  /* Create publisher */
  log_info("Create publisher for '%s'", mdata.name);
  sdn::Publisher pub (mdata); pub.SetInterface((char*) iface_name); pub.Configure();

  /* Get topic instance */
  log_info("Associate datatype to '%s' topic instance", mdata.name);
  F4ETopicDefinition* p_buffer = (F4ETopicDefinition*) pub.GetTopicInstance();

  p_buffer->identifier = 0L;
  p_buffer->send_time = 0L;
  p_buffer->recv_time = 0L;

  uint64_t curr_time = get_time();
  uint64_t till_time = ceil_time(curr_time);

  log_info("Start publisher at '%lu'", till_time);

  while ((_terminate != true) && (count > 0))
    {

      curr_time = wait_until(till_time);

      p_buffer->identifier += 1;
      p_buffer->send_time = curr_time;

      if (pub.Publish() != STATUS_SUCCESS)
	{
	  log_warning("Unable to publish on '%s'", mdata.name);
	}

      till_time += period;
      count -= 1;

    }

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
