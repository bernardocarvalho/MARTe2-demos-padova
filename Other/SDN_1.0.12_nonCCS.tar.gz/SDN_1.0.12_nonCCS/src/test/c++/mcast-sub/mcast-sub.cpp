/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/mcast-sub/mcast-sub.cpp $
* $Id: mcast-sub.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/*
 * Done - Handle statistics computation in application-specific callback upon message reception
 */

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-base.h" /* SDN core library - Base classes definition */
#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */

#include "sdn-topic.h"

/* Constants */

#define DEFAULT_AFFINITY       0
#define DEFAULT_ITERATIONS 10000
#define DEFAULT_PAYLOAD     1024 /* 1kB */
#define DEFAULT_PERIOD         0 /* Blocking */

/* Type definition */

typedef struct {

  bool verbose;
  ccs::base::AnyType* p_type;
  FIFOBuffer<uint64_t>* p_fifo; 

} __mcast_sub_data;


/* Global variables */

bool _terminate = false;

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core, defaults to 0.\n");
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are published, -1 for undefined number of counts (stops with Ctrl-C), defaults to 10000.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -m|--mcast <mcast_addr>: UDP/IPv4 multicast address, defaults to '%s:%u'.\n", DEFAULT_MCAST_GROUP, DEFAULT_MCAST_PORT);
  fprintf(stdout, "         -p|--period <period_ns>: Expected publication period, defaults to 0 (i.e. blocking receive).\n");
  fprintf(stdout, "         -s|--size <payload>: Payload, defaults to 1024 (1kB).\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode, statistics and measurmeent data are printed on stdout.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates a MCAST subscriber that expects <payload> bytes packets on <iface_name>, etc.\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

void callback (__mcast_sub_data* p_data)
{

  bool verbose = p_data->verbose;
  ccs::base::AnyType* p_type = p_data->p_type;
  FIFOBuffer<uint64_t>* p_fifo = p_data->p_fifo;

  /* Reaching here, the message has been successfully received */
  {
    char buffer [2048] = STRING_UNDEFINED; p_type->SerializeInstance(buffer, 2048);
    log_debug("Received instance '%s'", (char*) buffer);
  }

  uint64_t recv_time = get_time();
  uint64_t send_time = 0L; p_type->GetAttribute((char*) "send-time", &send_time);
  
  uint64_t latency = recv_time - send_time;
  
  /* Store latency */
  p_fifo->PushData(latency);
  
  if (latency > 50000L)
    {
      uint64_t identifier = 0L; p_type->GetAttribute((char*) "identifier", &identifier);

      if (verbose) fprintf(stdout, "%% Latency above threshold for instance '%lu' - '%lu %lu %lu [ns]'\n", identifier, latency, send_time, recv_time);
      log_notice("Latency above threshold for instance '%lu' - '%lu %lu %lu [ns]'", identifier, latency, send_time, recv_time);
    }

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  char mcast_group [STRING_MAX_LENGTH] = DEFAULT_MCAST_GROUP;
  uint_t mcast_port = DEFAULT_MCAST_PORT;

  uint_t core = DEFAULT_AFFINITY;
  uint_t count = DEFAULT_ITERATIONS;
  uint64_t period = DEFAULT_PERIOD;
  uint_t size = DEFAULT_PAYLOAD;

  bool verbose = false; /* Set to true to get measurements on stdout so as to load/plot into e.g. Matlab */

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &core);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-m") == 0) || (strcmp(argv[index], "--mcast") == 0))
	    {
	      /* Get topic MCAST address */
	      if ((index + 1) < (uint_t) argc) 
		{
		  char topic_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

		  sstrncpy((char*) topic_addr, argv[index + 1], STRING_MAX_LENGTH);

		  char* p_char = topic_addr; while ((*p_char != ':') && (*p_char != 0)) p_char += 1; *p_char = 0; /* Put a zero in lieu of ':' */
		  char* p_port = p_char + 1;

		  if ((sdn_is_address_valid(topic_addr) != true) || (sdn_is_mcast_address(topic_addr) != true)) { /* Display usage */ fprintf(stdout, "Error: Invalid address '%s'.\n", topic_addr); return (0); }

		  /* Parse MCAST group */
		  sstrncpy(mcast_group, (char*) topic_addr, MAX_IP_ADDR_LENGTH);

		  /* Parse MCAST port */
		  sscanf(p_port, "%u", &mcast_port);
		}

	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-p") == 0) || (strcmp(argv[index], "--period") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &period);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--size") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &size);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  if (set_thread_affinity_to_core(core) != STATUS_SUCCESS)
    {
      log_warning("set_thread_affinity_to_core() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Setting thread affinity to core '%d'\n", core);
      log_info("Setting thread affinity to core '%d'", core);
    }

  /* Create payload */
  if (verbose) fprintf(stdout, "%% Create payload buffer of size '%u'\n", size);
  log_info("Create payload buffer of size '%u'", size);

  ccs::base::AnyType payload;

  payload.AddAttribute<uint64_t>((uint_t) 0, (char*) "identifier"); size -= sizeof(uint64_t);
  payload.AddAttribute<uint64_t>((uint_t) 1, (char*) "send-time");  size -= sizeof(uint64_t);
  payload.AddAttribute<uint64_t>((uint_t) 2, (char*) "recv-time");  size -= sizeof(uint64_t);
  payload.AddAttribute<char>((uint_t) 3, (char*) "reserved", size);

  payload.CreateInstance();

  void* p_msg = payload.GetInstance();
  size = payload.GetSize();

  /* Create subscriber */
  if (verbose) fprintf(stdout, "%% Create subscriber on '%s'\n", iface_name);
  log_info("Create subscriber on '%s'", iface_name);

  sdn::mcast::Subscriber sub (iface_name, mcast_group, mcast_port); 

  if (verbose) fprintf(stdout, "%% Associate payload to subscriber\n");
  log_info("Associate payload to subscriber"); 
  
  sub.SetBuffer(p_msg, size);

  if (verbose) fprintf(stdout, "%% Associate callback to subscriber for latency measurement\n");
  log_info("Associate callback to subscriber for latency measurement"); 
  
  FIFOBuffer<uint64_t>* p_fifo = new FIFOBuffer<uint64_t> (count); 

  __mcast_sub_data data;

  data.verbose = verbose;
  data.p_type = &payload;
  data.p_fifo = p_fifo; 

  sub.SetCallback((void (*) (void*)) &callback, (void*) &data);

  if (verbose) fprintf(stdout, "%% Staring test with '%d' iterations\n", count);
  log_info("Staring test with '%d' iterations", count);

  while ((_terminate != true) && (count > 0))
    {

      if (period != DEFAULT_PERIOD)
	{
#if 0
	  uint64_t till_time = get_time() + (period - 100000L); wait_until(till_time);
#endif
	  while (sub.Receive(0) != STATUS_SUCCESS) /* Spinlock on reception with zero timeout */ { if (_terminate == true) break; }
	}
      else if (sub.Receive() != STATUS_SUCCESS) /* Blocking receive */
	{
	  log_warning("Unable to receive on '%s'", iface_name);
	  continue;
	}

      count -= 1;

    }

  log_info("Computing statistics");

  uint64_t latency = 0L;
  Statistics<uint64_t>* p_stats = new Statistics<uint64_t> (count);

  /* Compute statistics */
  while ((_terminate != true) && (p_fifo->PullData(latency) != STATUS_ERROR))
    {
      /* Just for a quick feedback on the quality of the measurement */
      if (verbose) fprintf(stdout, "%lu\n", latency);
      log_debug("Latency is '%lu [ns]'\n", latency);

      p_stats->PushSample(latency);
    }

  /* Just for a quick feedback on the quality of the measurement */
  if (verbose) fprintf(stdout, "%% Statistics are '%lu %lu %lu %lu [ns]'\n", p_stats->GetAvg(), p_stats->GetStd(), p_stats->GetMin(), p_stats->GetMax());
  log_info("Statistics are '%lu %lu %lu %lu [ns]'\n", p_stats->GetAvg(), p_stats->GetStd(), p_stats->GetMin(), p_stats->GetMax());

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
