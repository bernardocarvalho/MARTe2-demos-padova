/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/gen-sub/gen-sub.cpp $
* $Id: gen-sub.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-packet.h"
#include "sdn-header.h"
#include "sdn-topic.h"

#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */

/* Constants */

/* Type definition */

/* Global variables */

/* Internal function declaration */

/* Internal function definition */

int main (int argc, char** argv) 
{

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  char topic_name [STRING_MAX_LENGTH] = DEFAULT_TOPIC_NAME;

  uint64_t count = 10L;

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if (strcmp(argv[index], "-c") == 0)
	    {
	      /* Get interface identifier */
	      sscanf(argv[index + 1], "%ld", &count);
	      index += 1;
            
	    }
	  else if (strcmp(argv[index], "-i") == 0)
	    {
	      /* Get interface identifier */
	      strcpy(iface_name, argv[index + 1]);
	      index += 1;
            
	    }
	  else if (strcmp(argv[index], "-t") == 0)
	    {
	      /* Get topic identifier */
	      strcpy(topic_name, argv[index + 1]);
	      index += 1;
            
	    }
	}
    }
  else
    {
    }

  /* Instantiate topic - Datatype discovered dynamically */
  sdn_topic* p_topic = new sdn_topic ((char*) topic_name); 

  {
    char buffer [256]; p_topic->SerializeType((char*) buffer, 256);
    log_info("Using topic definition - %s", buffer);
  }

  /* Instantiate packet - Payload defined by size */
  sdn_packet* p_packet = new sdn_packet (p_topic->GetSize()); p_packet->CreateInstance();

  {
    char buffer [256]; p_packet->SerializeType((char*) buffer, 256);
    log_info("Using packet definition - %s", buffer);
  }

  /* Take the reference to the topic instance */
  p_topic->SetInstance(p_packet->GetPayload()); p_topic->ClearInstance();

  /* Take a reference to the header instance */
  sdn_header* header = p_packet->GetHeader();

  void* msg = (void*) p_packet->GetInstance();
  uint_t size = (uint_t) p_packet->GetSize();

  /* Create subscriber */
  sdn::mcast::Subscriber sub (iface_name, p_topic->GetMCastGroup(), p_topic->GetMCastPort()); 

  while (count > 0)
    {

      if (sub.Receive(msg, size) != STATUS_SUCCESS) /* Message smaller than buffer size will still be returned */
	{
	  log_warning("Unable to receive on '%s'", iface_name);
	}
      else
	{

	  header->SetReceiveTimestamp();

	  /* Serialize topic instance */
	  char buffer [256]; 
	  p_packet->SerializeInstance((char*) buffer, 256);
	  log_info("Received packet '%s' ...", buffer);
	  p_topic->SerializeInstance((char*) buffer, 256);
	  log_info("... serialized payload '%s'", buffer);

	}

      count -= 1;

    }

  /* Terminate */

  return (0);

}
