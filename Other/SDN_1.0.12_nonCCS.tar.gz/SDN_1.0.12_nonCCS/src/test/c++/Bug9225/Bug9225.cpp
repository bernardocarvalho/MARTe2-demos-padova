/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/Bug9225/Bug9225.cpp $
* $Id: Bug9225.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-base.h" /* SDN core library - Base classes definition */
#include "sdn-api.h" /* SDN core library - API definition */

/* Constants */

#define DEFAULT_ITERATIONS      10
#define DEFAULT_TIMEOUT 1000000000 /* 1Hz */
#define DEFAULT_PAYLOAD 1024 /* 1kB */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to 'invalid'.\n");
  fprintf(stdout, "         -m|--mcast <mcast_addr>: UDP/IPv4 multicast address, defaults to '%s:%u'.\n", DEFAULT_MCAST_GROUP, DEFAULT_MCAST_PORT);
  fprintf(stdout, "         -s|--size <topic_size>: Topic size in bytes, defaults to %u.\n", DEFAULT_PAYLOAD);
  fprintf(stdout, "         -t|--topic <topic_name>: Subscribe to <topic_name>, defaults to 'RTDN_SDN_FELIX' (for test purposes).\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program ... .\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  /* Define topic metadata */
  sdn::Metadata_t mdata; sdn::Topic_InitializeMetadata(mdata);

  sstrncpy(mdata.name, (char*) "RTDN_SDN_FELIX", STRING_MAX_LENGTH);
  mdata.size = DEFAULT_PAYLOAD;

  uint_t count = DEFAULT_ITERATIONS;

  bool verbose = false; /* Set to true to get measurements on stdout so as to load/plot into e.g. Matlab */

  /* Try and retrieve interface identifier from the environment */
  get_env_variable((char*) SDN_INTERFACE_ENVVAR, (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (net_is_interface_valid(iface_name) != true) { /* Display usage */ fprintf(stdout, "Error: Invalid interface '%s'.\n", iface_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-m") == 0) || (strcmp(argv[index], "--mcast") == 0))
	    {
	      /* Get topic MCAST address */
	      if ((index + 1) < (uint_t) argc) 
		{
		  char topic_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

		  sstrncpy((char*) topic_addr, argv[index + 1], STRING_MAX_LENGTH);

		  char* p_char = topic_addr; while (*p_char != ':') p_char += 1; *p_char = 0; /* Put a zero in lieu of ':' */

		  /* Parse MCAST group */
		  sstrncpy(mdata.mcast_group, (char*) topic_addr, MAX_IP_ADDR_LENGTH);

		  char* p_port = p_char + 1;

		  /* Parse MCAST port */
		  sscanf(p_port, "%u", &(mdata.mcast_port));
		}

	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--size") == 0))
	    {
	      /* Get topic size */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &(mdata.size));
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(mdata.name, argv[index + 1], STRING_MAX_LENGTH);

		  if (sdn::Topic_LocateDefinitionFile((char*) mdata.name, NULL) != STATUS_SUCCESS) { /* Display usage */ fprintf(stdout, "Error: Unable to locate '%s' topic definition file.\n", mdata.name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (verbose) fprintf(stdout, "%% Unit version is '%s'\n", UNIT_VERSION);
  log_info("Unit version is '%s'", UNIT_VERSION);

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  /* Check topic metadata */

  if (sdn::Topic_IsMetadataValid(mdata) != true)
    {
      if (verbose) fprintf(stdout, "%% WARNING - Topic metadata is not valid\n");
      log_warning("Topic metadata is not valid");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - Topic metadata is valid\n");
      log_info("Topic metadata is valid");
    }

  if (mdata.mcast_port < 1024)
    {
      if (verbose) fprintf(stdout, "%% ERROR - Topic mapping in restricted port range '%u'\n", mdata.mcast_port);
      log_warning("Topic mapping in restricted port range '%u'", mdata.mcast_port);
     }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - Topic mapping in unrestricted port range '%u'\n", mdata.mcast_port);
      log_info("Topic mapping in unrestricted port range '%u'", mdata.mcast_port);
    }

  /* Create subscriber */
  if (verbose) fprintf(stdout, "%% Create subscriber for '%s' on '%s'\n", mdata.name, iface_name);
  log_info("Create subscriber for '%s' on '%s'", mdata.name, iface_name);

  sdn::Subscriber sub (mdata);

  if (sub.SetInterface(iface_name) != STATUS_SUCCESS)
    {
      if (verbose) fprintf(stdout, "%% WARNING - sdn::Subscriber::SetInterface('%s') failed\n", iface_name);
      log_warning("sdn::Subscriber::SetInterface('%s') failed", iface_name);
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - sdn::Subscriber::SetInterface('%s') successful (expected)\n", iface_name);
      log_info("sdn::Subscriber::SetInterface('%s') successful (expected)", iface_name);
    }

  if (sub.Configure() != STATUS_SUCCESS)
    {
      if (verbose) fprintf(stdout, "%% WARNING - sdn::Subscriber::Configure() failed\n");
      log_warning("sdn::Subscriber::Configure() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - sdn::Subscriber::Configure() successful (expected)\n");
      log_info("sdn::Subscriber::Configure() successful (expected)");
    }

  if (verbose) fprintf(stdout, "%% Staring test with '%d' iterations\n", count);
  log_info("Staring test with '%d' iterations", count);

  while ((_terminate != true) && (count > 0))
    {

      if (sub.Receive(DEFAULT_TIMEOUT) != STATUS_SUCCESS) /* Blocking receive */
	{
	  if (verbose) fprintf(stdout, "%% WARNING - Unable to receive on '%s'\n", iface_name);
	  log_warning("Unable to receive on '%s'", iface_name);
	}

      count -= 1;

    }

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
