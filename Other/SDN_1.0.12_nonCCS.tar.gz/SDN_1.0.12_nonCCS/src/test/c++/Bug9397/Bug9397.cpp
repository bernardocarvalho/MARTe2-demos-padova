/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/Bug9397/Bug9397.cpp $
* $Id: Bug9397.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-api.h" /* SDN core library - API definition */

/* Constants */

#define DEFAULT_AFFINITY       0
#define DEFAULT_ITERATIONS    10
#define DEFAULT_PERIOD   1000000 /* 1kHz */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core.\n");
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are published, -1 for undefined number of counts (stops with Ctrl-C), defaults to 10.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -p|--period <period_ns>: Publication period, defaults to 1000000000 (1Hz).\n");
  fprintf(stdout, "         -s|--size <topic_size>: Topic size required in case topic definition XML file is not available.\n");
  fprintf(stdout, "         -t|--topic <topic_name>: Publish on <topic_name>, defaults to 'Bug9397-topic' (for test purposes).\n");
  fprintf(stdout, "         -u|--ucast <ucast_addr>: Imposes usage of a UDP/IPv4 unicast address of the form '<ip_addr>:<port>', e.g. '127.0.0.1:60001'.\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates SDN <topic_name> and <topic_size> and streams it on <iface_name> with configurable rate, optional <start_time>, etc.\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  sdn::Metadata_t mdata; sdn::Topic_InitializeMetadata(mdata, "Bug9397-topic", DEFAULT_TOPIC_SIZE, DEFAULT_UCAST_ADDR, DEFAULT_UCAST_PORT); /* Metadata with name, size and address */

  uint_t core = DEFAULT_AFFINITY;
  uint_t count = DEFAULT_ITERATIONS;
  uint64_t period = DEFAULT_PERIOD;

  bool verbose = false;

  /* Set interface identifier to environment */
  set_env_variable((char*) SDN_INTERFACE_ENVVAR, (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc)
		{
		  sscanf(argv[index + 1], "%u", &core);

		  if (set_thread_affinity_to_core(core) != STATUS_SUCCESS) log_warning("set_thread_affinity_to_core() failed");
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (net_is_interface_valid(iface_name) != true) { /* Display usage */ fprintf(stdout, "Error: Invalid interface '%s'.\n", iface_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-m") == 0) || (strcmp(argv[index], "--mcast") == 0))
	    {
	      /* Get topic MCAST address */
	      if ((index + 1) < (uint_t) argc) 
		{
		  char mcast_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

		  sstrncpy((char*) mcast_addr, argv[index + 1], STRING_MAX_LENGTH);

 		  char* p_char = (char*) mcast_addr; while ((*p_char != ':') && (*p_char != 0)) p_char += 1; *p_char = 0; /* Put a zero in lieu of ':' */
		  char* p_port = p_char + 1;

		  if ((sdn_is_address_valid(mcast_addr) != true) || (sdn_is_mcast_address(mcast_addr) != true)) { /* Display usage */ fprintf(stdout, "Error: Invalid address '%s'.\n", mcast_addr); return (0); }

		  sstrncpy((char*) mdata.mcast_group, (char*) mcast_addr, MAX_IP_ADDR_LENGTH);

		  /* Parse MCAST port */
		  sscanf(p_port, "%u", &(mdata.mcast_port));
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-p") == 0) || (strcmp(argv[index], "--period") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &period);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--size") == 0))
	    {
	      /* Get topic size */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &(mdata.size));
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy((char*) mdata.name, argv[index + 1], STRING_MAX_LENGTH);

		  if (sdn::Topic_LocateDefinitionFile((char*) mdata.name, NULL) != STATUS_SUCCESS) { /* Display usage */ fprintf(stdout, "Error: Unable to locate '%s' topic definition file.\n", mdata.name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-u") == 0) || (strcmp(argv[index], "--ucast") == 0))
	    {
	      /* Get topic UCAST address */
	      if ((index + 1) < (uint_t) argc) 
		{

		  char ucast_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

		  sstrncpy((char*) ucast_addr, argv[index + 1], STRING_MAX_LENGTH);

 		  char* p_char = (char*) ucast_addr; while ((*p_char != ':') && (*p_char != 0)) p_char += 1; *p_char = 0; /* Put a zero in lieu of ':' */
		  char* p_port = p_char + 1;

		  if ((sdn_is_address_valid(ucast_addr) != true) || (sdn_is_ucast_address(ucast_addr) != true)) { /* Display usage */ fprintf(stdout, "Error: Invalid address '%s'.\n", ucast_addr); return (0); }

		  sstrncpy((char*) mdata.mcast_group, (char*) ucast_addr, MAX_IP_ADDR_LENGTH);

		  /* Parse UCAST port */
		  sscanf(p_port, "%u", &(mdata.mcast_port));
		}
	      
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (verbose) fprintf(stdout, "%% Unit version is '%s'\n", UNIT_VERSION);
  log_info("Unit version is '%s'", UNIT_VERSION);

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  /* Create publisher */
  if (verbose) fprintf(stdout, "%% Create publisher for topic '%s' (size '%u') on '%s'\n", mdata.name, mdata.size, iface_name);
  log_info("Create publisher for '%s' on '%s'", mdata.name, iface_name);
  sdn::Publisher pub (mdata); 

  if (pub.SetInterface(iface_name) != STATUS_SUCCESS)
    {
      if (verbose) fprintf(stdout, "%% ERROR - sdn::Publisher::SetInterface('%s') failed (unexpected)\n", iface_name);
      log_error("sdn::Publisher::SetInterface('%s') failed (unexpected)", iface_name);
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - sdn::Publisher::SetInterface('%s') successful (expected)\n", iface_name);
      log_info("sdn::Publisher::SetInterface('%s') successful (expected)", iface_name);
    }

  if (pub.Configure() != STATUS_SUCCESS)
    {
      if (verbose) fprintf(stdout, "%% ERROR - sdn::Publisher::Configure() failed (unexpected)\n");
      log_error("sdn::Publisher::Configure() failed (unexpected)");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - sdn::Publisher::Configure() successful (expected)\n");
      log_info("sdn::Publisher::Configure() successful (expected)");
    }

  /* Create publisher */
  if (verbose) fprintf(stdout, "%% Create subscriber for topic '%s' (size '%u') on '%s'\n", mdata.name, mdata.size, iface_name);
  log_info("Create subscriber for '%s' on '%s'", mdata.name, iface_name);
  sdn::Subscriber sub (mdata); 

  if (sub.SetInterface(iface_name) != STATUS_SUCCESS)
    {
      if (verbose) fprintf(stdout, "%% ERROR - sdn::Subscriber::SetInterface('%s') failed (unexpected)\n", iface_name);
      log_error("sdn::Subscriber::SetInterface('%s') failed (unexpected)", iface_name);
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - sdn::Subscriber::SetInterface('%s') successful (expected)\n", iface_name);
      log_info("sdn::Subscriber::SetInterface('%s') successful (expected)", iface_name);
    }

  if (sub.Configure() != STATUS_SUCCESS)
    {
      if (verbose) fprintf(stdout, "%% ERROR - sdn::Subscriber::Configure() failed (unexpected)\n");
      log_error("sdn::Subscriber::Configure() failed (unexpected)");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% INFO - sdn::Subscriber::Configure() successful (expected)\n");
      log_info("sdn::Subscriber::Configure() successful (expected)");
    }

  uint64_t curr_time = get_time();
  uint64_t till_time = ceil_time(curr_time);

  if (verbose) fprintf(stdout, "%% Start publisher at '%lu'\n", till_time);
  log_info("Start publisher at '%lu'", till_time);

  while ((_terminate != true) && (count > 0))
    {

      curr_time = wait_until(till_time);

      if (pub.Publish() != STATUS_SUCCESS)
	{
	  if (verbose) fprintf(stdout, "%% ERROR - Unable to publish on '%s' (unexpected)\n", iface_name);
	  log_error("Unable to publish on '%s'", iface_name);
	}

      if (sub.Receive(0L) != STATUS_SUCCESS)
	{
	  if (verbose) fprintf(stdout, "%% ERROR - Unable to receive on '%s' (unexpected)\n", iface_name);
	  log_error("Unable to receive on '%s'", iface_name);
	}

      till_time += period;
      count -= 1;

    }

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
