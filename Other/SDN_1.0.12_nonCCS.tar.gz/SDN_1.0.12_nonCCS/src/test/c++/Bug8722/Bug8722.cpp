/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/Bug8722/Bug8722.cpp $
* $Id: Bug8722.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-types.h" /* Misc. type definition */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash */

/* Constants */

/* Type definition */

/* Global variables */

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program ... .\n");
  fprintf(stdout, "\n");

  return;

};

int main (int argc, char** argv) 
{

  char iface_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  bool verbose = false; /* Set to true to get measurements on stdout so as to load/plot into e.g. Matlab */

  /* Try and retrieve interface identifier from the environment */
  get_env_variable((char*) SDN_INTERFACE_ENVVAR, (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
           if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (verbose) fprintf(stdout, "%% Unit version is '%s'\n", UNIT_VERSION);
  log_info("Unit version is '%s'", UNIT_VERSION);

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  if (verbose) fprintf(stdout, "%% net_is_interface_valid('%s') is %s\n", iface_name, ((net_is_interface_valid(iface_name) == true) ? "valid" : "invalid"));
  log_info("net_is_interface_valid('%s') is %s", iface_name, ((net_is_interface_valid(iface_name) == true) ? "valid" : "invalid"));

  return (0);

}
