/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/gen-pub/gen-pub.cpp $
* $Id: gen-pub.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-packet.h"
#include "sdn-header.h"
#include "sdn-topic.h"

#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */

/* Constants */

#define DEFAULT_AFFINITY       0
#define DEFAULT_ITERATIONS 10000
#define DEFAULT_PERIOD   1000000 /* 1kHz */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core, defaults to 0.\n");
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are published, -1 for undefined number of counts (stops with Ctrl-C), defaults to 10.\n");
  fprintf(stdout, "         -f|--file <file_path>: Optionally playback topic instances from <file_path>, defaults to stream empty <topic_name> instances.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -p|--period <period_ns>: Publication period, defaults to 1000000000 (1Hz).\n");
  fprintf(stdout, "         -s|--start <start_time>: Absolute start time as uint64 (ns), defaults to next exact second.\n");
  fprintf(stdout, "         -t|--topic <topic_name>: Publish on <topic_name>, defaults to 'one-pps' (for test purposes).\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates SDN <topic_name> and streams it in <iface_name> with configurable rate, optional <start_time>, etc.\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  char topic_name [STRING_MAX_LENGTH] = DEFAULT_TOPIC_NAME;

  uint_t core = DEFAULT_AFFINITY;
  uint_t count = DEFAULT_ITERATIONS;
  uint64_t period = DEFAULT_PERIOD;

  char file_path [PATH_MAX_LENGTH] = STRING_UNDEFINED;
  FILE* fp = NULL;
  char* line = NULL;
  size_t length;
  uint64_t start_time = 0L;

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &core);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-f") == 0) || (strcmp(argv[index], "--file") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(file_path, argv[index + 1], PATH_MAX_LENGTH);

		  if (exist((char*) file_path) != true) { /* Display usage */ fprintf(stdout, "Error: File '%s' can not be found.\n", file_path); return (0); }
		  
		  fp = fopen(file_path, "r"); while (getline(&line, &length, fp) != -1) { if (line[0] == '%') continue; else break; }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-p") == 0) || (strcmp(argv[index], "--period") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &period);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-s") == 0) || (strcmp(argv[index], "--start") == 0))
	    {
	      /* Get start time */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &start_time);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(topic_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (sdn::Topic_LocateDefinitionFile((char*) topic_name, NULL) != STATUS_SUCCESS) { /* Display usage */ fprintf(stdout, "Error: Unable to locate '%s' topic definition file.\n", topic_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      log_info("CCS version is '%s'", version);
    }

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      log_info("Program name is '%s'", prog_name);
    }

  if (set_thread_affinity_to_core(core) != STATUS_SUCCESS)
    {
      log_warning("set_thread_affinity_to_core() failed");
    }
  else
    {
      log_info("Setting thread affinity to core '%d'", core);
    }

  /* Instantiate topic - Datatype discovered dynamically */
  sdn_topic topic ((char*) topic_name); 

  {
    char buffer [256]; topic.SerializeType((char*) buffer, 256);
    log_info("Using topic definition - %s", buffer);
  }

  /* Instantiate packet - Payload defined by size */
  sdn_packet packet (topic.GetSize()); packet.CreateInstance();

  {
    char buffer [256]; packet.SerializeType((char*) buffer, 256);
    log_info("Using packet definition - %s", buffer);
  }

  /* Take the reference to the topic instance */
  topic.SetInstance(packet.GetPayload()); topic.ClearInstance();

  /* Take a reference to the header instance */
  sdn_header* header = packet.GetHeader();

  header->SetTopicSize(topic.GetSize());
  header->SetTopicUID(topic.GetUID());
  header->SetTopicVersion(topic.GetVersion());

  void* msg = (void*) packet.GetInstance();
  uint_t size = (uint_t) packet.GetSize();

  /* Create publisher */
  log_info("Create publisher on '%s'", iface_name);
  sdn::mcast::Publisher pub (iface_name, topic.GetMCastGroup(), topic.GetMCastPort());

  uint64_t curr_time = get_time();
  uint64_t till_time = ((start_time == 0L) ? ceil_time(curr_time) : start_time);

  char* attr_name = topic.HasInstanceTimestamp();

  log_info("Start publisher at '%lu'", till_time);

  while ((_terminate != true) && (count > 0))
    {

      curr_time = wait_until(till_time);

      header->IncrCounter();
      header->SetTimestamp(curr_time);

      if (fp != NULL) { /* Parse line */ (topic.GetTypeDefinition())->ParseInstance(line); /* Load next line or terminate */ if (getline(&line, &length, fp) == -1) break; }

      if (attr_name != NULL) { topic.SetAttribute(attr_name, (void*) &curr_time); } 
 
      if (pub.Publish(msg, size) != STATUS_SUCCESS)
	{
	  log_warning("Unable to publish on '%s'", iface_name);
	}
#if 0
      else
	{
	  /* Serialize topic instance */
	  char buffer [256]; 
	  packet.SerializeInstance((char*) buffer, 256);
	  log_debug("Published packet '%s'", buffer);
	  topic.SerializeInstance((char*) buffer, 256);
	  log_debug("Published instance '%s'", buffer);
	}
#endif
      till_time += period;
      count -= 1;

    }

  if (fp != NULL) fclose(fp);

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
