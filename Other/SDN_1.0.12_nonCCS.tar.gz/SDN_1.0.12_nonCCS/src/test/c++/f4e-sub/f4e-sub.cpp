/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/f4e-sub/f4e-sub.cpp $
* $Id: f4e-sub.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-api.h" /* SDN core library - API definition */

#include "f4e-topic-definition.h"

/* Constants */

#define DEFAULT_AFFINITY       0
#define DEFAULT_ITERATIONS 10000
#define DEFAULT_PERIOD   1000000 /* 1kHz */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -a|--affinity <core_id>: Run thread on <core_id> CPU core, defaults to 0.\n");
  fprintf(stdout, "         -c|--count <sample_nb>: Stop after <sample_nb> are published, -1 for undefined number of counts (stops with Ctrl-C), defaults to 10000.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to ${SDN_INTERFACE_NAME}.\n");
  fprintf(stdout, "         -p|--period <period_ns>: Expected publication period, defaults to 0 (i.e. blocking receive).\n");
  fprintf(stdout, "         -t|--topic <topic_name>: Subscribe to <topic_name>, defaults to 'one-pps' (for test purposes).\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode, statistics and measurmeent data are printed on stdout.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program instantiates SDN <topic_name> and configures itself to receive it on <iface_name>. It computes latency statistics, etc.\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  char topic_name [STRING_MAX_LENGTH] = DEFAULT_TOPIC_NAME;

  uint_t core = DEFAULT_AFFINITY;
  uint_t count = DEFAULT_ITERATIONS;
  uint64_t period = DEFAULT_PERIOD;

  bool verbose = false; /* Set to true to get measurements on stdout so as to load/plot into e.g. Matlab */

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
	  else if ((strcmp(argv[index], "-a") == 0) || (strcmp(argv[index], "--affinity") == 0))
	    {
	      /* Get core identifier */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &core);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-c") == 0) || (strcmp(argv[index], "--count") == 0))
	    {
	      /* Get record count */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%u", &count);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-p") == 0) || (strcmp(argv[index], "--period") == 0))
	    {
	      /* Get publication period */
	      if ((index + 1) < (uint_t) argc) sscanf(argv[index + 1], "%lu", &period);
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(topic_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (sdn::Topic_LocateDefinitionFile((char*) topic_name, NULL) != STATUS_SUCCESS) { /* Display usage */ fprintf(stdout, "Error: Unable to locate '%s' topic definition file.\n", topic_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  if (set_thread_affinity_to_core(core) != STATUS_SUCCESS)
    {
      log_warning("set_thread_affinity_to_core() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Setting thread affinity to core '%d'\n", core);
      log_info("Setting thread affinity to core '%d'", core);
    }

  /* Create subscribers */
  if (verbose) fprintf(stdout, "%% Create subscribers on '%s'\n", iface_name);
  
  sdn::Subscriber* p_sub = NULL;
  LUTable<sdn::Subscriber*> sub_tbl;

  sstrncpy(topic_name, (char*) "f4e-topic-1", STRING_MAX_LENGTH); log_info("Create subscriber for '%s' on '%s'", topic_name, iface_name); p_sub = new sdn::Subscriber (topic_name); p_sub->SetInterface(iface_name); p_sub->Configure(); sub_tbl.AddPair((char*) topic_name, p_sub);
  sstrncpy(topic_name, (char*) "f4e-topic-2", STRING_MAX_LENGTH); log_info("Create subscriber for '%s' on '%s'", topic_name, iface_name); p_sub = new sdn::Subscriber (topic_name); p_sub->SetInterface(iface_name); p_sub->Configure(); sub_tbl.AddPair((char*) topic_name, p_sub);
  //sstrncpy(topic_name, (char*) "f4e-topic-3", STRING_MAX_LENGTH); log_info("Create subscriber for '%s' on '%s'", topic_name, iface_name); p_sub = new sdn::Subscriber (topic_name); p_sub->SetInterface(iface_name); p_sub->Configure(); sub_tbl.AddPair((char*) topic_name, p_sub);
  //sstrncpy(topic_name, (char*) "f4e-topic-4", STRING_MAX_LENGTH); log_info("Create subscriber for '%s' on '%s'", topic_name, iface_name); p_sub = new sdn::Subscriber (topic_name); p_sub->SetInterface(iface_name); p_sub->Configure(); sub_tbl.AddPair((char*) topic_name, p_sub);

  sdn::Metadata_t mdata; sdn::Topic_InitializeMetadata(mdata);

  sstrncpy(mdata.name, (char*) F4E_TOPIC_NAME, STRING_MAX_LENGTH);
  mdata.size = sizeof(F4ETopicDefinition);
  sstrncpy(mdata.mcast_group, (char*) F4E_MCAST_GROUP, MAX_IP_ADDR_LENGTH);
  mdata.mcast_port = F4E_MCAST_PORT;

  log_info("Create subscriber for '%s' on '%s'", mdata.name, iface_name); p_sub = new sdn::Subscriber (mdata); p_sub->SetInterface(iface_name); p_sub->Configure(); sub_tbl.AddPair((char*) mdata.name, p_sub);

  uint64_t curr_time = get_time();
  uint64_t till_time = ceil_time(curr_time) + (period >> 1);

  if (verbose) fprintf(stdout, "%% Staring test with '%d' iterations at '%lu'\n", count, till_time);
  log_info("Staring test with '%d' iterations at '%lu'", count, till_time);

  while ((_terminate != true) && (count > 0))
    {

      curr_time = wait_until(till_time);

      for (uint_t index = 0; index < sub_tbl.GetSize(); index += 1)
	{

	  /* Recover subscriber instance from look-up table */
	  sub_tbl.GetKeyword((char*) topic_name, index);
	  sub_tbl.GetValue(p_sub, index);

	  /* Test if payload is available - sdn::Subscriber::Receive with zero timeout */
	  if (p_sub->Receive(0L) != STATUS_SUCCESS)
	    {
	      log_warning("Topic '%s' - No update available at '%lu'", topic_name, curr_time);
	    }
	  else
	    {

	      log_info("Topic '%s' - Update available at '%lu'", topic_name, curr_time);

	      sdn::Topic* p_topic = p_sub->m_topic; /* ToDo - Should use appropriate accessor for this */
	      char* attr_name = p_topic->HasInstanceTimestamp();

	      uint64_t send_time = 0L; 

	      if (attr_name != NULL) p_topic->GetAttribute(attr_name, (void*) &send_time); 
	      else 
		{
		  F4ETopicDefinition* p_buffer = (F4ETopicDefinition*) p_sub->GetTopicInstance();
		  send_time = p_buffer->send_time;
		}

	      log_info("Topic '%s' - Payload has age of '%lu'", topic_name, curr_time - send_time);

	      /* Serialize payload for logging purposes */
	      char buffer [256]; p_topic->SerializeInstance((char*) buffer, 256);

	      log_info("Topic '%s' - Serialized payload is '%s'", topic_name, buffer);

	    }

	}

      till_time += period;
      count -= 1;

    }

  /* Terminate */
  log_info("Terminate program");

  for (uint_t index = 0; index < sub_tbl.GetSize(); index += 1)
    {
      
      /* Recover subscriber instance from look-up table */
      sub_tbl.GetKeyword((char*) topic_name, index);
      sub_tbl.GetValue(p_sub, index);

      log_info("Delete subscriber for '%s' on '%s'", topic_name, iface_name); if (p_sub != NULL) delete p_sub;
      
    }

  return (0);

}
