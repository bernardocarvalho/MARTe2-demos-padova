/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/Bug9290/Bug9290.cpp $
* $Id: Bug9290.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */
#include <signal.h> /* sigset, etc. */

/* Local header files */

#include "sdn-base.h" /* SDN core library - Base classes definition */
#include "sdn-api.h" /* SDN core library - API definition */

/* Constants */

/* Type definition */

/* Global variables */

bool _terminate = false;

/* Internal function declaration */

/* Internal function definition */

void print_usage (void)
{

  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  get_program_name((char*) prog_name);

  fprintf(stdout, "Usage: %s <options>\n", prog_name);
  fprintf(stdout, "Options: -h|--help: Print usage.\n");
  fprintf(stdout, "         -i|--iface <iface_name>: Use <iface_name> as SDN interface, defaults to 'invalid'.\n");
  fprintf(stdout, "         -t|--topic <topic_name>: Subscribe to <topic_name>, defaults to 'Bug9290-topic' (for test purposes).\n");
  fprintf(stdout, "         -v|--verbose: Verbose mode.\n");
  fprintf(stdout, "\n");
  fprintf(stdout, "The program ... .\n");
  fprintf(stdout, "\n");

  return;

};

void signal_handler (int signal)
{

  log_info("Received signal '%d' to terminate", signal);
  _terminate = true;

};

int main (int argc, char** argv) 
{

  /* Install signal handler to support graceful termination */
  sigset(SIGTERM, signal_handler);
  sigset(SIGINT,  signal_handler);
  sigset(SIGHUP,  signal_handler);

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  char topic_name [STRING_MAX_LENGTH] = "Bug9290-topic";

  bool verbose = false; /* Set to true to get measurements on stdout so as to load/plot into e.g. Matlab */

  /* Try and retrieve interface identifier from the environment */
  get_env_variable((char*) SDN_INTERFACE_ENVVAR, (char*) iface_name);

  if (argc > 1)
    {
      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-h") == 0) || (strcmp(argv[index], "--help") == 0))
	    {
	      /* Display usage */
	      print_usage();
	      return (0);
	    }
          else if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy(iface_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (net_is_interface_valid(iface_name) != true) { /* Display usage */ fprintf(stdout, "Error: Invalid interface '%s'.\n", iface_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      if ((index + 1) < (uint_t) argc) 
		{
		  sstrncpy((char*) topic_name, argv[index + 1], STRING_MAX_LENGTH);

		  if (sdn::Topic_LocateDefinitionFile((char*) topic_name, NULL) != STATUS_SUCCESS) { /* Display usage */ fprintf(stdout, "Error: Unable to locate '%s' topic definition file.\n", topic_name); return (0); }
		}
	      else { /* Display usage */ print_usage(); return (0); }
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true;
            
	    }
	}
    }
  else
    {
    }

  char version   [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_ccs_version(version) != STATUS_SUCCESS)
    {
      log_warning("get_ccs_version() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% CCS version is '%s'\n", version);
      log_info("CCS version is '%s'", version);
    }

  if (verbose) fprintf(stdout, "%% Unit version is '%s'\n", UNIT_VERSION);
  log_info("Unit version is '%s'", UNIT_VERSION);

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Host name is '%s'\n", host_name);
      log_info("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      if (verbose) fprintf(stdout, "%% Program name is '%s'\n", prog_name);
      log_info("Program name is '%s'", prog_name);
    }

  /* Create topic */
  if (verbose) fprintf(stdout, "%% Create topic '%s'\n", topic_name);
  log_info("Create topic '%s'", topic_name);

  sdn::Topic topic ((char*) topic_name);

  /* Test qualifiers */
  if (topic.IsInitialized() != true)
    {
      if (verbose) fprintf(stdout, "%% ERROR - Topic '%s' is not intialized\n", topic_name);
      log_error("Topic '%s' is not intialized", topic_name);
      return -1;
    }

  /* Display topic introspection data */
  sdn::base::AnyType* p_type_def = topic.GetTypeDefinition();

  if (verbose) 
    {

      fprintf(stdout, "%% INFO - Topic '%s' size '%u'\n", topic.GetName(), topic.GetSize());

      for (uint_t index = 0; index < p_type_def->GetRank(); index += 1)
	{
	  fprintf(stdout, "%% %u (index) - %s %s", index, AnyType_GetTypeName(p_type_def->GetAttributeType(index)), p_type_def->GetAttributeName(index)); 

	  if (p_type_def->ccs::base::AnyType::GetAttributeMultiplicity(index) > 1) fprintf(stdout, " [%u];", p_type_def->ccs::base::AnyType::GetAttributeMultiplicity(index)); 
	  else fprintf(stdout, ";");

	  if (p_type_def->GetAttributeQualifier(index) != NULL) fprintf(stdout, " /* Qualifier '%s' */", p_type_def->GetAttributeQualifier(index)); 

	  fprintf(stdout, "\n");
	}

    }

  char* attr_name = NULL;

  if (((attr_name = topic.HasInstanceIndex()) != NULL) && (strcmp(attr_name, "packet-counter") == 0))
    {
      if (verbose) fprintf(stdout, "%% INFO - Topic has instance index attribute '%s'\n", attr_name);
      log_info("Topic has instance index attribute '%s'", attr_name);
    }
  else
    {
      if (verbose) fprintf(stdout, "%% ERROR - Topic has instance index attribute '%s'\n", attr_name);
      log_error("Topic has instance index attribute '%s'", attr_name);
    }

  if (((attr_name = topic.HasInstanceTimestamp()) != NULL) && (strcmp(attr_name, "packet-timestamp") == 0))
    {
      if (verbose) fprintf(stdout, "%% INFO - Topic has instance time attribute '%s'\n", attr_name);
      log_info("Topic has instance time attribute '%s'", attr_name);
    }
  else
    {
      if (verbose) fprintf(stdout, "%% ERROR - Topic has instance time attribute '%s'\n", attr_name);
      log_error("Topic has instance time attribute '%s'", attr_name);
    }

  /* Terminate */
  log_info("Terminate program");

  return (0);

}
