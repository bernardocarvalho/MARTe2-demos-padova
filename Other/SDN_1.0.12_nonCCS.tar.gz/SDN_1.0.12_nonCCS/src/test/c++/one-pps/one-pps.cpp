/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/one-pps/one-pps.cpp $
* $Id: one-pps.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN Software - Communication API - Simple examples
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */
#include <stdarg.h> /* va_start, etc. */

/* Local header files */

#include "sdn-base.h" /* SDN core library - Base classes definition */
#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */

#include "sdn-packet.h"
#include "sdn-header.h"
#include "sdn-topic.h"

/* Constants */

#undef DEFAULT_TOPIC_NAME
#define DEFAULT_TOPIC_NAME "one-pps"

/* Type definition */

/* Global variables */

/* Internal function definition */

/* Public function definition */

int main(int argc, char **argv)
{

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;
  char topic_name [STRING_MAX_LENGTH] = DEFAULT_TOPIC_NAME;

  bool verbose = false;

  /* Try and retrieve interface identifier from environment */
  get_env_variable((char*) SDN_INTERFACE_ENVVAR, (char*) iface_name);

  if (argc > 1)
    {

      for (uint_t index = 1; index < (uint_t) argc; index++)
	{
          if ((strcmp(argv[index], "-i") == 0) || (strcmp(argv[index], "--iface") == 0))
	    {
	      /* Get interface identifier */
	      sstrncpy((char*) iface_name, argv[index + 1], STRING_MAX_LENGTH);
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-t") == 0) || (strcmp(argv[index], "--topic") == 0))
	    {
	      /* Get topic identifier */
	      sstrncpy((char*) topic_name, argv[index + 1], STRING_MAX_LENGTH);
	      index += 1;
            
	    }
	  else if ((strcmp(argv[index], "-v") == 0) || (strcmp(argv[index], "--verbose") == 0))
	    {
	      /* Set verbose mode */
	      verbose = true; 
            
	    }
	}
    }
  else
    {
    }

  /* Instantiate topic - Datatype discovered dynamically */
  sdn::Topic topic ((char*) topic_name); 

  {
    char buffer [1024]; topic.SerializeType((char*) buffer, 1024);
    log_info("Using topic definition - %s", buffer);
  }

  /* Instantiate packet - Payload defined by size */
  sdn::Packet packet (topic.GetSize()); packet.CreateInstance();

  {
    char buffer [1024]; packet.SerializeType((char*) buffer, 1024);
    log_info("Using packet definition - %s", buffer);
  }

  /* Take the reference to the topic instance */
  topic.SetInstance(packet.GetPayload()); topic.ClearInstance();

  /* Take a reference to the header instance */
  sdn::Header* header = packet.GetHeader();

  header->SetTopicSize(topic.GetSize());
  header->SetTopicUID(topic.GetUID());
  header->SetTopicVersion(topic.GetVersion());

  void* msg = (void*) packet.GetInstance();
  uint_t size = (uint_t) packet.GetSize();

  /* Create publisher */
  sdn::base::Publisher* p_ref = (sdn::base::Publisher*) new sdn::mcast::Publisher ();
  p_ref->SetInterface(iface_name); p_ref->SetAddress(topic.GetMCastGroup()); p_ref->SetPort(topic.GetMCastPort()); p_ref->Open();

  uint64_t id = 0;
  uint64_t curr_time = get_time();
  uint64_t till_time = ceil_time(curr_time); /* Next integral second in the future */ 

  while (true)
    {
      curr_time = wait_until(till_time); /* Block until future time is reached */
      till_time = ceil_time(curr_time); /* Compute next sampling event, i.e. next integral second */

      header->UpdateInstance();

      topic.SetAttribute((uint_t) 0, id);
      topic.SetAttribute((uint_t) 1, curr_time);

      if (p_ref->Publish(msg, size) != STATUS_SUCCESS)
	{
	  log_warning("Unable to publish time on '%s'", iface_name);
	}
      else
	{
	  log_info("Publish instance '%ld' at '%ld' on '%s'", id, curr_time, iface_name);
	}

	id += 1;
    }

  /* Terminate */

  return 0;

};
