#ifndef F4E_TOPIC_DEFINITION_H
#define F4E_TOPIC_DEFINITION_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/test/c++/include/f4e-topic-definition.h $
* $Id: f4e-topic-definition.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "sdn-types.h" /* Misc. type definition, e.g. condensed integer types, etc. */

/* Constants */

#define F4E_TOPIC_NAME "f4e-compile-time-topic"
#define F4E_MCAST_GROUP "239.0.0.4"
#define F4E_MCAST_PORT 60004

/* Type definition */

typedef struct {

  uint64_t identifier;
  uint64_t send_time;
  uint64_t recv_time;
  uint8_t reserved[40];

} F4ETopicDefinition;

#endif /* F4E_TOPIC_DEFINITION_H */
