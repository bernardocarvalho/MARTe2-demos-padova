/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/sdn-publisher.cpp $
* $Id: sdn-publisher.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
#include "sdn-api.h" /* SDN core library - API definition */

#include "sdn-header.h"
#include "sdn-footer.h"
#include "sdn-topic.h"
#include "sdn-packet.h"

#include "core-participant.h"
#include "core-publisher.h"

#include "disc-publisher.h"

#include "sdn-participant.h"
//#include "sdn-publisher.h" /* This class definition */

/* Constants */

#define OBJTYPE_SDN_PUBLISHER (char*) "sdn::Publisher_Base"

#define DEFAULT_PUBLISHER_PERIOD 1000000000L /* 1Hz */
#define DEFAULT_PUBLISHER_WAIT_PERIOD 10000L

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::pub"

/* Type definition */

namespace sdn {

class Publisher_Base : public Participant_Impl /* Base class */
{

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Do (void) { return this->Publish(); }; /* Specializes virtual method */
    virtual RET_STATUS Publish (void) = 0; /* Pure virtual method */

    /* Constructor methods */
    Publisher_Base (void) { this->SetInstanceType(OBJTYPE_SDN_PUBLISHER); return; };

    /* Destructor method */
   ~Publisher_Base (void) {};

}; 

class Publisher_Impl : public Publisher_Base
{

  private:

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Configure (void);
    RET_STATUS Publish (void);

    /* Constructor methods */
    Publisher_Impl (void) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Impl (Metadata_t& mdata) { /* Initialize resources */ this->Initialize(); this->SetMetadata(mdata); return; };
    Publisher_Impl (const char* name) { /* Initialize resources */ this->Initialize(); this->SetTopicName(name); return; };
    Publisher_Impl (Topic& topic) { /* Initialize resources */ this->Initialize(); /* WARNING - Topic externally instantiated should not be destroyed upon Participant destruction */ (this->m_base)->m_mdata = topic.m_meta; (this->m_base)->m_topic = &topic; (this->m_base)->m_ext_topic = true; return; };

    /* Destructor method */
   ~Publisher_Impl (void) { (this->m_disc)->Remove(this->m_base); if (this->m_base != NULL) delete (core::Publisher_Impl*) this->m_base; this->m_base = NULL; return; };

};
#if 0
typedef class Publisher_Asyn : public Publisher_Impl
{

  private:

    base::AnyThread* m_thread; /* Thread to manage publisher instance */

    uint64_t m_accuracy;
    bool m_synchronous;  /* Publication is triggered when topic is externally updated */
    volatile bool m_trigger;  /* Publication is triggered when topic is externally updated */

    void (* m_cb) (void*); /* Routine called before topic publication  */
    void* m_attr;          /* Routine attribute */

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */
    RET_STATUS Launch (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Launch(); return status; };
    RET_STATUS Terminate (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Terminate(); return status; };

    /* Accessor methods */
    RET_STATUS SetAffinity (uint_t core) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetAffinity(core); return status; };
    RET_STATUS SetCallback (void (* cb)(void*)) { this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { this->m_attr = attr; this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetPeriod (uint64_t period, int64_t phase = 0L, uint64_t accuracy = DEFAULT_THREAD_ACCURACY);
    RET_STATUS SetPriority (uint_t policy, uint_t priority) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetPriority(policy, priority); return status; };

    /* Miscellaneous methods */
    RET_STATUS Preamble (void) { return this->Configure(); };
    RET_STATUS Do (void);
    RET_STATUS Trigger (void) { return ((__sync_val_compare_and_swap(&(this->m_trigger), false, true)) ? STATUS_ERROR : STATUS_SUCCESS); };

    /* Constructor methods */
    Publisher_Asyn (void) : Publisher_Impl() { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (Metadata_t& mdata) : Publisher_Impl(mdata) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (char* name) : Publisher_Impl(name) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (Topic& topic) : Publisher_Impl(topic) { /* Initialize resources */ this->Initialize(); return; };

    /* Destructor method */
   ~Publisher_Asyn (void) { if (this->m_thread != NULL) delete this->m_thread; this->m_thread = NULL; return; };

} PublisherThread; /* For backward compatibility purposes with v1.0 */
#endif
/* Global variables */

/* Function declaration */

/* Function definition */
#if 0
static void Publisher_Asyn_Preamble (Publisher_Asyn* self) { if (self != NULL) self->Preamble(); return; };
static void Publisher_Asyn_CB (Publisher_Asyn* self) { if (self != NULL) self->Do(); return; };
#endif
/* Initializer methods */

void Publisher_Impl::Initialize (void)
{ 

  log_trace("Publisher_Impl::Initialize - Entering method");

  /* Initialize attributes */
  this->m_base = NULL; 

  /* Acquire resources */
  log_debug("Publisher_Impl::Initialize - Creating core::Publisher instance"); 
  this->m_base = (core::Participant_Impl*) new core::Publisher_Impl ();

  log_trace("Publisher_Impl::Initialize - Leaving method");

  return; 

}
#if 0
void Publisher_Asyn::Initialize (void)
{

  log_trace("Publisher_Asyn::Initialize - Entering method");

  /* Create thread instance */
  char thread_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  snprintf(thread_name, STRING_MAX_LENGTH, "Publisher_Asyn_%s", this->GetTopicName());

  this->m_thread = new base::AnyThread ((char*) thread_name);
  (this->m_thread)->SetPreamble((void (*) (void*)) &Publisher_Asyn_Preamble, (void*) this); 
  (this->m_thread)->SetCallback((void (*) (void*)) &Publisher_Asyn_CB, (void*) this);
  (this->m_thread)->SetPeriod(DEFAULT_PUBLISHER_PERIOD);

  this->m_cb = NULL; this->m_attr = NULL;
  this->m_accuracy = DEFAULT_PUBLISHER_WAIT_PERIOD;
  this->m_synchronous = false; this->m_trigger = false;

  log_trace("Publisher_Asyn::Initialize - Leaving method");

  return; 

};
#endif
/* Initializer methods */

/* Accessor methods */
    
bool Publisher_Iface::IsInitialized (void) { return (this->p_impl)->IsInitialized(); };
    
char* Publisher_Iface::GetInterface (void) { return (this->p_impl)->GetInterface(); };
char* Publisher_Iface::GetTopicName (void) { return (this->p_impl)->GetTopicName(); };
uint_t Publisher_Iface::GetTopicSize (void) { return (this->p_impl)->GetTopicSize(); };
    
RET_STATUS Publisher_Iface::SetInterface (const char* name) { return (this->p_impl)->SetInterface(name); };
RET_STATUS Publisher_Iface::SetTopicName (const char* name) { return (this->p_impl)->SetTopicName(name); };
RET_STATUS Publisher_Iface::SetMetadata (Metadata_t& mdata) { return (this->p_impl)->SetMetadata(mdata); };
    
RET_STATUS Publisher_Iface::CopyTopicInstance (void* instance, uint_t size) { return (this->p_impl)->CopyTopicInstance(instance, size); };
void* Publisher_Iface::GetTopicHeader (void) { return (this->p_impl)->GetTopicHeader(); };
void* Publisher_Iface::GetTopicFooter (void) { return (this->p_impl)->GetTopicFooter(); };
void* Publisher_Iface::GetTopicInstance (void) { return (this->p_impl)->GetTopicInstance(); };
    
RET_STATUS Publisher_Iface::SetCallback (void (* cb)(void*)) { return (this->p_impl)->SetCallback(cb); };
RET_STATUS Publisher_Iface::SetCallback (void (* cb)(void*), void* attr) { return (this->p_impl)->SetCallback(cb, attr); };
#if 0
RET_STATUS Publisher_Asyn::SetPeriod (uint64_t period, int64_t phase, uint64_t accuracy)
{ 

  RET_STATUS status = STATUS_ERROR; 

  if (period == 0L)
    {
      this->m_accuracy = accuracy;
      this->m_trigger = false;
      this->m_synchronous = true;
    }

  if (this->m_thread != NULL) 
    { 
      (this->m_thread)->SetAccuracy(accuracy); 
      (this->m_thread)->SetPhase(phase); 
      status = (this->m_thread)->SetPeriod(period); 
    } 

  return status; 

};
#endif
/* Miscellaneous methods */

RET_STATUS Publisher_Iface::Configure (void) 
{ 

  RET_STATUS status = STATUS_ERROR; 

  status = (this->p_impl)->Configure();

  /* For backward compatibility purposes with v1.0 */
  this->m_topic = ((this->p_impl)->m_base)->m_topic;
  this->m_packet = ((this->p_impl)->m_base)->m_packet; 
  if (this->m_packet != NULL) this->m_header = (this->m_packet)->GetHeader();
  if (this->m_packet != NULL) this->m_footer = (this->m_packet)->GetFooter();

  return status; 

};

RET_STATUS Publisher_Iface::Publish (void) { return (this->p_impl)->Publish(); };
    
RET_STATUS Publisher_Impl::Configure (void)
{ 

  log_trace("Publisher_Impl::Configure - Entering method");

  RET_STATUS status = STATUS_ERROR;

  /* Configure base class */
  if (Participant_Configure((Participant_Impl*) this) != STATUS_SUCCESS)
    {
      log_error("Publisher_Impl::Configure - Failed to configure participant"); 
      return status;
    }

  log_debug("Publisher_Impl::Configure - Configure core::Publisher instance");
  if ((this->m_base)->Configure() != STATUS_SUCCESS)
    {
      log_error("Publisher_Impl::Configure - Failed to configure core::Publisher instance"); 
      return status;
    }

  log_debug("Publisher_Impl::Configure - Notify disc::Publisher instance");
  (this->m_disc)->Register(this->m_base);

  status = STATUS_SUCCESS; 
  
  log_trace("Publisher_Impl::Configure - Leaving method");

  return status; 

};

RET_STATUS Publisher_Impl::Publish (void) 
{ 

  log_trace("Publisher_Impl::Publish - Entering method");

  RET_STATUS status = STATUS_ERROR;

  status = ((core::Publisher_Impl*) this->m_base)->Publish();

  log_trace("Publisher_Impl::Publish - Leaving method");

  return status;

};
#if 0
RET_STATUS Publisher_Asyn::Do (void)
{

  log_trace("Publisher_Asyn::Do - Entering method");

  RET_STATUS status = STATUS_ERROR;

  while ((this->m_synchronous == true) && (__sync_val_compare_and_swap(&(this->m_trigger), true, false) == false)) wait_for(this->m_accuracy);

  if (this->GetTopicInstance() == NULL)
    {
      log_debug("Publisher_Asyn::Do - Skip execution - No topic instance defined");
      return status;
    }

  /* ToDo - Should be waiting for external trigger in case of synchronous operation */

  /* Callback, if any */
  if (this->m_cb != NULL) (*(this->m_cb))(this->m_attr);

  if (this->Publish() != STATUS_SUCCESS)
    {
      log_warning("Publisher_Asyn::Do - Publisher::Publish failed");
    }
  else 
    {
      log_debug("Publisher_Asyn::Do - Publisher::Publish successful at '%lu'", get_time());

      status = STATUS_SUCCESS;
    }

  log_trace("Publisher_Asyn::Do - Leaving method");

  return status; 

};
#endif
/* Constructor methods */

Publisher_Iface::Publisher_Iface (void)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl ();

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (Metadata_t& mdata)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (mdata);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (const char* name)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (name);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (Topic& topic)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (topic);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

/* Destructor method */

Publisher_Iface::~Publisher_Iface (void)
{
        
  log_trace("Publisher_Iface::~Publisher_Iface - Entering method");
        
  /* Release resources */
  if (this->p_impl != NULL) delete this->p_impl; this->p_impl= NULL;
        
  log_trace("Publisher_Iface::~Publisher_Iface - Leaving method");
        
  return;
        
};

/* Display methods */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
