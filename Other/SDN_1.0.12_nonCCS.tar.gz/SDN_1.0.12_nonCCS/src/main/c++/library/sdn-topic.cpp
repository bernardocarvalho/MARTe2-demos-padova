/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/sdn-topic.cpp $
* $Id: sdn-topic.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

#include <libxml/tree.h>
//#include <libxml/parser.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "sdn-topic.h" /* This class definition */

/* Constants */

#undef DEFAULT_TOPIC_NAME
#define DEFAULT_TOPIC_NAME "reserved"

//#define DEFAULT_TOPIC_PATH "${CODAC_ROOT}/apps/include"
//#define SDN_TOPIC_PATH_ENV "${SDN_TOPIC_DIRECTORY}"
#define DEFAULT_TOPIC_PATH "${CODAC_CONF}/sdn"
#define SDN_TOPIC_PATH_ENV "${SDN_TOPIC_PATH}"

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::topic"

namespace sdn {

/* Type definition */

/* Global variables */

/* Bug 8874 - SDN_TOPIC_PATH variable does not allow for values above 64 characters */
static char _path_list [] [PATH_MAX_LENGTH] = 
{

  "${SDN_TOPIC_PATH}",
  "${CODAC_CONF}/sdn", 
  "${CODAC_CONF}/default", 
  "/tmp", 
  "./target/main/resources", 
  "./target/test/resources", 
  "../../../main/resources", 
  "../../resources", 
  ".", 
  EOT_KEYWORD

};

static char _suff_list [] [STRING_MAX_LENGTH] = 
{

  "",
  ".xml",
  "_typedef.xml",
  EOT_KEYWORD

};

/* Function declaration */

/* Function definition */

/* Initializer methods */

RET_STATUS Topic::AddAttribute (uint_t rank, const char* name, const char* type, uint_t mult) 
{ 

  RET_STATUS status = STATUS_ERROR; 

  if (this->m_type_def != NULL) 
    { 
      char rank_str [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
      char mult_str [STRING_MAX_LENGTH] = STRING_UNDEFINED; 

      snprintf((char*) mult_str, STRING_MAX_LENGTH, "%u", mult); 

      status = (this->m_type_def)->AddAttribute(rank_str, (char*) name, (char*) type, mult_str); 

    } 

  this->SetUID(); 

  return status; 

};

void Topic::ClearInstance (void)
{ 

  if (this->m_instance != NULL) memset(this->m_instance, 0, this->GetSize()); 

  /* Delegate to AnyType instance, if possible */
  if ((this->m_type_def != NULL) && ((this->m_type_def)->IsInitialized() == true)) (this->m_type_def)->ClearInstance();

  return; 

};

RET_STATUS Topic::CreateInstance (void) 
{

  RET_STATUS status = STATUS_ERROR;

  log_trace("Topic::CreateInstance - Entering method");

  /* Delegate to AnyType instance, if possible */
  if ((this->m_type_def != NULL) && ((this->m_type_def)->IsInitialized() == true) && ((status = (this->m_type_def)->CreateInstance()) == STATUS_SUCCESS))
    {
      this->m_instance = (uint8_t*) (this->m_type_def)->GetInstance();
      status = STATUS_SUCCESS;
    }

  /* Do it if only if size is known */
  if ((this->GetSize() != 0) && (this->m_instance == NULL))
    {
      this->m_instance = new uint8_t [this->GetSize()];
      this->m_allocated = true;
      status = STATUS_SUCCESS;
    }

  if (status != STATUS_SUCCESS) log_error("Unable to instantiate '%s' topic - Not enough information available", this->GetName());

  log_trace("Topic::CreateInstance - Leaving method");

  return status;

};

RET_STATUS Topic::Configure (void)
{

  RET_STATUS status = STATUS_ERROR;

  log_trace("Topic::Configure - Entering method");

  /* Initialize attributes */
  char file_path [PATH_MAX_LENGTH] = STRING_UNDEFINED;

  /* Bug 9354 - Support defining topic using name and size in absence of XML definition file */
  if (AnyType_LocateTypeDefinition(this->GetName(), (char*) file_path, PATH_MAX_LENGTH) == STATUS_SUCCESS)
    {
      AnyType_LoadTypeDefinition(this->m_type_def, file_path);
    }
  else if ((this->m_type_def)->IsDefined() != true)
    {
      log_warning("Unable to locate '%s' type definition file", this->GetName());
      this->SetUID(); /* Needed for subscriber who fail to load XML file */

      log_notice("Topic '%s' defined by size '%u' only", this->GetName(), this->GetSize());
      (this->m_type_def)->ccs::base::AnyType::AddAttribute(0, (char*) "undefined", this->GetSize());
      (this->m_type_def)->AnyType::AddExtAttribute(NULL, (char*) "undefined", NULL, NULL, NULL, NULL);
    }
  else
    {

      log_notice("Topic '%s' type definition done in absence of file", this->GetName());

      uint_t size = (this->m_type_def)->GetSize();

      if ((this->GetSize() == 0) && (size != 0))
	{
	  this->SetSize(size);
	  log_notice("Topic '%s' size inferred from datatype definition '%u'", this->GetName(), this->GetSize());
	}

      if ((this->GetSize() != 0) && (size != 0) && (this->GetSize() != size))
	{
	  log_warning("Topic '%s' size mismatch between metadata '%u' and datatype definition '%u'", this->GetName(), this->GetSize(), size);
	  this->SetSize(size);
	  log_notice("Topic '%s' size inferred from datatype definition '%u'", this->GetName(), this->GetSize());
	}

    }

  this->m_instance = NULL;

  this->m_allocated = false;

  /* Check validity of metadata */
  if (Topic_IsMetadataValid(this->m_meta) != true)
    {
      log_error("Invalid '%s' topic definition", this->GetName());
      return status;
    }

  /* Try and locate topic definition file */

  log_debug("Try and load '%s' topic definition", this->GetName());

  if (Topic_LocateDefinitionFile(this->GetName(), (char*) file_path, PATH_MAX_LENGTH) != STATUS_SUCCESS)
    {
      log_warning("Unable to locate '%s' topic definition file", this->GetName());
    }
  else
    {
      log_debug("Located '%s' topic definition file at '%s'", this->GetName(), (char*) file_path);
    }

  if (this->Load((char*) file_path) != STATUS_SUCCESS) 
    {
      log_warning("Unable to load topic definition file '%s'", (char*) file_path);
    }
  else
    {
      log_debug("Loaded topic definition file '%s'", (char*) file_path);
    }

  status = STATUS_SUCCESS;

  log_trace("Topic::Configure - Leaving method");

  return status;

}

void Topic::Initialize (void)
{

  log_trace("Topic::Initialize - Entering method");

  /* Initialize attributes */
  Topic_InitializeMetadata(this->m_meta);

  this->m_type_def = new sdn::base::AnyType;;
  this->m_instance = NULL;

  this->m_allocated = false;

  log_trace("Topic::Initialize - Leaving method");

  return;

}

RET_STATUS Topic::Load (const char* file_path)
{

  log_trace("Topic::Load('%s') - Entering method", file_path);

  RET_STATUS status = STATUS_ERROR;

  /* Check file existence */
  if (exist((char*) file_path) != true)
    {
      log_error("Unable to locate topic definition file '%s'", file_path);
      return status;
    }

  /* Rely on libxml2 to load and parse type definition file */

  xmlInitParser();
  LIBXML_TEST_VERSION;

  xmlDocPtr xDoc = xmlParseFile(file_path);

  if (xDoc == NULL) 
    {
      log_error("Unable to parse file '%s'", file_path);
      return status;
    }
  else 
    {
      xmlNodePtr xCurNode = xmlDocGetRootElement(xDoc);

      char topic_name [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
      char topic_iden [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
      char topic_vers [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
      char topic_size [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
      char topic_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED; 

      xmlChar* prop; 

      if (xmlHasProp(xCurNode, (xmlChar*) "name") != NULL)    { prop = xmlGetProp(xCurNode, (xmlChar*) "name");    sstrncpy((char*) topic_name, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); }
      if (xmlHasProp(xCurNode, (xmlChar*) "uid") != NULL)     { prop = xmlGetProp(xCurNode, (xmlChar*) "uid");     sstrncpy((char*) topic_iden, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); }
      if (xmlHasProp(xCurNode, (xmlChar*) "version") != NULL) { prop = xmlGetProp(xCurNode, (xmlChar*) "version"); sstrncpy((char*) topic_vers, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); }
      if (xmlHasProp(xCurNode, (xmlChar*) "size") != NULL)    { prop = xmlGetProp(xCurNode, (xmlChar*) "size");    sstrncpy((char*) topic_size, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };
      if (xmlHasProp(xCurNode, (xmlChar*) "mapping") != NULL) { prop = xmlGetProp(xCurNode, (xmlChar*) "mapping"); sstrncpy((char*) topic_addr, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };

      /* Shutdown libxml */
      xmlFreeDoc(xDoc);
      xmlCleanupParser();
      xmlMemoryDump();

      /* Must have 'name' and 'version' properties */
      if (IsUndefined(topic_name) || IsUndefined(topic_vers))
	{
	  log_error("Topic definition does not conform to expected syntax");
	  return status;
	}
  
      /* Check topic name */
      if (strcmp(this->GetName(), (char*) topic_name) != 0)
	{
	  log_warning("Topic name mismatch '%s %s'", this->GetName(), (char*) topic_name);
	  this->SetName((char*) topic_name);
	}

      /* Store recovered attributes */
      this->SetVersion((char*) topic_vers);
      
      if (IsUndefined(topic_iden) != true) this->SetUID(topic_iden);
      if (IsUndefined(topic_size) != true) this->SetSize(topic_size);
#if 0 /* sdn::Topic::Initialize() already has verified Metadata_t and generated MCAST from topic name if not specified */
      if (IsUndefined(topic_addr) == true)
	{
	  log_notice("Generate topic mapping from hash table");
	  Topic_GenerateMCastAddress(this->m_meta);
	}
      else 
#else
      if (IsUndefined(topic_addr) != true) /* Use topic definition file address if available */
#endif
	{
	  char* p_char = topic_addr;
	  char* p_addr = topic_addr;
	  /* Put a zero in lieu of ':' */
	  while (*p_char != ':') p_char += 1; *p_char = 0; 
	  this->SetMCastGroup(p_addr); 
	  p_addr = p_char + 1;
	  this->SetMCastPort(p_addr); 
	}
    }

  status = STATUS_SUCCESS;

  uint_t hash = ((this->m_type_def == NULL) ? 0 : (this->m_type_def)->SerializeType());

  if ((this->GetUID() == 0) && (hash != 0))
    {
      this->SetUID(hash);
      log_notice("Topic '%s' uid inferred from datatype definition '%u'", this->GetName(), this->GetUID());
    }

  if ((this->GetUID() != 0) && (this->GetUID() != hash))
    {
      log_warning("Topic '%s' uid mismatch between metadata '%u' and datatype definition '%u'", this->GetName(), this->GetUID(), hash);
    }

  uint_t size = ((this->m_type_def == NULL) ? 0 : (this->m_type_def)->GetSize());

  if ((this->GetSize() == 0) && (size != 0))
    {
      this->SetSize(size);
      log_notice("Topic '%s' size inferred from datatype definition '%u'", this->GetName(), this->GetSize());
    }

  if ((this->GetSize() != 0) && (size != 0) && (this->GetSize() != size))
    {
      log_warning("Topic '%s' size mismatch between metadata '%u' and datatype definition '%u'", this->GetName(), this->GetSize(), size);
      this->SetSize(size);
      log_notice("Topic '%s' size inferred from datatype definition '%u'", this->GetName(), this->GetSize());
    }

  /* Bug 9249 - Natural payload size limit for SDN over UDP/IPv4 */
  if (this->GetSize() > MAX_TOPIC_SIZE)
    {
      log_warning("Topic '%s' size '%u' is invalid - Payload limited to '%u'", this->GetName(), this->GetSize(), MAX_TOPIC_SIZE); 
    }

  log_info("Loaded topic definition - '%s [%s:%d]' of size '%u' and version '%u'", this->GetName(), this->GetMCastGroup(), this->GetMCastPort(), this->GetSize(), this->GetVersion());

  {
    char buffer [2048]; this->SerializeType(buffer, 2048);
    log_debug("Loaded topic definition '%s'", buffer);
  }

  log_trace("Topic::Load('%s') - Leaving method", file_path);

  return status;

};

/* Accessor methods */

char* Topic::HasInstanceIndex (void) 
{ 

  char* p_attr = NULL;

  if (this->m_type_def == NULL) return p_attr;

  for (uint_t index = 0; index < (this->m_type_def)->GetRank(); index += 1) 
    { 
      char* p_qual = (this->m_type_def)->GetAttributeQualifier(index); 
#if 0
      if (p_qual != NULL) log_debug("Topic::HasInstanceIndex - Attribute '%u' has qualifier '%s %p'", index, p_qual, p_qual);
      else log_debug("Topic::HasInstanceIndex - Attribute '%u' does not have a qualifier", index);
#endif
      if ((p_qual != NULL) && (strcmp(p_qual, "samplenb") == 0)) 
	{
	  p_attr = (this->m_type_def)->GetAttributeName(index); 
	  log_debug("Topic::HasInstanceIndex - Found attribute '%s'", p_attr);
	  break;
	}
    } 

  return p_attr; 

};

char* Topic::HasInstanceTimestamp (void) 
{ 

  char* p_attr = NULL;

  if (this->m_type_def == NULL) return p_attr;

  for (uint_t index = 0; index < (this->m_type_def)->GetRank(); index += 1) 
    { 
      char* p_qual = (this->m_type_def)->GetAttributeQualifier(index); 
#if 0
      if (p_qual != NULL) log_debug("Topic::HasInstanceTimestamp - Attribute '%u' has qualifier '%s %p'", index, p_qual, p_qual);
      else log_debug("Topic::HasInstanceTimestamp - Attribute '%u' does not have a qualifier", index);
#endif
      if ((p_qual != NULL) && (strcmp(p_qual, "timestamp") == 0)) 
	{
	  p_attr = (this->m_type_def)->GetAttributeName(index); 
	  log_debug("Topic::HasInstanceTimestamp - Found attribute '%s'", p_attr);
	  break;
	}
    } 

  return p_attr; 

};

void Topic::GetMetadata (Metadata_t& mdata) { mdata = this->m_meta; return; };
void Topic::SetMetadata (Metadata_t& mdata) { this->m_meta = mdata; return; };

bool Topic::IsName (const char* name) { return ((strcmp((char*) this->m_meta.name, name) == 0) ? true : false); };
char* Topic::GetName (void) { return (char*) this->m_meta.name; };
void Topic::SetName (const char* name) { sstrncpy(this->m_meta.name, name, STRING_MAX_LENGTH); return; };

uint_t Topic::GetInstanceChecksum (void)
{ 

  uint32_t chksum = ((this->GetInstance() != NULL) ? crc((uint8_t*) this->GetInstance(), this->GetSize()) : 0); 

  log_debug("Topic::GetInstanceChecksum - Instance checksum is '%u' (over '%p' reference and '%u' size)", chksum, this->GetInstance(), this->m_meta.size); 

  return (uint_t) chksum; 

};

uint_t Topic::GetSize (void) { return this->m_meta.size; };
void Topic::SetSize (uint_t size) { this->m_meta.size = size; return; };
void Topic::SetSize (const char* size_str) { sscanf(size_str, "%u", &(this->m_meta.size)); return; };

uint_t Topic::GetUID (void) { return this->m_meta.hash; };
void Topic::SetUID (uint_t hash) { this->m_meta.hash = hash; return; };
void Topic::SetUID (const char* uid_str) { sscanf(uid_str, "%u", &(this->m_meta.hash)); return; };

void Topic::SetUID (void) 
{ 

  log_trace("Topic::SetUID - Entering method");
#if 0
  uint_t hash = ((this->m_type_def == NULL) ? 0 : (this->m_type_def)->SerializeType()); 
#else
  char buffer [2048] = STRING_UNDEFINED;
  uint_t hash = ((this->m_type_def == NULL) ? 0 : (this->m_type_def)->SerializeType(buffer, 2048));
  log_info("Topic::SetUID - Serialized datatype is '%s'", buffer);
#endif
  log_info("Topic::SetUID - Hash is '%u'", hash);

  log_trace("Topic::SetUID - Leaving method");

  return this->SetUID(hash); 

};

uint_t Topic::GetVersion (void) { return this->m_meta.vers; };
void Topic::SetVersion (const char* vers) { sscanf(vers, "%u", &(this->m_meta.vers)); return; };
void Topic::SetVersion (uint_t vers) { this->m_meta.vers = vers; return; };

char* Topic::GetMCastGroup (void) { return (char*) this->m_meta.mcast_group; };
void Topic::SetMCastGroup (const char* group) { sstrncpy(this->m_meta.mcast_group, group, MAX_IP_ADDR_LENGTH); return; }; /* Warning - Size of string */
  
uint_t Topic::GetMCastPort (void) { return this->m_meta.mcast_port; };
void Topic::SetMCastPort (uint_t port) { this->m_meta.mcast_port = port; return; };
void Topic::SetMCastPort (const char* port_str) { sscanf(port_str, "%d", &(this->m_meta.mcast_port)); return; };

void* Topic::GetInstance (void) { return (void*) this->m_instance; };

void Topic::SetInstance (void* instance) 
{ 

  log_trace("Topic::SetInstance - Entering method");

  log_debug("Topic::SetInstance - Reference is '%p'", instance);

  this->m_instance = (uint8_t*) instance; if (this->m_type_def != NULL) (this->m_type_def)->SetInstance(instance); 

  log_trace("Topic::SetInstance - Leaving method");

  return;

};

/* Miscellaneous methods */

RET_STATUS Topic_LocateDefinitionFile (const char* name, char* file_path, uint_t max_size)
{

  log_trace("%s - Entering method", __FUNCTION__);

  RET_STATUS status = STATUS_ERROR;

  if (name == NULL) return status;

  if (file_path == NULL)
    {
      char tmp [1024];
      file_path = (char*) tmp; max_size = 1024;
    }

  char file_name [PATH_MAX_LENGTH];

  bool found = false;

  uint_t path_index = 0;

  while (strncmp(_path_list[path_index], EOT_KEYWORD, PATH_MAX_LENGTH) != 0)
    {
      char* conf_path = _path_list[path_index];

      log_debug("%s - Try and resolve path '%s'", __FUNCTION__, conf_path); 

      if (resolve_variable_path(conf_path) != STATUS_SUCCESS)
	{
	  log_error("Unable to resolve path '%s'", conf_path);
	  continue;
	}
      else
	{
	  log_debug("%s - Path resolves to '%s'", __FUNCTION__, conf_path);
	}

      uint_t suff_index = 0;

      while (strncmp(_suff_list[suff_index], EOT_KEYWORD, PATH_MAX_LENGTH) != 0)
	{
	  char* suffix = _suff_list[suff_index];

	  if (exist((char*) conf_path, (char*) name, (char*) suffix) == true)
	    {
	      found = true;

	      snprintf(file_name, PATH_MAX_LENGTH, "%s%s", name, (char*) suffix);

	      log_debug("%s - Load '%s' topic definition file from '%s'", __FUNCTION__, name, conf_path);

	      snprintf(file_path, PATH_MAX_LENGTH, "%s/%s", conf_path, file_name);

	      break;
	    }

	  suff_index += 1;
	}

      if (found == true) 
	{
	  /* No need to search further */
	  log_debug("%s - Located '%s' topic definition file", __FUNCTION__, file_path);
	  status = STATUS_SUCCESS;
	  break;
	}

      path_index += 1;
    }

  if (found != true) log_error("Unable to locate '%s' topic definition file", name);

  log_trace("%s - Leaving method", __FUNCTION__);

  return status;

};

RET_STATUS Topic_GenerateMCastAddress (Metadata_t& mdata) 
{ 

  log_trace("%s - Entering method", __FUNCTION__);

  RET_STATUS status = STATUS_ERROR;

  if (IsUndefined((char*) mdata.name) == true) return status;

  uint16_t key = hash((char*) mdata.name); 
  uint8_t c = (key >> 8) ^ 255; 
  uint8_t d = key ^ 255;

  snprintf((char*) mdata.mcast_group, MAX_IP_ADDR_LENGTH, "239.0.%d.%d", c, d);
#if 0 /* Bug 9225 - Ports below 1024 require superuser priviledges */
  if (key == 0) key = 10000; /* Port 0 is invalid */
#else
  if (key < 1024) 
    { 
      log_notice("Interoperability risk - The generated port '%u' will be altered with respect to previous unit versions (< v1.0.6)", key);
      key += 10000;
    }
#endif
  mdata.mcast_port = key;

  status = STATUS_SUCCESS;

  log_trace("%s - Leaving method", __FUNCTION__);

  return status;

};

bool Topic_IsMetadataValid (Metadata_t& mdata)
{

  log_trace("%s - Entering method", __FUNCTION__);

  if (IsUndefined((char*) mdata.name) == true) return false; /* Must have name defined */

  if ((mdata.size == 0) && (Topic_LocateDefinitionFile((char*) mdata.name, NULL) != STATUS_SUCCESS)) return false; /* Must have size defined or be backed-up by a topic definition file */

  /* Bug 9249 - Natural payload size limit for SDN over UDP/IPv4 */
  if (mdata.size > MAX_TOPIC_SIZE)
    {
      log_error("Topic size '%u' is invalid - Payload limited to '%u'", mdata.size, MAX_TOPIC_SIZE); 
      return false;
    }

  /* Generate MCastAddress if necessary */
  if ((IsUndefined((char*) mdata.mcast_group) == true) || (Topic_IsAddressValid(mdata) != true))
    {
      log_notice("Generate topic mapping from hash table");
      Topic_GenerateMCastAddress(mdata);
    }

  if (mdata.mcast_port == 0)
    {
      log_error("Topic mapping can not be using port '0'");
      return false;
    }

  /* Bug 9225 - Ports below 1024 require superuser priviledges */
  if (mdata.mcast_port < 1024)
    {
      log_warning("Topic mapping is using port '%u' in a restricted range which requires superuser priviledges", mdata.mcast_port);
    }

  log_trace("%s - Leaving method", __FUNCTION__);

  return true;

};

void Topic_InitializeMetadata (Metadata_t& mdata) { memset((void*) &mdata, 0, sizeof(Metadata_t)); return; };
void Topic_InitializeMetadata (Metadata_t& mdata, const char* name) 
{ 

  Topic_InitializeMetadata(mdata); 

  if (strncmp(name, "sdn://", 6) == 0) 
    {

      char buffer [STRING_MAX_LENGTH] = STRING_UNDEFINED; sstrncpy((char*) buffer, (char*) name + 6, STRING_MAX_LENGTH);

      char* p_addr = buffer;

      /* Put a zero in lieu of ':' */
      char* p_char = buffer; while ((*p_char != ':') && (*p_char != 0)) p_char += 1; *p_char = 0;

      if (sdn_is_address_valid(p_addr) == true) 
	{
	  //log_debug("%s - Address '%s' is valid", __FUNCTION__, p_addr);
	  sstrncpy(mdata.mcast_group, p_addr, MAX_IP_ADDR_LENGTH); 
	}

      p_addr = p_char + 1; /* The port number */

      /* Put a zero in lieu of '/' */
      p_char = p_addr; while ((*p_char != '/') && (*p_char != 0)) p_char += 1; *p_char = 0;

      //log_debug("%s - Parsing '%s' as port", __FUNCTION__, p_addr);
      sscanf(p_addr, "%u", &(mdata.mcast_port));

      p_addr = p_char + 1; /* The actual topic name */

      //log_debug("%s - Parsing '%s' as topic name", __FUNCTION__, p_addr);
      sstrncpy((char*) mdata.name, p_addr, STRING_MAX_LENGTH);

    }
  else sstrncpy((char*) mdata.name, (char*) name, STRING_MAX_LENGTH); 

  return; 

};

void Topic_InitializeMetadata (Metadata_t& mdata, const char* name, uint_t size) { Topic_InitializeMetadata(mdata, name); mdata.size = size; return; };
void Topic_InitializeMetadata (Metadata_t& mdata, const char* name, uint_t size, const char* addr, uint_t port)
{ 

  Topic_InitializeMetadata(mdata, name, size); mdata.mcast_port = port; 

  if (sdn_is_address_valid(addr) == true)
    {

      char buffer [STRING_MAX_LENGTH] = STRING_UNDEFINED; sstrncpy((char*) buffer, (char*) addr, STRING_MAX_LENGTH);

      /* The address may include the port in the form '<addr>:<port>' */
      bool found = false; char* p_char = buffer; while ((*p_char != ':') && (*p_char != 0)) p_char += 1; if (*p_char ==  ':') found = true;

      if (found == true)
	{
	  /* Put a zero in lieu of ':' */
	  *p_char = 0; 
	  char* port_str = p_char + 1; /* The port number */

	  sstrncpy(mdata.mcast_group, (char*) buffer, MAX_IP_ADDR_LENGTH); 
	  sscanf(port_str, "%u", &(mdata.mcast_port));
	}
      else sstrncpy(mdata.mcast_group, (char*) addr, MAX_IP_ADDR_LENGTH); 

    }

  return; 

};

void Topic_InitializeMetadata (Metadata_t& mdata, const char* name, uint_t size, uint_t vers) { Topic_InitializeMetadata(mdata, name, size); mdata.vers = vers; return; };

/* Constructor methods */

Topic::Topic (void)
{

  log_trace("Topic::Topic - Entering method");

  /* Initialize attributes */
  this->Initialize();

  this->SetName((char*) DEFAULT_TOPIC_NAME); /* Topic name */
  this->SetSize((uint_t) 0); /* Topic datatype size  */
  this->SetUID((uint_t) 0); /* Topic UID  */
  this->SetVersion((uint_t) 0); /* Topic version  */
  this->SetMCastGroup((char*) DEFAULT_MCAST_GROUP); /* Topic multicast group */
  this->SetMCastPort(DEFAULT_MCAST_PORT); /* Topic multicast port */
#if 0 /* That above may be defined programmatically and sdn::Topic::Configure called as well */
  /* Initialize topic instance */
  if (this->Configure() != STATUS_SUCCESS) log_warning("Unable to initialize '%s' topic", this->GetName());
#endif
  log_trace("Topic::Topic - Leaving method");

  return;

}

Topic::Topic (Metadata_t& mdata)
{

  log_trace("Topic::Topic('%s') - Entering method", mdata.name);

  /* Initialize attributes */
  this->Initialize();

  Topic_InitializeMetadata(this->m_meta);

  this->m_meta = mdata; /* Set metadata */

  /* Initialize topic instance */
  if (this->Configure() != STATUS_SUCCESS) log_warning("Unable to initialize '%s' topic", this->GetName());
  else mdata = this->m_meta;

  log_trace("Topic::Topic('%s') - Leaving method", mdata.name);

  return;

}

Topic::Topic (const char* name)
{

  log_trace("Topic::Topic('%s') - Entering method", name);

  /* Initialize attributes */
  this->Initialize();

  this->SetName(name); /* Topic name */

  /* Initialize topic instance */
  if (this->Configure() != STATUS_SUCCESS) log_warning("Unable to initialize '%s' topic", this->GetName());

  log_trace("Topic::Topic('%s') - Leaving method", name);

  return;

}

/* Destructor method */

Topic::~Topic (void)
{

  log_trace("Topic::~Topic - Entering method");

  /* Delete topic instance, if necessary */
  log_info("Delete '%s' topic instance", this->GetName()); this->DeleteInstance();

  /* Release resources */
  if (this->m_type_def != NULL) delete this->m_type_def;

  /* Clear attributes */
  Topic_InitializeMetadata(this->m_meta);
  this->m_type_def = NULL;

  log_trace("Topic::~Topic - Leaving method");

  return;

}

/* Display methods */

uint_t Topic::SerializeType (char* buffer, int max_size)
{

  log_trace("Topic::SerializeType - Entering method");

  uint_t hash = 0;

  /* WARNING - Unsafe implementation */

  if (buffer == NULL) /* Only interested in hash key */
    {
      char tmp [2048];
      buffer = (char*) tmp; max_size = 2048;
    }

  /* WARNING - Check if size could be negative - yes in case snprintf truncates ... does not append zero  ... and the buffer is not cleared */

  /* Zero the buffer */
  memset(buffer, 0, max_size); max_size -= 1; /* Make sure the buffer is zero'ed (and the trailing zero won't get overwrittent) so as to avoid strlen failure in case snprintf truncates */

  char* p_buf = buffer;

  if (this->IsInitialized() != true) 
    {
      sstrncpy(p_buf, (char*) "</topic>", max_size);
      return hash;
    }

  snprintf(p_buf, max_size, "<topic name=\"%s\"", this->GetName()); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  if (this->GetUID() != 0)
    {
      snprintf(p_buf, max_size, " uid=\"%u\"", this->GetUID()); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
    }

  if (this->GetVersion() != 0)
    {
      snprintf(p_buf, max_size, " version=\"%u\"", this->GetVersion()); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
    }

  snprintf(p_buf, max_size, " size=\"%u\" mapping=\"%s:%u\"", this->GetSize(), this->GetMCastGroup(), this->GetMCastPort()); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  if ((this->m_type_def != NULL) && ((this->m_type_def)->IsInitialized() == true))
    {
      sstrncpy(p_buf, (char*) ">", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      /* Serialize datatype definition */
      hash = (this->m_type_def)->SerializeType(p_buf, max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
      
      /* Terminate buffer */
      sstrncpy(p_buf, (char*) "</topic>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
    }
  else /* The topic datatype has not been defined */
    {
      /* Terminate buffer */
      sstrncpy(p_buf, (char*) "/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
    }

  log_trace("Topic::SerializeType - Leaving method");

  return hash; /* Hask key from datatype definition, if any */

};

RET_STATUS Topic::SerializeInstance (char* buffer, int max_size) 
{

  log_trace("Topic::SerializeInstance - Entering method");

  if (this->IsInitialized() != true)
    {
      sstrncpy(buffer, (char*) "</value>", max_size); 
      return STATUS_SUCCESS;
    }

  /* WARNING - Check if size could be negative */

  if ((this->m_type_def != NULL) && ((this->m_type_def)->IsInitialized() == true))
    {
      (this->m_type_def)->SerializeInstance(buffer, max_size); 
    }
  else
    {
      /* Use base64 encoding */
      char* p_buf = buffer; sstrncpy(p_buf, (char*) "<value encoding=\"base64\">", max_size); max_size -= strlen(p_buf); p_buf = buffer + strlen(buffer); /* Re-align pointer */
      base64_encode((uint8_t*) this->m_instance, this->GetSize(), p_buf, max_size); max_size -= strlen(p_buf); p_buf = buffer + strlen(buffer); /* Re-align pointer */
      sstrncpy(p_buf, (char*) "</value>", max_size); 
    }

  log_trace("Topic::SerializeInstance - Leaving method");

  return STATUS_SUCCESS;

};

}; /* namespace sdn */

#undef LOG_ALTERN_SRC

