/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/sdn-msg.cpp $
* $Id: sdn-msg.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-msg.h" /* This class definition */

/* Constants */

/* Type definition */

namespace sdn {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

/* Accessor methods */

/* Miscellaneous methods */

RET_STATUS DiscoveryMsg::Parse (void* buffer)
{

  RET_STATUS status = STATUS_ERROR;

  if (this->IsValid(buffer) != true) return status;

  if (this->m_copy == NULL) this->m_copy = new uint8_t [this->Message::GetSize()];

  memcpy(this->m_copy, buffer, this->Message::GetSize());

  this->m_cmd = NULL;
  this->m_resp = NULL;
  this->m_host = NULL;
  this->m_part = NULL;
  this->m_role = NULL;
  this->m_size = NULL;
  this->m_topic = NULL;
  this->m_version = NULL;
  this->m_mcast_group = NULL;
  this->m_mcast_port = NULL;
  
  char* temp_ptr = NULL;
  char* next_ptr = NULL;

  /* Discard */
  next_ptr = strtok_r((char*) this->m_copy, (const char*) "\n", &temp_ptr); /* Protocol version */ //log_debug("Parse line '%s'", next_ptr);
  next_ptr = strtok_r(NULL, (const char*) "\n", &temp_ptr); /* Discovery message */                //log_debug("Parse line '%s'", next_ptr);

  /* Command */
  next_ptr = strtok_r(NULL, (const char*) "\n", &temp_ptr); this->m_cmd = next_ptr + 4;            //log_debug("Parse line '%s'", next_ptr);
  
  /* Topic name */
  next_ptr = strtok_r(NULL, (const char*) "\n", &temp_ptr); this->m_topic = next_ptr + 6;          //log_debug("Parse line '%s'", next_ptr);

  while ((next_ptr = strtok_r(NULL, (const char*) "\n", &temp_ptr)) != NULL)
    {
      //log_debug("Parse line '%s'", next_ptr);

      if (this->IsQuery() == true)
	{
	  this->m_role = NULL; continue;
	}

      char* p_char = next_ptr;

      /* Try and find role */
      while (*p_char != 0)
	{
	  if (strncmp(p_char, "HOST", 4) == 0) 
	    {
	      this->m_host = p_char + 5; while (*p_char != ';') p_char += 1; *p_char = 0; log_debug("sdn_discovery_msg::Parse - Host found '%s'", this->m_host);
	    }

	  if (strncmp(p_char, "APP", 3) == 0) 
	    {
	      this->m_part = p_char + 4; while (*p_char != ';') p_char += 1; *p_char = 0; log_debug("sdn_discovery_msg::Parse - ... '%s'", this->m_part); 
	    }

	  if (strncmp(p_char, "ROLE", 4) == 0) 
	    {
	      this->m_role = p_char + 5; *(this->m_role + 3) = 0; break;
	    }

	  if (strncmp(p_char, "ISRSP", 5) == 0) 
	    {
	      this->m_resp = p_char + 6; *(this->m_resp + 1) = 0; break;
	    }
#if 1
	  if (strncmp(p_char, "TVER", 4) == 0) 
	    {
	      this->m_version = p_char + 5; while (*p_char != ';') p_char += 1; *p_char = 0; p_char += 1;
	      log_debug("Found topic version '%s'", this->m_version);
	    }

	  if (strncmp(p_char, "PLSIZE", 6) == 0) 
	    {
	      this->m_size = p_char + 7; while (*p_char != ';') p_char += 1; *p_char = 0; p_char += 1; break;
	      log_debug("Found payload size '%s'", this->m_size);
	    }

	  if (strncmp(p_char, "ADDR", 4) == 0) 
	    { /* strtok_r has already replaced '\n' with '0' */
	      this->m_mcast_group = p_char + 5; /* while (*p_char != '\n') p_char += 1; *p_char = 0; p_char += 1; */ break;
	      log_debug("Found MCAST group '%s'", this->m_mcast_group);
	    }

	  if (strncmp(p_char, "PORT", 4) == 0) 
	    { /* strtok_r has already replaced '\n' with '0' */
	      this->m_mcast_port = p_char + 5; /* while (*p_char != '\n') p_char += 1; *p_char = 0; p_char += 1; */ break;
	      log_debug("Found MCAST port '%s'", this->m_mcast_port);
	    }
#endif
	  p_char += 1;
	}
    }

  status = STATUS_SUCCESS;

  return status;

};

/* Constructor methods */

QueryMsg::QueryMsg (void) { sstrncpy((char*) this->m_topic_name, (char*) "ALL", STRING_MAX_LENGTH); return; };
QueryMsg::QueryMsg (char* topic) { sstrncpy((char*) this->m_topic_name, topic, STRING_MAX_LENGTH); return; };

/* Destructor method */

/* Display methods */

}; /* namespace sdn */
