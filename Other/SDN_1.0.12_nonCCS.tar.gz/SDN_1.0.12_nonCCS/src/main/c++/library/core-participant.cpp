/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/core-participant.cpp $
* $Id: core-participant.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
//#include "sdn-core.h" /* SDN core library - API definition (sdn::core) */

#include "sdn-topic.h"
#include "sdn-packet.h"

#include "core-participant.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::core"

/* Type definition */

namespace sdn {

namespace core {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

void Participant_Impl::Initialize (void) 
{ 

  log_trace("Participant_Impl::Initialize - Entering method");

  /* Initialize attributes */ 
  this->m_ext_topic = false;
  this->m_packet = NULL; this->m_topic = NULL; Topic_InitializeMetadata(this->m_mdata); 
  this->m_cb = NULL; this->m_attr = NULL; /* Routine called as part of message handling */
  
  /* Bug 8722 - Test validity of SDN_INTERFACE_NAME */
  if (sdn_is_interface_valid() != true) log_notice("Participant_Impl::Initialize - SDN_INTERFACE_NAME is either not defined or wrongly defined");

  get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) this->m_iface_name); 

  log_trace("Participant_Impl::Initialize - Leaving method");

  return; 

};

/* Accessor methods */

/* Bug 7919 - Return error in case interface is invalid */
RET_STATUS Participant_Impl::SetInterface (const char* name) { RET_STATUS status = STATUS_ERROR; if (net_is_interface_valid(name) == true) { sstrncpy((char*) this->m_iface_name, name, STRING_MAX_LENGTH); status = STATUS_SUCCESS; } return status; };
RET_STATUS Participant_Impl::SetMetadata (Metadata_t& mdata) { RET_STATUS status = STATUS_ERROR; this->m_mdata = mdata; if (Topic_IsMetadataValid(this->m_mdata) == true) status = STATUS_SUCCESS; return status; };
RET_STATUS Participant_Impl::SetTopicName (const char* name) { sstrncpy((char*) this->m_mdata.name, name, STRING_MAX_LENGTH); return STATUS_SUCCESS; };

/* Miscellaneous methods */

RET_STATUS Participant_Configure (Participant_Impl* self)
{

  log_trace("Participant_Configure - Entering method");

  RET_STATUS status = STATUS_ERROR;

  if ((self->m_topic != NULL) && ((self->m_topic)->IsName((char*) self->m_mdata.name) != true)) /* Topic name has been changed */
    {
      log_debug("Participant::Configure - Deleting topic and packet instances");
      delete self->m_topic; self->m_topic = NULL;
      delete self->m_packet; self->m_packet = NULL;
    }

  /* Instantiate topic using metadata */
  if (self->m_topic == NULL) self->m_topic = new Topic (self->m_mdata);

  if ((self->m_topic)->IsInitialized() != true) /* Incomplete metadata: name only must be supported by XML topic definition file, else metadata must be complete enough */
    {
      /* Initialization failed */
      log_error("Participant_Configure - Failed to initialize topic '%s'", (self->m_topic)->GetName()); 
      return status;
    }
  else
    {
      char buffer [256]; 
      (self->m_topic)->SerializeType((char*) buffer, 256);
      log_info("Participant_Configure - Using topic definition - %s", buffer);
    }

  /* Instantiate packet from payload size */
  if (self->m_packet == NULL) self->m_packet = new Packet ((self->m_topic)->GetSize()); (self->m_packet)->CreateInstance();

  {
    char buffer [256]; 
    (self->m_packet)->SerializeType((char*) buffer, 256);
    log_info("Participant_Configure - Using packet definition - %s", buffer);
  }

  /* Take the reference to the topic instance */
  (self->m_topic)->SetInstance((self->m_packet)->GetPayload()); (self->m_topic)->ClearInstance();

  /* Prepare header fields */
  ((self->m_packet)->GetHeader())->SetTopicSize((self->m_topic)->GetSize());
  ((self->m_packet)->GetHeader())->SetTopicUID((self->m_topic)->GetUID());
  ((self->m_packet)->GetHeader())->SetTopicVersion((self->m_topic)->GetVersion());
#if 0
  {
    char buffer [256]; 
    ((self->m_packet)->GetHeader())->SerializeInstance((char*) buffer, 256);
    log_info("Participant_Configure - Using header definition - %s", buffer);
  }
#endif
  status = STATUS_SUCCESS;

  log_trace("Participant_Configure - Leaving method");

  return status;

};

/* Constructor methods */

Participant_Impl::Participant_Impl (void) 
{ 

  /* Initialize resources */ 
  this->Initialize(); 

  /* Register to the object database */ 
  ObjectDatabase_Register((AnyObject*) this); 

  return; 

};

/* Destructor method */

Participant_Impl::~Participant_Impl (void) 
{ 

  /* Release resources */ 
  if ((this->m_ext_topic != true) && (this->m_topic != NULL)) delete this->m_topic; 
  if (this->m_packet != NULL) delete this->m_packet; 

  /* Remove from the object database */ 
  ObjectDatabase_Remove((AnyObject*) this); 

  return; 

};

/* Display methods */

}; /* namespace core */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
