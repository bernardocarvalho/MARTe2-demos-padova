/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/mcast-participant.cpp $
* $Id: mcast-participant.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
//#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */

#include "mcast-participant.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::mcast"

/* Type definition */

namespace sdn {

namespace mcast {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

void Participant_Impl::Initialize (void)
{

  log_trace("Participant_Impl::Initialize - Entering method"); 

  /* Initialize attributes */
  this->SetInterface(DEFAULT_IFACE_NAME);
  this->SetMCastGroup(DEFAULT_MCAST_GROUP);
  this->SetMCastPort(DEFAULT_MCAST_PORT);

  this->m_buffer = NULL;
  this->m_size = 0;

  this->m_socket = -1;

  this->m_cb = NULL; this->m_attr = NULL;

  /* Bug 8722 - Test validity of SDN_INTERFACE_NAME */
  if (sdn_is_interface_valid() != true) log_notice("Participant_Impl::Initialize - SDN_INTERFACE_NAME is either not defined or wrongly defined");
  else
    {
      /* Try and retrieve interface name from environment variable */
      get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) this->m_if_name, MAX_IP_ADDR_LENGTH);
    }

  log_trace("Participant_Impl::Initialize - Leaving method"); 

  return;

};

/* Accessor methods */

void Participant_Impl::SetInterface (const char* iface) { if (net_is_interface_valid((char*) iface) != true) log_warning("Participant_Impl::SetInterface - Interface '%s' is invalid", iface); sstrncpy((char*) this->m_if_name, (char*) iface, MAX_IP_ADDR_LENGTH); return; };
void Participant_Impl::SetMCastGroup (const char* group) { if (sdn_is_mcast_address(group) != true) log_warning("Participant_Impl::SetMCastGroup - Address '%s' is invalid", group); sstrncpy((char*) this->m_mcast_group, (char*) group, MAX_IP_ADDR_LENGTH); return; };
void Participant_Impl::SetMCastPort (uint_t port) { this->m_mcast_port = port; return; };

void Participant_Impl::SetBuffer (void* buffer, uint_t size) 
{ 

  log_trace("Participant_Impl::SetBuffer - Entering method ('%p')", buffer); 

  /* Bug 9249 - Natural payload size limit for UDP/IPv4 */
  if (size > MAX_PACKET_SIZE) log_warning("Participant_Impl::SetBuffer - Buffer size '%u' is invalid - MCAST payload limited to '%u'", size, MAX_PACKET_SIZE); 

  this->m_buffer = buffer; this->m_size = size; 

  log_trace("Participant_Impl::SetBuffer - Leaving method ('%p')", buffer); 

  return; 

};

/* Miscellaneous methods */

RET_STATUS Participant_Open (Participant_Impl* self)
{

  log_trace("Participant_Open - Entering routine"); 

  RET_STATUS status = STATUS_ERROR;

  self->m_socket = socket(AF_INET, SOCK_DGRAM, 0);

  if (self->m_socket < 0)
    {
      log_error("Participant_Open - socket(...) failed with '%d - %s'", errno, strerror(errno));
      return status;
    }
  else
    {
      log_debug("Participant_Open - socket(...) successful");
    }
#if 0 /* Just for the subscriber */
  /* Bind socket to multicast address */
  {
    struct sockaddr_in mcast_addr;

    memset(&mcast_addr, 0, sizeof(self->mcast_addr));
    mcast_addr.sin_family = AF_INET;
    mcast_addr.sin_addr.s_addr = inet_addr(self->m_mcast_group);
    mcast_addr.sin_port = htons(self->m_mcast_port);
    
    /* Bind socket to multicast address */
    if (bind(self->m_socket, (struct sockaddr*) &mcast_addr, sizeof(mcast_addr)) != 0)
      {
	log_error("Participant_Open - bind(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Participant_Open - bind(...) successful");
      }
  }
#endif
  /* Get address of selected local interface */
  {
    struct ifreq if_req;

    strcpy(if_req.ifr_name, self->m_if_name);
    
    if (ioctl(self->m_socket, SIOCGIFADDR, &if_req) < 0)
      {
	log_error("Participant_Open - ioctl(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Participant_Open - ioctl(...) successful");
	log_debug("Participant_Open - IP address is '%s'", inet_ntoa(((struct sockaddr_in*)&if_req.ifr_addr)->sin_addr));
      }

    strncpy(self->m_if_addr, inet_ntoa(((struct sockaddr_in*)&if_req.ifr_addr)->sin_addr), MAX_IP_ADDR_LENGTH);
  }

  /* Set socket options - Attach socket to selected local interface */
  {
    struct in_addr if_addr;

    if_addr.s_addr = inet_addr(self->m_if_addr);

    if (setsockopt(self->m_socket, IPPROTO_IP, IP_MULTICAST_IF, (char*) &if_addr, sizeof(if_addr)) < 0)
      {
	log_error("Participant_Open - setsockopt(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Participant_Open - setsockopt(...) successful");
      }
  }

  status = STATUS_SUCCESS;

  log_trace("Participant_Open - Leaving routine"); 

  return status;

}

RET_STATUS Participant_Close (Participant_Impl* self)
{

  log_trace("Participant_Close - Entering routine"); 

  RET_STATUS status = STATUS_ERROR;

  if (self->m_socket < 0)
    {
      return status;
    }

  close(self->m_socket);
  self->m_socket = -1;

  status = STATUS_SUCCESS;

  log_trace("Participant_Close - Leaving routine"); 

  return status;

}

/* Constructor methods */

Participant_Impl::Participant_Impl (void)
{

  log_trace("Participant_Impl::Participant_Impl - Entering method"); 

  /* Initialize attributes */
  this->Initialize();

  log_trace("Participant_Impl::Participant_Impl - Leaving method"); 

  return;

};

/* Destructor method */

Participant_Impl::~Participant_Impl (void)
{

  log_trace("Participant_Impl::~Participant_Impl - Entering method"); 

  /* Close socket */ 
  /* this->Close(); */ /* Should not be calling pure virtual method since instances of derived classes would already have been destroyed */

  log_trace("Participant_Impl::~Participant_Impl - Leaving method"); 

  return;

}


}; /* namespace mcast */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
