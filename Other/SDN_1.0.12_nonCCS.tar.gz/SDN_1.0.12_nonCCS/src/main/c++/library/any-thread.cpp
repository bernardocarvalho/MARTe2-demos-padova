/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/any-thread.cpp $
* $Id: any-thread.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <pthread.h>
#include <sys/prctl.h> /* PR_SET_NAME, etc. */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

/* Local header files */

#include "tools.h" /* Misc. helper functions, e.g. hash, etc. */
#include "types.h" /* Global type definition */

#define LOG_TRACE_ENABLE
#undef LOG_TRACE_ENABLE 
#define LOG_DEBUG_ENABLE
#undef LOG_DEBUG_ENABLE 
#include "log-api.h" /* Syslog wrapper routines (ccs::log) */

#include "any-thread.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "ccs::base"

/* Type definition */

namespace ccs {

namespace base {

/* Global variables */

/* Function declaration */

void AnyThread_Task (AnyThread* self);

void AnyThread_None (AnyThread* self); /* Thread activity defined by application-specific callback */
void AnyThread_Asynch (AnyThread* self);   /* Asynchronous thread activity - Wait for duration rather than until time */
void AnyThread_Synch (AnyThread* self);     /* Synchronous thread activity - Wait and compute next execution time */
void AnyThread_SynchLong (AnyThread* self); /* Synchronous thread activity - Appropriate for long periods */

/* Function definition */

void AnyThread_Task (AnyThread* self)
{

  if (self == NULL)
    {
      log_error("Unable to start '%s' thread", self->m_name);
      pthread_exit(NULL);
    }

  log_debug("Starting '%s' thread", self->m_name);
  log_debug("Run 'top -p %d', press <f>,<j>,<return> and <H> to show threads and CPU usage", get_process_id());

  /* Set thread name */
  prctl(PR_SET_NAME, self->m_name, 0, 0, 0);
#if 0 /* AnyThread::Launch to return after preamble has returned */
  /* Update state */
  self->m_running = true; 
#endif
  /* Call application-specific routine */
  self->Preamble();

  /* Update state */
  self->m_running = true; /* Launch to return after preamble has returned */

  /* Thread loop */
  while (__sync_bool_compare_and_swap(&(self->m_terminate), false, false))
    {
      /* Wait until expected time has passed */
      self->Sleep();

      /* Call the application-specific routine */
      self->Do();
    }

  /* Call application-specific routine */
  self->Closing();

  /* Update state */
  self->m_running = false;

  log_debug("Terminating '%s' thread", self->m_name);

  pthread_exit(NULL);

};

void AnyThread_None (AnyThread* self) { return; };
void AnyThread_Asynch (AnyThread* self) { while ((__sync_bool_compare_and_swap(&(self->m_trigger), true, false) != true) && (__sync_bool_compare_and_swap(&(self->m_terminate), false, false) == true)) wait_for(self->m_accuracy); self->m_curr_time = get_time(); }; /* Deprecate AnyThread::SetSynchronous */
//void AnyThread_SynchFirst (AnyThread* self) { /* Compute time of first execution */     self->m_curr_time = get_time(); self->m_till_time = ceil_time(self->m_curr_time); self->m_sleep = (void (*)(void*)) &AnyThread_SynchSleep; };
void AnyThread_Synch (AnyThread* self) { /* Wait until expected time has passed */ self->m_curr_time = wait_until(self->m_till_time + self->m_phase, self->m_accuracy); self->m_till_time += self->m_period; };
void AnyThread_SynchLong (AnyThread* self) 
{ 

  /* Intermediate breaks to regularly test for termination flag */
  while ((self->m_interm < self->m_till_time) && (__sync_bool_compare_and_swap(&(self->m_terminate), false, false) == true))
    { 
      self->m_interm += DEFAULT_THREAD_PERIOD; 
      //log_debug("Compute next intermediate time to '%ld'", self->m_interm);
      self->m_curr_time = wait_until(self->m_interm + self->m_phase, self->m_accuracy); /* Warning - 10% CPU load due to wait_until - 10ms accuracy is enough */
    };

  self->m_interm = self->m_till_time + DEFAULT_THREAD_PERIOD;
  self->m_till_time += self->m_period;

  //log_debug("AnyThread_SynchLong - Compute next execution time to '%ld'", self->m_till_time);

};

/* Initializer methods */

void AnyThread::Initialize (void) 
{ 

  /* Initialize instance attributes */
  sstrncpy(this->m_name, DEFAULT_THREAD_NAME, STRING_MAX_LENGTH); 

  this->m_thread = NULL; 
  this->m_running = false; this->m_terminate = false; this->m_trigger = false; 

  this->m_do.attr = NULL; this->m_do.cb = NULL; 
  this->m_pre.attr = NULL; this->m_pre.cb = NULL; 
  this->m_pos.attr = NULL; this->m_pos.cb = NULL; 

  this->m_affinity = DEFAULT_THREAD_SCHEDULING_AFFINITY; 
  this->m_policy   = DEFAULT_THREAD_SCHEDULING_POLICY; 
  this->m_priority = DEFAULT_THREAD_SCHEDULING_PRIORITY; 

  this->m_interm = this->m_curr_time = this->m_till_time = 0; this->m_synchronous = true; this->m_sleep = (void (*)(void*)) &AnyThread_Synch;
  this->m_accuracy = DEFAULT_THREAD_ACCURACY; this->m_period = DEFAULT_THREAD_PERIOD; this->m_phase = DEFAULT_THREAD_PHASE; 

  return; 

};

RET_STATUS AnyThread::Launch (uint64_t at_time) 
{ 

  RET_STATUS status = STATUS_ERROR;

  log_trace("AnyThread::Launch - Entering method");

  if (this->IsRunning() == true) return status;

  /* Compute expected start time */
  this->m_curr_time = get_time(); 
  this->m_interm = ceil_time(this->m_curr_time, DEFAULT_THREAD_PERIOD);

  this->m_till_time = ((this->m_period == 0) ? this->m_interm : ceil_time(this->m_curr_time, ((this->m_period > DEFAULT_THREAD_PERIOD) ? 1000000000L : this->m_period))); /* Start at next period or exact second */

  if (at_time > this->m_curr_time) this->m_till_time = at_time;

  log_debug("Launching '%s' thread for execution at '%ld'", this->m_name, this->m_till_time + this->m_phase);

  this->m_terminate = false; 

  /* Start thread */
  pthread_attr_t thread_attr;

  if (pthread_attr_init(&thread_attr) != 0) 
    {
      log_error("AnyThread::Launch - pthread_attr_init(..) failed with '%m'");
      return status;
    }

  /* Make thread detached in order to free resources even when pthread_join is not called */
  pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);

  if (pthread_create(&(this->m_thread), &thread_attr, (void* (*) (void*)) &AnyThread_Task, (void*) this) != 0)
    {
      log_error("AnyThread::Launch - pthread_create(..) failed");
      return status;
    }
  else
    {
      log_debug("AnyThread::Launch - pthread_create(..) successful");
    }

  if (pthread_attr_destroy(&thread_attr) != 0) 
    {
      log_error("AnyThread::Launch - pthread_attr_destroy(..) failed with '%m'");
      return status;
    }

  while (this->IsRunning() == false) wait_for(DEFAULT_THREAD_PERIOD); 

  /* Set thread properties */
  if (this->m_affinity != DEFAULT_THREAD_SCHEDULING_AFFINITY) this->SetAffinity(this->m_affinity);
  if ((this->m_policy != DEFAULT_THREAD_SCHEDULING_POLICY) ||
      (this->m_priority != DEFAULT_THREAD_SCHEDULING_PRIORITY)) this->SetPriority(this->m_policy, this->m_priority);

  status = STATUS_SUCCESS;

  log_trace("AnyThread::Launch - Leaving method");

  return status; 

};

RET_STATUS AnyThread::Terminate (void) 
{ 

  log_trace("AnyThread::Terminate - Entering method");

  if (this->IsRunning() == true) this->m_terminate = true;

  uint_t count = 20;

  while ((this->IsRunning() == true) && (count > 0)) { wait_for(DEFAULT_THREAD_PERIOD); count -= 1; };

  if (count == 0) { log_warning("Forcing termination of '%s' thread", this->m_name); pthread_cancel(this->m_thread); this->m_running = false; }

  this->m_terminate = false; 
  this->m_thread = NULL; 

  log_trace("AnyThread::Terminate - Leaving method");

  return STATUS_SUCCESS; 

};

/* Accessor methods */

RET_STATUS AnyThread::SetPeriod (uint64_t period) 
{ 

  RET_STATUS status = STATUS_SUCCESS;

  if (this->m_period != period)
    {
      /* Change behaviour */
      log_debug("AnyThread::SetPeriod - Set '%s' thread period to '%ld'", this->m_name, period);
      this->m_period = period; this->Update();
    }
  
  return status; 

};

RET_STATUS AnyThread::SetSynchronous (bool flag) 
{ 

  RET_STATUS status = STATUS_SUCCESS;

  /* Deprecate AnyThread::SetSynchronous */
  if (flag == false) log_warning("AnyThread::SetSynchronous - Deprecated function");

  if (this->m_synchronous != flag)
    {
      /* Change behaviour */
      log_debug("AnyThread::SetSynchronous - Set '%s' thread to '%s' mode", this->m_name, ((flag == true) ? "synchronous" : "asynch"));
      this->m_synchronous = flag; this->Update();
    }

  return status; 

};

/* Miscellaneous methods */

void AnyThread::Update (void) 
{

  log_debug("Update '%s' thread sleep method as appropriate ...", this->m_name);

  if (this->m_period == 0) 
    {
      log_debug("... for blocking application-specific callback");
#if 0
      this->m_sleep = (void (*)(void*)) &AnyThread_None;
#else
      this->m_sleep = NULL;
#endif
    }
  else if (this->m_synchronous == false) 
    {
      log_debug("... for 'asynch' mode");
      this->m_sleep = (void (*)(void*)) &AnyThread_Asynch;
    }
  else 
    {
      log_debug("... for 'synchronous' mode starting at '%ld'", this->m_till_time + this->m_phase);
      this->m_sleep = (void (*)(void*)) ((this->m_period > DEFAULT_THREAD_PERIOD) ? &AnyThread_SynchLong : &AnyThread_Synch); 

      if (this->IsRunning() == true)
	{
	  /* Compute expected execution time */
	  this->m_curr_time = get_time(); 
	  this->m_interm = ceil_time(this->m_curr_time, DEFAULT_THREAD_PERIOD);
	  this->m_till_time = ceil_time(this->m_curr_time, ((this->m_period > DEFAULT_THREAD_PERIOD) ? 1000000000L : this->m_period)); /* Start at next period or exact second */
	}
    }

  return; 

};

/* Constructor methods */

/* Destructor method */

/* Display methods */

}; /* namespace base */

}; /* namespace ccs */

#undef LOG_ALTERN_SRC

