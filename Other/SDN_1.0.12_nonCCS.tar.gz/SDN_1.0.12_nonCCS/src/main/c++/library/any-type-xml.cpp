/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/any-type-xml.cpp $
* $Id: any-type-xml.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

#include <libxml/tree.h> 
//#include <libxml/parser.h>

/* Local header files */

#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "any-type-xml.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::base"

/* Type definition */

namespace sdn {

namespace base {

/* Global variables */

static char _path_list [] [PATH_MAX_LENGTH] = 
{

  "${CODAC_CONF}/default", 
  "${SDN_TOPIC_PATH}",
  "${CODAC_CONF}/sdn", 
  "${CODAC_ROOT}/apps/include", /* Deprecated */
  "/tmp", 
  ".", 
  EOT_KEYWORD

};

static char _suff_list [] [STRING_MAX_LENGTH] = 
{

  "",
  ".xml",
  "_typedef.xml",
  EOT_KEYWORD

};

/* Function declaration */

/* Function definition */

RET_STATUS AnyType_LocateTypeDefinition (char* name, char* file_path, uint_t max_size)
{

  log_trace("%s - Entering method", __FUNCTION__);

  RET_STATUS status = STATUS_ERROR;

  if (name == NULL) return status;

  if (file_path == NULL)
    {
      char tmp [1024];
      file_path = (char*) tmp; max_size = 1024;
    }

  char file_name [PATH_MAX_LENGTH];

  bool found = false;

  uint_t path_index = 0;

  while (strncmp(_path_list[path_index], EOT_KEYWORD, PATH_MAX_LENGTH) != 0)
    {
      char* conf_path = _path_list[path_index];

      log_debug("%s - Try and resolve path '%s'", __FUNCTION__, conf_path); 

      if (resolve_variable_path(conf_path) != STATUS_SUCCESS)
	{
	  log_error("Unable to resolve path '%s'", conf_path);
	  continue;
	}
      else
	{
	  log_debug("%s - Path resolves to '%s'", __FUNCTION__, conf_path);
	}

      uint_t suff_index = 0;

      while (strncmp(_suff_list[suff_index], EOT_KEYWORD, PATH_MAX_LENGTH) != 0)
	{
	  char* suffix = _suff_list[suff_index];

	  if (exist((char*) conf_path, (char*) name, (char*) suffix) == true)
	    {
	      found = true;

	      snprintf(file_name, PATH_MAX_LENGTH, "%s%s", name, (char*) suffix);

	      log_debug("%s - Load '%s' topic definition file from '%s'", __FUNCTION__, name, conf_path);

	      snprintf(file_path, PATH_MAX_LENGTH, "%s/%s", conf_path, file_name);

	      break;
	    }

	  suff_index += 1;
	}

      if (found == true) 
	{
	  /* No need to search further */
	  log_debug("%s - Located '%s' topic definition file", __FUNCTION__, file_path);
	  status = STATUS_SUCCESS;
	  break;
	}

      path_index += 1;
    }

  if (found != true) log_error("AnyType_LocateTypeDefinition - Unable to locate '%s' datatype definition file", name);

  log_trace("%s - Leaving method", __FUNCTION__);

  return status;

};

RET_STATUS AnyType_LoadTypeDefinition (AnyType* self, char* file_path) /* Dependency to libxml2 to be managed by the calling application */
{

  log_trace("%s - Entering method", __FUNCTION__);

  RET_STATUS status = STATUS_ERROR;

  /* Search for configuration file */
  if (exist(file_path) != true)
    {
      log_error("%s - Unable to locate datatype definition file '%s'", __FUNCTION__, file_path);
      return status;
    }
  else
    {
      log_debug("%s - Found file '%s'", __FUNCTION__, file_path);
    }

  /* Rely on libxml2 to load and parse type definition file */

  xmlInitParser();
  LIBXML_TEST_VERSION;

  xmlDocPtr xDoc = xmlParseFile(file_path);

  if (xDoc == NULL) 
    {
      log_error("%s - Unable to parse file '%s'", __FUNCTION__, file_path);
      return status;
    }
  else 
    {
      xmlNodePtr xCurNode = xmlDocGetRootElement(xDoc);

      for (xCurNode = xCurNode->children; xCurNode; xCurNode = xCurNode->next) 
	{
	  /* Only interested in XML elements at this level */
	  if (xCurNode->type != XML_ELEMENT_NODE) { log_debug("%s - Discard XML node type '%d'", __FUNCTION__, xCurNode->type); continue; }
	  /* Only interested in 'attribute' elements */
	  if (strcmp((char*) xCurNode->name, (char*) "attribute") != 0) { log_debug("%s - Discard XML element node '%s'", __FUNCTION__, xCurNode->name); continue; }
	  /* Must have 'name' and 'type' properties */
	  if (xmlHasProp(xCurNode, (xmlChar*) "name") == NULL) { log_warning("%s - Discard attribute - Does not appear to have a name", __FUNCTION__); continue; }
	  if (xmlHasProp(xCurNode, (xmlChar*) "dataType") == NULL) { log_warning("%s - Discard attribute - Does not appear to have a type", __FUNCTION__); continue; }
#if 0 /* Risk of memory leak */
	  char* attr_name = (char*) xmlGetProp(xCurNode, (xmlChar*) "name");
	  char* attr_type = (char*) xmlGetProp(xCurNode, (xmlChar*) "dataType");
#else
	  char attr_name [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
	  char attr_rank [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
	  char attr_type [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
	  char attr_mult [STRING_MAX_LENGTH] = STRING_UNDEFINED; 

	  xmlChar* prop; 

	  prop = xmlGetProp(xCurNode, (xmlChar*) "name");     sstrncpy((char*) attr_name, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop);
	  prop = xmlGetProp(xCurNode, (xmlChar*) "dataType"); sstrncpy((char*) attr_type, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop);

	  if (xmlHasProp(xCurNode, (xmlChar*) "rank") != NULL)         { prop = xmlGetProp(xCurNode, (xmlChar*) "rank");         sstrncpy((char*) attr_rank, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };
	  if (xmlHasProp(xCurNode, (xmlChar*) "multiplicity") != NULL) { prop = xmlGetProp(xCurNode, (xmlChar*) "multiplicity"); sstrncpy((char*) attr_mult, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };
#endif
	  log_debug("%s - Found attribute '%s'", __FUNCTION__, attr_name);

	  char* attr_defl = NULL;

	  /* May have a default value, i.e. XML text as child */
	  if ((xCurNode->children != NULL) && (xCurNode->children->type == XML_TEXT_NODE)) 
	    { 
	      log_debug("%s - Attribute '%s' is provided with a default value", __FUNCTION__, attr_name);
	      attr_defl = (char*) xCurNode->children->content; char* p_buf = attr_defl; while (*p_buf != 0) { if (*p_buf == '\n') *p_buf = ' '; p_buf += 1; } /* Replace characters */
	    }

	  if (self->AddAttribute(attr_rank, attr_name, attr_type, attr_mult, attr_defl) != STATUS_SUCCESS)
	    {
	      log_error("%s - AnyType::AddAttribute('%s %s %s %s %s') failed", __FUNCTION__, attr_rank, attr_name, attr_type, attr_mult, attr_defl); 
	      break;
	    }
	  else if (self->HasAttribute(attr_name) == true)
	    {
	      log_debug("%s - AnyType::AddAttribute('%s %s %s %s %s') successful", __FUNCTION__, attr_rank, attr_name, attr_type, attr_mult, attr_defl);
	    }
	  else log_warning("%s - AnyType::AddAttribute successful but AnyType::HasAttribute('%s') failed - '%d'", __FUNCTION__, attr_name, self->GetRank());

	  char attr_desc [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
	  char attr_qual [STRING_MAX_LENGTH] = STRING_UNDEFINED; 
	  char attr_unit [STRING_MAX_LENGTH] = STRING_UNDEFINED; 

	  if (xmlHasProp(xCurNode, (xmlChar*) "description") != NULL) { prop = xmlGetProp(xCurNode, (xmlChar*) "description"); sstrncpy((char*) attr_desc, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };
	  if (xmlHasProp(xCurNode, (xmlChar*) "qualifier") != NULL)   { prop = xmlGetProp(xCurNode, (xmlChar*) "qualifier");   sstrncpy((char*) attr_qual, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };
	  if (xmlHasProp(xCurNode, (xmlChar*) "unit") != NULL)        { prop = xmlGetProp(xCurNode, (xmlChar*) "unit");        sstrncpy((char*) attr_unit, (char*) prop, STRING_MAX_LENGTH); xmlFree(prop); };

	  if (IsUndefined((char*) attr_desc) != true) log_debug("Attribute '%s' has 'description' property set to '%s'", attr_name, attr_desc);
	  if (IsUndefined((char*) attr_qual) != true) log_debug("Attribute '%s' has 'qualifier' property set to '%s'", attr_name, attr_qual);
	  if (IsUndefined((char*) attr_unit) != true) log_debug("Attribute '%s' has 'unit' property set to '%s'", attr_name, attr_unit);
	  if (IsUndefined((char*) attr_mult) != true) log_debug("Attribute '%s' has 'multiplicity' property set to '%s'", attr_name, attr_mult);

	  if (self->AddExtAttribute(attr_rank, attr_name, attr_desc, attr_qual, attr_unit, attr_mult) != STATUS_SUCCESS)
	    {
	      log_error("%s - AnyType::AddExtAttribute('%s %s %s %s %s %s') failed", __FUNCTION__, attr_rank, attr_name, attr_desc, attr_qual, attr_unit, attr_mult); 
	      break;
	    }
	  else
	    {
	      log_debug("%s - AnyType::AddExtAttribute('%s %s %s %s %s %s') successful", __FUNCTION__, attr_rank, attr_name, attr_desc, attr_qual, attr_unit, attr_mult);
	    }

	}
    }
  
  /* Shutdown libxml */
  xmlFreeDoc(xDoc);
  xmlCleanupParser();
  xmlMemoryDump();

  /* Try and compress LUTable */
  self->Compress();

  status = STATUS_SUCCESS;

  if (self->IsDefined() == true)
    {
      char buffer [2048] = STRING_UNDEFINED; self->SerializeType(buffer, 2048);
      log_info("Loaded datatype definition '%s'", buffer);
    }
  else
    {
      /* Error during initialization */
      status = STATUS_ERROR;
    }

  log_trace("%s - Leaving method", __FUNCTION__);

  return status;

};

/* Initializer methods */

RET_STATUS AnyType::AddExtAttribute (char* rank, char* name, char* desc, char* qual, char* unit, char* mult)
{

  log_debug("AnyType::AddExtAttribute('%s %s %s %s %s %s') - Entering method", rank, name, desc, qual, unit, mult);

  RET_STATUS status = STATUS_ERROR;

  if (this->HasAttribute(name) == false) 
    {
      log_error("AnyType::AddExtAttribute - Undefined attribute '%s'", name);
      this->m_defined = false; 
      return status;
    }
  else
    {
      log_debug("AnyType::AddExtAttribute - Attribute '%s' exists", name);
    }

  uint_t rank_ = (this->m_type_ext)->GetSize(); if (IsUndefined(rank) != true) sscanf(rank, "%d", &rank_);

  if (rank_ > MAXIMUM_ATTRIBUTE_NUM) /* Scalability issue */
    {
      log_error("AnyType::AddExtAttribute - Out-of-bound attribute '%s' rank '%d'", name, rank_);
      this->m_defined = false;
      return status;
    }

  /* Bug 8733 - Attributes defined with identical rank specification overwrite each other */

  if ((this->m_type_ext)->IsValid(rank_) == true) /* An attribute already exists at this location */
    {
      log_error("AnyType::AddExtAttribute - An attribute '%s' already exists at rank '%d'", (this->m_type_ext)->GetKeyword(rank_), rank_);
      this->m_defined = false;
      return status; 
    }

  ExtTypeInfo_t info; 

  info.rank = rank_; 

  sstrncpy((char*) info.desc, (IsUndefined(desc) ? (char*) STRING_UNDEFINED : desc), STRING_MAX_LENGTH);
  sstrncpy((char*) info.qual, (IsUndefined(qual) ? (char*) STRING_UNDEFINED : qual), STRING_MAX_LENGTH);
  sstrncpy((char*) info.unit, (IsUndefined(unit) ? (char*) STRING_UNDEFINED : unit), STRING_MAX_LENGTH);
  sstrncpy((char*) info.mult, (IsUndefined(mult) ? (char*) STRING_UNDEFINED : mult), STRING_MAX_LENGTH);

  if ((this->m_type_ext)->AddPair(name, info, rank_) != STATUS_SUCCESS) /* Create attribute at LUTable index corresponding to rank and not in the order they are declared */
    { 
      log_error("AnyType::AddExtAttribute - Unable to add attribute '%s' at rank '%d'", name, rank_);
      this->m_defined = false;
      return status; 
    }
  else
    {
      log_debug("AnyType::AddExtAttribute - LUTable<>::AddPair('%s %s %s %s %s %u') successful", name, info.desc, info.qual, info.unit, info.mult, rank_);
    }

  status = STATUS_SUCCESS;

  log_trace("AnyType::AddExtAttribute('%s %s %s %s %s %s') - Leaving method", rank, name, desc, qual, unit, mult);

  return status;
 
};

void AnyType::Initialize (void)
{

  log_trace("AnyType:Initialize: - Entering method");

  /* Initialize attributes */
  this->SetName(DEFAULT_TOPIC_NAME);

  this->m_type_ext = new LUTable<ExtTypeInfo_t> (MAXIMUM_ATTRIBUTE_NUM); 
  
  ExtTypeInfo_t info; info.rank = 0; 

  sstrncpy((char*) info.desc, (char*) STRING_UNDEFINED, STRING_MAX_LENGTH);
  sstrncpy((char*) info.qual, (char*) STRING_UNDEFINED, STRING_MAX_LENGTH);
  sstrncpy((char*) info.unit, (char*) STRING_UNDEFINED, STRING_MAX_LENGTH);
  sstrncpy((char*) info.mult, (char*) STRING_UNDEFINED, STRING_MAX_LENGTH);
  
  (this->m_type_ext)->SetDefault(info); 
  (this->m_type_ext)->Clear();

  log_trace("AnyType::Initialize - Leaving method");

  return;

};

RET_STATUS AnyType::Load (char* file_path) 
{

  log_trace("AnyType::Load - Entering method");

  RET_STATUS status = STATUS_ERROR;

  /* Search for configuration file */
  if (exist(file_path) != true)
    {
      log_error("AnyType::Load - Unable to locate datatype definition file '%s'", file_path);
      return status;
    }
  else
    {
      log_debug("AnyType::Load - Found file '%s'", file_path);
    }

  if (AnyType_LoadTypeDefinition(this, file_path) != STATUS_SUCCESS)
    {
      log_error("AnyType::Load - Unable to parse datatype definition file '%s'", file_path);
      return status;
    }
  else
    {
      log_debug("AnyType::Load - Parsed file '%s'", file_path);
    }

  status = STATUS_SUCCESS;

  log_trace("AnyType::Load - Leaving method");

  return status;

};

/* Accessor methods */

char* AnyType::GetAttributeDescription (uint_t rank)
{

  if ((this->m_type_ext)->IsValid(rank) != true) 
    {
      log_error("AnyType::GetAttributeDescription('%d') - Invalid attribute", rank);
      return NULL;
    }

  ExtTypeInfo_t* p_info = (this->m_type_ext)->GetReference(rank);

  return ((IsUndefined((char*) p_info->desc) == true) ? NULL : (char*) p_info->desc);

};

char* AnyType::GetAttributeQualifier (uint_t rank)
{

  if ((this->m_type_ext)->IsValid(rank) != true) 
    {
      log_error("AnyType::GetAttributeQualifier('%d') - Invalid attribute", rank);
      return NULL;
    }

  ExtTypeInfo_t* p_info = (this->m_type_ext)->GetReference(rank);

  return ((IsUndefined((char*) p_info->qual) == true) ? NULL : (char*) p_info->qual);

};

char* AnyType::GetAttributeUnit (uint_t rank)
{

  if ((this->m_type_ext)->IsValid(rank) != true) 
    {
      log_error("AnyType::GetAttributeUnit('%d') - Invalid attribute", rank);
      return NULL;
    }

  ExtTypeInfo_t* p_info = (this->m_type_ext)->GetReference(rank);

  return ((IsUndefined((char*) p_info->unit) == true) ? NULL : (char*) p_info->unit);

};

char* AnyType::GetAttributeMultiplicity (uint_t rank)
{

  if ((this->m_type_ext)->IsValid(rank) != true) 
    {
      log_error("AnyType::GetAttributeMultiplicity('%d') - Invalid attribute", rank);
      return NULL;
    }

  ExtTypeInfo_t* p_info = (this->m_type_ext)->GetReference(rank);

  return ((IsUndefined((char*) p_info->mult) == true) ? NULL : (char*) p_info->mult);

};

/* Miscellaneous methods */

RET_STATUS AnyType::Compress (void) 
{ 

  RET_STATUS status = STATUS_ERROR;

  /* Bug 9290 - ccs::base::AnyType::Compress() returns when the type is contiguous
              - LUtable<>::Compress() performs at most one-step compression 
  */

  if ((status = this->ccs::base::AnyType::Compress()) != STATUS_SUCCESS)
    {
      log_error("ccs::base::AnyType::Compress() failed");
      return status;
    }

  while ((this->m_type_ext)->Compress() != STATUS_ERROR) { log_info("AnyType::Compress - Compression iteration"); }

  status = STATUS_SUCCESS;

  return status; 

};

/* Constructor methods */

AnyType::AnyType (void) : ccs::base::AnyType ()
{

  log_trace("AnyType::AnyType - Entering method");

  /* Initialize attributes */
  this->Initialize();

  log_trace("AnyType::AnyType - Leaving method");

  return;

};

AnyType::AnyType (char* name) : ccs::base::AnyType () /* Dependency to libxml2 to be managed by the calling application */
{

  log_trace("AnyType::AnyType('%s') - Entering method", name);

  /* Initialize attributes */
  this->Initialize();

  this->SetName(name);

  char file_path [PATH_MAX_LENGTH];

  /* Search for type definition file at several locations ... */
  if (AnyType_LocateTypeDefinition(this->GetName(), (char*) file_path) != STATUS_SUCCESS)
    {
      log_warning("AnyType::AnyType('%s') - Unable to locate datatype definition file", this->GetName());
      return;
    }
  else
    {
      log_debug("AnyType::AnyType('%s') - Located '%s' file", this->GetName(), file_path);
    }

 if (this->Load(file_path) != STATUS_SUCCESS) /* Try and load datatype definition file */
    {
      log_warning("AnyType::AnyType('%s') - Unable to open and parse '%s' file", this->GetName(), file_path);
    }

  log_trace("AnyType::AnyType('%s') - Leaving method", name);

  return;

};

/* Destructor method */

/* Display methods */

uint_t AnyType::SerializeType (char* buffer, int max_size)
{

  log_trace("AnyType::SerializeType - Entering method");

  /* WARNING - Unsafe implementation */

  if (buffer == NULL) /* Only interested in hash key */
    {
      char tmp [2048] = STRING_UNDEFINED;
      buffer = (char*) tmp; max_size = 2048;
    }

  /* WARNING - Check if size could be negative - yes in case snprintf truncates ... does not append zero  ... and the buffer is not cleared */

  /* Zero the buffer */
  memset(buffer, 0, max_size); max_size -= 1; /* Make sure the buffer is zero'ed (and the trailing zero won't get overwrittent) so as to avoid strlen failure in case snprintf truncates */

  char* p_buf = buffer;

  if (this->IsDefined() != true)
    {
      sstrncpy(p_buf, (char*) "</dataType>", max_size);
      return 0;
    }
#if 0
  snprintf(p_buf, max_size, "<dataType name=\"%s\" size=\"%u\">\n", this->GetName(), this->GetSize()); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
#else
  //snprintf(p_buf, max_size, "<dataType name=\"%s\" size=\"%u\">", this->GetName(), this->GetSize()); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
  snprintf(p_buf, max_size, "<dataType>"); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
#endif
  for (uint_t index = 0; index < this->GetRank(); index += 1)
    {
      ccs::base::TypeInfo_t info; (this->m_type)->GetValue(info, index);

      if (ccs::base::AnyType_IsAttrValid(info) != true) continue;

      char name [STRING_MAX_LENGTH]; (this->m_type)->GetKeyword(name, index); /* Get attribute name */
      char* type = ccs::base::AnyType_GetTypeName((TypeIdentifier_t) info.type); /* Get type identifier */

      snprintf(p_buf, max_size, "<attribute name=\"%s\" dataType=\"%s\"", name, type); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      if (info.mult != 1) 
	{ 
#if 0
	  snprintf(p_buf, max_size, " multiplicity=\"%u\"/>\n", info.mult); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
#else
	  snprintf(p_buf, max_size, " multiplicity=\"%u\"/>", info.mult); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
#endif
	}
      else
	{
#if 0
	  sstrncpy(p_buf, (char*) "/>\n", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
#else
	  sstrncpy(p_buf, (char*) "/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
#endif
	}
    }

  /* Terminate buffer */
  sstrncpy(p_buf, (char*) "</dataType>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  log_debug("Serialized type '%s'", buffer);

  log_trace("AnyType::SerializeType - Leaving method");

  /* Hask key from datatype definition */
  return hash(buffer);

};

}; /* namespace base */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC

