/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/ucast-publisher.cpp $
* $Id: ucast-publisher.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
#include "sdn-ucast.h" /* SDN core library - API definition (sdn::ucast) */

#include "ucast-participant.h"
#include "ucast-publisher.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::ucast"

/* Type definition */

namespace sdn {

namespace ucast {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

/* Accessor methods */

//const char* Publisher_Iface::GetAddress (void) { return (this->p_impl)->GetAddress(); };
const char* Publisher_Iface::GetInterface (void) { return (this->p_impl)->GetInterface(); };
const char* Publisher_Iface::GetUCastAddr (void) { return (this->p_impl)->GetUCastAddr(); };
uint_t Publisher_Iface::GetUCastPort (void) { return (this->p_impl)->GetUCastPort(); };
    
void Publisher_Iface::SetInterface (const char* iface) { return (this->p_impl)->SetInterface(iface); };
void Publisher_Iface::SetUCastAddr (const char* addr) { return (this->p_impl)->SetUCastAddr(addr); };
void Publisher_Iface::SetUCastPort (uint_t port) { return (this->p_impl)->SetUCastPort(port); };
    
void* Publisher_Iface::GetBuffer (void) { return (this->p_impl)->GetBuffer(); };
uint_t Publisher_Iface::GetSize (void) { return (this->p_impl)->GetSize(); };
void Publisher_Iface::SetBuffer (void* buffer, uint_t size) { return (this->p_impl)->SetBuffer(buffer, size); };

RET_STATUS Publisher_Iface::SetCallback (void (* cb)(void*)) { return (this->p_impl)->SetCallback(cb); }; /* Routine called before message publication */
RET_STATUS Publisher_Iface::SetCallback (void (* cb)(void*), void* attr) { return (this->p_impl)->SetCallback(cb, attr); }; /* Routine called before message publication */

/* Miscellaneous methods */

RET_STATUS Publisher_Iface::Open (void) { return (this->p_impl)->Open(); }; /* Specializes virtual method */
RET_STATUS Publisher_Iface::Close (void) { return (this->p_impl)->Close(); }; /* Specializes virtual method */

RET_STATUS Publisher_Iface::Publish (void* buffer, uint_t size) { return (this->p_impl)->Publish(buffer, size); };
RET_STATUS Publisher_Iface::Publish (void) { return (this->p_impl)->Publish(); };

RET_STATUS Publisher_Impl::Open (void)
{

  RET_STATUS status = STATUS_ERROR;

  log_trace("Publisher_Impl::Open - Entering method"); 

  /* Common base class implementation */
  Participant_Open((Participant_Impl*) this);

  if (this->m_socket < 0)
    {
      log_error("Publisher_Impl::Open - m_socket has not been initialized");
      return status;
    }
#if 0
  /* Connect to multicast group - Unclear why socket needs to be 'bound' AND 'connected' */
  {
    struct sockaddr_in mcast_addr;

    memset(&mcast_addr, 0, sizeof(mcast_addr));
    mcast_addr.sin_family = AF_INET;
    mcast_addr.sin_addr.s_addr = inet_addr(this->m_mcast_group);
    mcast_addr.sin_port = htons(this->m_mcast_port);
    
    /* Bind socket to multicast address */
    if (connect(this->m_socket, (struct sockaddr*) &mcast_addr, sizeof(mcast_addr)) != 0)
      {
	log_error("Publisher_Impl::Open - connect(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Publisher_Impl::Open - connect(...) successful");
	log_debug("Publisher_Impl::Open - MCAST group is '%s %d'", this->m_mcast_group, this->m_mcast_port);
      }
  }
#endif
  /* Set socket buffer length */
  {
    int length = 16384;

    if (setsockopt(this->m_socket, SOL_SOCKET, SO_SNDBUF, (char*) &length, sizeof(length))  < 0)
      {
	log_error("Publisher_Impl::Open - setsockopt(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Publisher_Impl::Open - setsockopt(...) successful");
      }
  }

  /* Disable UDP checksum */
  {
    int disable = 1;

    if (setsockopt(this->m_socket, SOL_SOCKET, SO_NO_CHECK, (char*) &disable, sizeof(disable))  < 0)
      {
	log_error("Publisher_Impl::Open - setsockopt(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Publisher_Impl::Open - setsockopt(...) successful");
      }
  }

  status = STATUS_SUCCESS;

  log_trace("Publisher_Impl::Open - Leaving method"); 

  return status;

};

RET_STATUS Publisher_Impl::Close (void)
{

  RET_STATUS status = STATUS_ERROR;

  log_trace("Publisher_Impl::Close - Entering method"); 

  /* Common base class implementation */
  Participant_Close((Participant_Impl*) this);

  status = STATUS_SUCCESS;

  log_trace("Publisher_Impl::Close - Leaving method"); 

  return status;

};

RET_STATUS Publisher_Impl::Publish (void* p_msg, uint_t size)
{

  log_trace("Publisher_Impl::Publish - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  if (this->m_socket < 0)
    {
      log_error("Publisher_Impl::Publish - m_socket has not been initialized");
      return status;
    }

  struct sockaddr_in ucast_addr; /* The remote address to which to send */
  int addr_size = sizeof(ucast_addr);

  memset(&ucast_addr, 0, addr_size);
  ucast_addr.sin_family = AF_INET;
  ucast_addr.sin_addr.s_addr = inet_addr(this->m_ucast_addr);
  ucast_addr.sin_port = htons(this->m_ucast_port);

  /* Send message */    
  if (sendto(this->m_socket, p_msg, size, MSG_DONTWAIT, (struct sockaddr*) &ucast_addr, addr_size) < 0)
    {
      log_error("Publisher_Impl::Publish - send(...) failed with '%d - %s'", errno, strerror(errno));
      return status;
    }
  else
    {
      log_debug("Publisher_Impl::Publish - send(...) successful with size '%d'", size);
      status = STATUS_SUCCESS;
    }
#if 0
  /* Receive reply */
  if (recvfrom(this->m_socket, p_msg, size, 0, (struct sockaddr*) &ucast_addr, (socklen_t*) &addr_size) < 0)
    {
      log_error("Publisher_Impl::Publish - send(...) failed with '%d - %s'", errno, strerror(errno));
      return status;
    }
  else
    {
      log_debug("Publisher_Impl::Publish - send(...) successful with size '%d'", size);
      status = STATUS_SUCCESS;
    }
#endif
  log_trace("Publisher_Impl::Publish - Leaving method"); 

  return status;

};

RET_STATUS Publisher_Impl::Publish (void) 
{ 

  log_trace("Publisher_Impl::Publish - Entering method"); 

  /* Invoke callback, if any */
  if (this->m_cb != NULL) (*(this->m_cb))(this->m_attr);

  log_trace("Publisher_Impl::Publish - Leaving method"); 

  return this->Publish(this->m_buffer, this->m_size); 

};

/* Constructor methods */

Publisher_Iface::Publisher_Iface (void)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl ();

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (const char* iface, const char* addr, uint_t port)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (iface, addr, port);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Impl::Publisher_Impl (void) 
{ 

  log_trace("Publisher_Impl::Publisher_Impl - Entering method"); 

  /* Initialize attributes */ 
  this->SetInstanceType(OBJTYPE_UCAST_PUBLISHER); 
  this->Initialize(); 

  log_trace("Publisher_Impl::Publisher_Impl - Leaving method"); 

  return; 

};

Publisher_Impl::Publisher_Impl (const char* iface, const char* addr, uint_t port) 
{ 

  log_trace("Publisher_Impl::Publisher_Impl - Entering method"); 

  /* Initialize attributes */ 
  this->SetInstanceType(OBJTYPE_UCAST_PUBLISHER); 
  this->Initialize(); 

  this->SetInterface(iface); 
  this->SetUCastAddr(addr); 
  this->SetUCastPort(port); 

  /* Open and configure socket */ 
  this->Open(); 

  log_trace("Publisher_Impl::Publisher_Impl - Leaving method"); 

  return; 

};

/* Destructor method */

Publisher_Iface::~Publisher_Iface (void)
{
        
  log_trace("Publisher_Iface::~Publisher_Iface - Entering method");
        
  /* Release resources */
  if (this->p_impl != NULL) delete this->p_impl; this->p_impl= NULL;
        
  log_trace("Publisher_Iface::~Publisher_Iface - Leaving method");
        
  return;
        
};

Publisher_Impl::~Publisher_Impl (void) 
{ 

  log_trace("Publisher_Impl::~Publisher_Impl - Entering method"); 

  /* Close socket */ 
  this->Close(); 

  log_trace("Publisher_Impl::~Publisher_Impl - Leaving method"); 

  return; 

};

}; /* namespace ucast */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
