/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/sdn-participant.cpp $
* $Id: sdn-participant.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "core-participant.h"
#include "disc-publisher.h"

#include "sdn-participant.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::core"

/* Type definition */

namespace sdn {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

void Participant_Impl::Initialize (void) 
{ 

  log_trace("Participant_Impl::Initialize - Entering method");

  /* Initialize attributes */ 
  this->m_base = NULL;
  this->m_disc = NULL;

  log_trace("Participant_Impl::Initialize - Leaving method");

  return; 

};

/* Accessor methods */

/* Miscellaneous methods */

RET_STATUS Participant_Configure (Participant_Impl* self)
{

  log_trace("%s - Entering method", __FUNCTION__);

  RET_STATUS status = STATUS_ERROR;

  /* Instantiate discovery publisher */
  if (self->m_disc == NULL) self->m_disc = new disc::Publisher(); (self->m_disc)->SetInterface(self->GetInterface()); (self->m_disc)->Configure();
 
  status = STATUS_SUCCESS;

  log_trace("%s - Leaving method", __FUNCTION__);

  return status;

};

/* Constructor methods */

Participant_Impl::Participant_Impl (void)
{
    
  log_trace("Participant_Impl::Participant_Impl - Entering method");
    
  /* Initialize resources */
  this->Initialize();
    
  /* Register to the object database */
  ObjectDatabase_Register((AnyObject*) this);
    
  log_trace("Participant_Impl::Participant_Impl - Leaving method");
    
  return;

};

/* Destructor method */

Participant_Impl::~Participant_Impl (void) 
{ 

  log_trace("Participant_Impl::~Participant_Impl - Entering method");
    
  /* Release resources */
  if (this->m_disc != NULL) delete this->m_disc; this->m_disc = NULL; 

  /* Remove from the object database */ 
  ObjectDatabase_Remove((AnyObject*) this); 

  log_trace("Participant_Impl::~Participant_Impl - Leaving method");
    
  return;

};

/* Display methods */

}; /* namespace sdn */
