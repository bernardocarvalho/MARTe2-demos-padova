/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/disc-subscriber.cpp $
* $Id: disc-subscriber.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */


/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "mcast-subscriber.h"

#include "disc-participant.h"
#include "disc-subscriber.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::disc"

/* Type definition */

namespace sdn {

namespace disc {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

void Subscriber_Impl::Initialize (void)
{

  log_trace("Subscriber_Impl::Initialize - Entering method"); 

  /* Initialize attributes */
  this->m_base = NULL; /* mcast::Subscriber instance */

  log_trace("Subscriber_Impl::Initialize - Leaving method"); 

  return;

};

/* Accessor methods */

/* Miscellaneous methods */

RET_STATUS Subscriber_Impl::Configure (void)
{

  log_trace("Subscriber_Impl::Configure - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  /* Configure base class */
  if (Participant_Configure((Participant*) this) != STATUS_SUCCESS)
    {
      log_error("Subscriber_Impl::Configure - Failed to configure participant"); 
      return status;
    }

  /* Create generic publisher, if necessary */
  if ((this->m_base != NULL) && 
      ((strcmp((this->m_base)->GetMCastGroup(), this->GetMCastGroup()) != 0) ||
       ((this->m_base)->GetMCastPort() != this->GetMCastPort()) ||
       ((this->m_base)->GetInterface() != this->GetInterface())))
    {
      log_debug("Subscriber_Impl::Configure - Closing mcast::Subscriber instance");
      (this->m_base)->Close();
    }

  if (this->m_base == NULL) { log_debug("Subscriber::Configure - Creating mcast::Subscriber instance"); this->m_base = new mcast::Subscriber_Impl (); }
  log_debug("Subscriber_Impl::Configure - Configure mcast::Subscriber instance");
  (this->m_base)->SetInterface(this->GetInterface()); (this->m_base)->SetMCastGroup(this->GetMCastGroup()); (this->m_base)->SetMCastPort(this->GetMCastPort()); (this->m_base)->Open();

  log_debug("Subscriber_Impl::Configure - Defining mcast::Subscriber buffer and size");
  (this->m_base)->SetBuffer(this->GetBuffer(), this->GetSize());

  status = STATUS_SUCCESS; 
  
  log_trace("Subscriber_Impl::Configure - Leaving method"); 

  return status;

}; 

RET_STATUS Subscriber_Impl::Receive (void) 
{ 

  log_trace("Subscriber_Impl::Receive - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  /* Receive discovery message from the network */
  if (this->m_base != NULL) status = (this->m_base)->Receive();
  log_info("Subscriber_Impl::Receive - Message '%s'", (char*) this->GetBuffer());

  log_trace("Subscriber_Impl::Publish - Leaving method"); 

  return status; 

};

RET_STATUS Subscriber_Impl::Receive (uint_t timeout) 
{ 

  log_trace("Subscriber_Impl::Receive - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  /* Receive discovery message from the network */
  if ((this->m_base != NULL) && ((status = (this->m_base)->Receive(timeout)) == STATUS_SUCCESS)) 
    {    
      log_info("Subscriber_Impl::Receive - Message '%s'", (char*) this->GetBuffer());
    }

  log_trace("Subscriber_Impl::Publish - Leaving method"); 

  return status; 

};

/* Constructor methods */

/* Destructor method */

Subscriber_Impl::~Subscriber_Impl (void) 
{ 

  log_trace("Subscriber_Impl::~Subscriber_Impl - Entering method"); 

  /* Release resources */
  if (this->m_base != NULL) delete this->m_base; this->m_base = NULL; 

  log_trace("Subscriber_Impl::~Subscriber_Impl - Leaving method"); 

  return; 

}; 

}; /* namespace disc */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
