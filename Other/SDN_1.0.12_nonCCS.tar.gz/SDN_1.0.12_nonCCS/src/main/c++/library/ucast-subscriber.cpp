/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/ucast-subscriber.cpp $
* $Id: ucast-subscriber.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
#include "sdn-ucast.h" /* SDN core library - API definition (sdn::ucast) */

#include "ucast-participant.h"
#include "ucast-subscriber.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::ucast"

/* Type definition */

namespace sdn {

namespace ucast {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

/* Accessor methods */

const char* Subscriber_Iface::GetInterface (void) { return (this->p_impl)->GetInterface(); };
const char* Subscriber_Iface::GetUCastAddr (void) { return (this->p_impl)->GetUCastAddr(); };
uint_t Subscriber_Iface::GetUCastPort (void) { return (this->p_impl)->GetUCastPort(); };
    
void Subscriber_Iface::SetInterface (const char* iface) { return (this->p_impl)->SetInterface(iface); };
void Subscriber_Iface::SetUCastAddr (const char* addr) { return (this->p_impl)->SetUCastAddr(addr); };
void Subscriber_Iface::SetUCastPort (uint_t port) { return (this->p_impl)->SetUCastPort(port); };
    
void* Subscriber_Iface::GetBuffer (void) { return (this->p_impl)->GetBuffer(); };
uint_t Subscriber_Iface::GetSize (void) { return (this->p_impl)->GetSize(); };
void Subscriber_Iface::SetBuffer (void* buffer, uint_t size) { return (this->p_impl)->SetBuffer(buffer, size); };

uint_t Subscriber_Iface::GetTimeout (void) { return (this->p_impl)->GetTimeout(); };
void Subscriber_Iface::SetTimeout (uint_t timeout) { return (this->p_impl)->SetTimeout(timeout); };

bool Subscriber_Iface::IsUpdated (void) { return (this->p_impl)->IsUpdated(); }; /* Successful Receive */

RET_STATUS Subscriber_Iface::SetCallback (void (* cb)(void*)) { return (this->p_impl)->SetCallback(cb); }; /* Routine called before message publication */
RET_STATUS Subscriber_Iface::SetCallback (void (* cb)(void*), void* attr) { return (this->p_impl)->SetCallback(cb, attr); }; /* Routine called before message publication */

/* Miscellaneous methods */

RET_STATUS Subscriber_Iface::Open (void) { return (this->p_impl)->Open(); }; /* Specializes virtual method */
RET_STATUS Subscriber_Iface::Close (void) { return (this->p_impl)->Close(); }; /* Specializes virtual method */

RET_STATUS Subscriber_Iface::Receive (void* buffer, uint_t size, uint64_t timeout) { return (this->p_impl)->Receive(buffer, size, timeout); };
RET_STATUS Subscriber_Iface::Receive (void* buffer, uint_t size) { return (this->p_impl)->Receive(buffer, size); };
RET_STATUS Subscriber_Iface::Receive (uint64_t timeout) { return (this->p_impl)->Receive(timeout); };
RET_STATUS Subscriber_Iface::Receive (void) { return (this->p_impl)->Receive(); };

RET_STATUS Subscriber_Impl::Open (void)
{

  log_trace("Subscriber_Impl::Open - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  /* Common base class implementation */
  Participant_Open((Participant_Impl*) this);

  if (this->m_socket < 0)
    {
      log_error("Subscriber_Impl::Open - m_socket has not been initialized");
      return status;
    }

  /* Set socket buffer length*/
  {
    int length = 16384;

    if (setsockopt(this->m_socket, SOL_SOCKET, SO_RCVBUF, (char*) &length, sizeof(length))  < 0)
      {
	log_error("Subscriber_Impl::Open - setsockopt(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Subscriber_Impl::Open - setsockopt(...) successful");
      }
  }

  status = STATUS_SUCCESS;

  log_trace("Subscriber_Impl::Open - Leaving method"); 

  return status;

};

RET_STATUS Subscriber_Impl::Close (void)
{

  log_trace("Subscriber_Impl::Close - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  if (this->m_socket < 0)
    {
      log_error("Subscriber_Impl::Close - m_socket has not been initialized");
      return status;
    }
#if 0
  /* Set socket options - Drop IGMP membership */
  {
    struct ip_mreq ip_req;

    ip_req.imr_multiaddr.s_addr = inet_addr(this->m_mcast_group);
    ip_req.imr_interface.s_addr = inet_addr(this->m_if_addr);

    if (setsockopt(this->m_socket, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*) &ip_req, sizeof(ip_req)) < 0)
      {
	log_error("Subscriber_Impl::Close - setsockopt(...) failed with '%d - %s'", errno, strerror(errno));
	return status;
      }
    else
      {
	log_debug("Subscriber_Impl::Close - setsockopt(...) successful");
      }
  }
#endif
  /* Common base class implementation */
  Participant_Close((Participant_Impl*) this);

  status = STATUS_SUCCESS;

  log_trace("Subscriber_Impl::Close - Leaving method"); 

  return status;

};

RET_STATUS Subscriber_Impl::Receive (void* p_msg, uint_t size, uint64_t timeout)
{

  RET_STATUS status = STATUS_ERROR;

  if (this->m_socket < 0)
    {
      log_error("Subscriber_Impl::Receive - m_socket has not been initialized");
      return status;
    }

  fd_set sel_fd;
  struct timespec sel_timeout; ns_to_timespec(timeout, sel_timeout);
      
  FD_ZERO(&sel_fd); FD_SET(this->m_socket, &sel_fd);

  if (pselect(this->m_socket + 1, &sel_fd, NULL, NULL, &sel_timeout, NULL) != 1)
    {
      //log_warning("Subscriber::Receive - pselect(...) failed with '%d - %s'", errno, strerror(errno));
      return status;
    }

  return this->Receive(p_msg, size);

};

RET_STATUS Subscriber_Impl::Receive (void* p_msg, uint_t size)
{

  log_trace("Subscriber_Impl::Receive - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  if (this->m_socket < 0)
    {
      log_error("Subscriber_Impl::Receive - m_socket has not been initialized");
      return status;
    }

  struct sockaddr_in ucast_addr; /* The remote address to which to reply */
  int addr_size = sizeof(ucast_addr);

  memset(&ucast_addr, 0, addr_size);

  /* Receive message */
  if (recvfrom(this->m_socket, p_msg, size, 0, (struct sockaddr*) &ucast_addr, (socklen_t*) &addr_size) < 0)
    {
      log_error("Subscriber_Impl::Receive - recvfrom(...) failed with '%d - %s'", errno, strerror(errno));
      return status;
    }
  else
    {
      //log_debug("Subscriber_Impl::Receive - recvfrom(...) successful with size '%d'", size);
      status = STATUS_SUCCESS;
    }
#if 0
  /* Send reply */    
  if (sendto(this->m_socket, p_msg, size, MSG_DONTWAIT, (struct sockaddr*) &ucast_addr, addr_size) < 0)
    {
      log_error("Subscriber_Impl::Publish - send(...) failed with '%d - %s'", errno, strerror(errno));
      return status;
    }
  else
    {
      log_debug("Subscriber_Impl::Publish - send(...) successful with size '%d'", size);
      //status = STATUS_SUCCESS;
    }
#endif
  log_trace("Subscriber_Impl::Receive - Leaving method"); 

  return status;

};

RET_STATUS Subscriber_Impl::Receive (uint64_t timeout) /* Blocking wait with configurable timeout - Buffer and size defined using mcast::Participant::SetBuffer() */
{ 

  RET_STATUS status = STATUS_ERROR; 
#if 0
  this->m_updated = false; /* Clear flag */
#else
  //__atomic_store_n(&this->m_updated, true, __ATOMIC_RELEASE);
  bool flag = __sync_val_compare_and_swap(&this->m_updated, true, false); /* Clear flag */
#endif
  if ((status = this->Receive(this->m_buffer, this->m_size, timeout)) == STATUS_SUCCESS) 
    {
#if 0
      this->m_updated = true; /* Set flag */
#else
      //__atomic_store_n(&this->m_updated, false, __ATOMIC_RELEASE);
      flag = __sync_val_compare_and_swap(&this->m_updated, false, true); /* Set flag */
#endif
      /* Invoke callback, if any */
      if (this->m_cb != NULL) (*(this->m_cb))(this->m_attr);
    }

  return status;
 
}; 

RET_STATUS Subscriber_Impl::Receive (void) /* Blocking wait - Buffer and size defined using mcast::Participant::SetBuffer() */
{ 

  RET_STATUS status = STATUS_ERROR; 
#if 0
  this->m_updated = false; /* Clear flag */
#else
  //__atomic_store_n(&this->m_updated, true, __ATOMIC_RELEASE);
  bool flag = __sync_val_compare_and_swap(&this->m_updated, true, false); /* Clear flag */
#endif
  if ((status = this->Receive(this->m_buffer, this->m_size)) == STATUS_SUCCESS) 
    {
#if 0
      this->m_updated = true; /* Set flag */
#else
      //__atomic_store_n(&this->m_updated, false, __ATOMIC_RELEASE);
      flag = __sync_val_compare_and_swap(&this->m_updated, false, true); /* Set flag */
#endif
      /* Invoke callback, if any */
      if (this->m_cb != NULL) (*(this->m_cb))(this->m_attr);
    }

  return status;
 
}; 

/* Constructor methods */

Subscriber_Iface::Subscriber_Iface (void)
{

  log_trace("Subscriber_Iface::Subscriber_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Subscriber_Impl ();

  log_trace("Subscriber_Iface::Subscriber_Iface - Leaving method"); 

  return;

};

Subscriber_Iface::Subscriber_Iface (const char* iface, const char* addr, uint_t port)
{

  log_trace("Subscriber_Iface::Subscriber_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Subscriber_Impl (iface, addr, port);

  log_trace("Subscriber_Iface::Subscriber_Iface - Leaving method"); 

  return;

};

Subscriber_Impl::Subscriber_Impl (void) 
{ 

  log_trace("Subscriber_Impl::Subscriber_Impl - Entering method"); 

  /* Initialize attributes */ 
  this->SetInstanceType(OBJTYPE_UCAST_SUBSCRIBER); 
  this->Initialize(); 

  log_trace("Subscriber_Impl::Subscriber_Impl - Leaving method"); 

  return; 

};

Subscriber_Impl::Subscriber_Impl (const char* iface, const char* addr, uint_t port) 
{ 

  log_trace("Subscriber_Impl::Subscriber_Impl - Entering method"); 

  /* Initialize attributes */
  this->SetInstanceType(OBJTYPE_UCAST_SUBSCRIBER); 
  this->Initialize(); 

  this->SetInterface(iface); 
  this->SetUCastPort(port); 

  /* Open and configure socket */ 
  this->Open(); 

  log_trace("Subscriber_Impl::Subscriber_Impl - Leaving method"); 

  return; 

};

/* Destructor method */

Subscriber_Iface::~Subscriber_Iface (void)
{
        
  log_trace("Subscriber_Iface::~Subscriber_Iface - Entering method");
        
  /* Release resources */
  if (this->p_impl != NULL) delete this->p_impl; this->p_impl= NULL;
        
  log_trace("Subscriber_Iface::~Subscriber_Iface - Leaving method");
        
  return;
        
};

Subscriber_Impl::~Subscriber_Impl (void) 
{ 

  log_trace("Subscriber_Impl::~Subscriber_Impl - Entering method"); 

  /* Close socket */ 
  this->Close(); 
  
  log_trace("Subscriber_Impl::~Subscriber_Impl - Leaving method"); 

  return; 

};

}; /* namespace ucast */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
