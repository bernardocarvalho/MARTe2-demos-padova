/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/sdn-header.cpp $
* $Id: sdn-header.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "sdn-header.h" /* This class definition */

/* Constants */

/* Type definition */

namespace sdn {

/* Global variables */
#ifndef DATATYPE_DEFINITION_FROM_XML_FILE
static AttrInfo_t Header_attributes_list [] = {

  /* Attributes */
  /* Header UID      */ { "header_uid",    "char",     "8", "SDNv2.x" }, 
  /* Header size     */ { "header_size",   "uint32_t", "1", "48" }, 
  /* Topic UID       */ { "topic_uid",     "uint32_t", "1", "0" }, 
  /* Topic version   */ { "topic_version", "uint32_t", "1", "0" }, 
  /* Topic size      */ { "topic_size",    "uint32_t", "1", "0" }, 
  /* Topic counter   */ { "topic_counter", "uint64_t", "1", "0" }, 
  /* Topic timestamp */ { "send_time",     "uint64_t", "1", "0" }, 
  /* Topic timestamp */ { "recv_time",     "uint64_t", "1", "0" }, 

  { STRING_UNDEFINED, STRING_UNDEFINED, STRING_UNDEFINED, STRING_UNDEFINED }

};
#endif /* DATATYPE_DEFINITION_FROM_XML_FILE */
/* Function declaration */

/* Function definition */

/* Initializer methods */

void Header::Initialize (void) 
{ 

  if (this->AnyType::GetInstance() == NULL) return;

  void* attr = NULL;

  /* Header UID      */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_HEADER_UID);    sstrncpy((char*) attr, (char*) "SDNv2.x", 8);
  /* Header size     */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_HEADER_SIZE);   *((uint32_t*) attr) = this->AnyType::GetSize();
  /* Topic UID       */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_UID);     *((uint32_t*) attr) = 0;
  /* Topic version   */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_VERSION); *((uint32_t*) attr) = 0;
  /* Topic size      */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_SIZE);    *((uint32_t*) attr) = 0;
  /* Topic counter   */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_COUNTER);       *((uint64_t*) attr) = 0L;
  /* Topic timestamp */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_SEND_TIME);     *((uint64_t*) attr) = 0L;
  /* Topic timestamp */ attr = this->AnyType::GetAttributeReference(SDN_HEADER_RECV_TIME);     *((uint64_t*) attr) = 0L;

  return; 

};

/* Accessor methods */

char* Header::HasInstanceIndex (void) 
{ 

  char* p_attr = NULL;
#if 0
  for (uint_t index = 0; index < this->GetRank(); index += 1) 
    { 
      char* p_qual = this->GetAttributeQualifier(index); 

      if ((p_qual != NULL) && (strcmp(p_qual, "samplenb") == 0)) 
	{
	  p_attr = this->GetAttributeName(index); 
	  log_debug("Header::HasInstanceIndex - Found attribute '%s'", p_attr);
	  break;
	}
    } 
#else
  p_attr = this->AnyType::GetAttributeName((uint_t) SDN_HEADER_COUNTER);
#endif
  return p_attr; 

};

char* Header::HasInstanceTimestamp (void) 
{ 

  char* p_attr = NULL;
#if 0
  for (uint_t index = 0; index < this->GetRank(); index += 1) 
    { 
      char* p_qual = this->GetAttributeQualifier(index); 

      if ((p_qual != NULL) && (strcmp(p_qual, "timestamp") == 0)) 
	{
	  p_attr = this->GetAttributeName(index); 
	  log_debug("Header::HasInstanceTimestamp - Found attribute '%s'", p_attr);
	  break;
	}
    } 
#else
  p_attr = this->AnyType::GetAttributeName((uint_t) SDN_HEADER_SEND_TIME);
#endif
  return p_attr; 

};

void Header::SetTopicVersion (char* version) 
{ 
#if 0
  char* attr = (char*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_VERSION); 

  sstrncpy(attr, version, this->AnyType::GetAttributeSize(SDN_HEADER_TOPIC_VERSION)); 
#else
  uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_VERSION);
  uint32_t vers = 0;

  sscanf(version, "%u", &vers); /* Parse version string as integer */

  *attr = vers;
#endif
  return; 

};

void Header::SetTopicVersion (uint32_t version) 
{ 
  uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_VERSION);

  *attr = version;

  return; 

};

/* Miscellaneous methods */

void Header::ClearInstance (void) 
{ 

  log_debug("Header::ClearInstance - Invoke AnyType::ClearInstance method");
  this->AnyType::ClearInstance(); 

  /* Initialize header instance */ 
  this->Initialize(); 

  return; 

};

/* Constructor methods */
#ifdef DATATYPE_DEFINITION_FROM_XML_FILE
Header::Header (void) : sdn::base::AnyType ((char*) "sdn-header") 
{ 

  if (this->IsDefined()  != true)
    {
      /* Declare attributes */
      /* Header UID      */ this->AnyType::AddAttribute<char>((uint_t) SDN_HEADER_HEADER_UID, (char*) "header_uid", 8); 
      /* Header size     */ this->AnyType::AddAttribute<uint32_t>((uint_t) SDN_HEADER_HEADER_SIZE, (char*) "header_size");
      /* Topic UID       */ this->AnyType::AddAttribute<uint32_t>((uint_t) SDN_HEADER_TOPIC_UID, (char*) "topic_uid");
      /* Topic version   */ this->AnyType::AddAttribute<uint32_t>((uint_t) SDN_HEADER_TOPIC_VERSION, (char*) "topic_version");
      /* Topic size      */ this->AnyType::AddAttribute<uint32_t>((uint_t) SDN_HEADER_TOPIC_SIZE, (char*) "topic_size");
      /* Topic counter   */ this->AnyType::AddAttribute<uint64_t>((uint_t) SDN_HEADER_COUNTER, (char*) "topic_counter");
      /* Topic timestamp */ this->AnyType::AddAttribute<uint64_t>((uint_t) SDN_HEADER_SEND_TIME, (char*) "send_time");
      /* Topic timestamp */ this->AnyType::AddAttribute<uint64_t>((uint_t) SDN_HEADER_RECV_TIME, (char*) "recv_time");
      
      /* Initialize header instance */ 
      this->Initialize(); 
    }

  return;

};
#else
Header::Header (void) : AnyType ((AttrInfo_t*) Header_attributes_list) { /* Nothing further */ return; };
#endif
/* Destructor method */

/* Display methods */

}; /* namespace sdn */

