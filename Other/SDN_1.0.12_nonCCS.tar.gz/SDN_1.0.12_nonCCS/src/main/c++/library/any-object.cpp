/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/any-object.cpp $
* $Id: any-object.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */
#if 0 /* Removed to avoid loading dl library if not necessary - Replaced with load_shared_library inline function in tools.h */
#include <dlfcn.h> /* dlopen, dlsym, etc. */
#endif
/* Local header files */

#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "any-object.h" /* This class definition */

/* Constants */

#ifndef UNIT_VERSION_HR
#define VERSION_ID "1.1" /* Needs manual modification */
#else
#define VERSION_ID UNIT_VERSION_HR
#endif

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::base"

/* Type definition */

namespace sdn {

namespace base {

typedef struct ObjectTypeInfo {

  ObjectTypeId_t type;
  AnyObject_Constructor_t constr;
  AnyObject_Destructor_t destr;

} ObjectTypeInfo_t;

class ObjectFactory
{

  private:

    LUTable<ObjectTypeInfo_t>* m_type_list;

    /* Initializer methods */
    RET_STATUS Initialize (void); 

    /* Accessor methods */
    AnyObject_Constructor_t GetConstructor (ObjectTypeId_t type);
    AnyObject_Constructor_t GetConstructor (char* type);
    AnyObject_Destructor_t GetDestructor (ObjectTypeId_t type);
    AnyObject_Destructor_t GetDestructor (char* type);

  protected:

  public:

    /* Initializer methods */
    AnyObject* Instantiate (char* type);
    RET_STATUS Register (char* type, AnyObject_Constructor_t constr, AnyObject_Destructor_t destr); 
    RET_STATUS Remove (char* type) { return (this->m_type_list)->Clear(type); };
    RET_STATUS Terminate (AnyObject* ref);

    /* Accessor methods */

    /* Miscellaneous methods */

    /* Constructor methods */
    ObjectFactory (void) { this->Initialize(); return; };

    /* Destructor method */
   ~ObjectFactory (void) { /* Nothing further than base class destructor */ return; }; 

    /* Display methods */

};

/* Global variables */

static ObjectFactory* __p_ofy = NULL; /* Just instantiate the globally scoped class database */
static ObjectDatabase* __p_odb = NULL; /* Just instantiate the globally scoped object database */

REGISTER_CLASS_WITH_OBJECT_FACTORY(AnyObject); /* Auto-register constructor with the ObjectFactory */

/* Function declaration */

/* Function definition */

/* Initializer methods */

void AnyObject::Initialize (void) 
{ 

  log_trace("AnyObject::Initialize - Entering method"); 

  this->SetInstanceName((char*) STRING_UNDEFINED); 
  this->m_instance_root = this->m_instance_type = GetInstanceTypeByName(OBJTYPE_ROOT); 

  log_trace("AnyObject::Initialize - Leaving method"); 

  return; 

};

RET_STATUS ObjectFactory::Initialize (void) 
{ 
  
  ObjectTypeInfo_t info; 

  info.type = OBJTYPE_UNDEFINED; 
  info.constr = NULL; 
  info.destr = NULL; 

  this->m_type_list = new LUTable<ObjectTypeInfo_t> (info);
 /* WARNING - Static initialization can not be guaranteed to happen after the statically initialized logging callback is available */
#ifdef UNIT_VERSION
#ifdef SVN_REVISION
#ifdef BUILD_DATE
#ifdef BUILD_USER
  log_info("SDN core library version '%s (rev. %s built %s %s)' has initialized", VERSION_ID, SVN_REVISION, BUILD_USER, BUILD_DATE); 
#else
  log_info("SDN core library version '%s' has initialized", VERSION_ID); 
#endif /* BUILD_USER */
#endif /* BUILD_DATE */
#endif /* SVN_REVISION */
#endif /* UNIT_VERSION */

  return STATUS_SUCCESS; 

};

AnyObject* ObjectFactory::Instantiate (char* type) 
{ 

  AnyObject* ref = NULL; 
  AnyObject_Constructor_t construct = this->GetConstructor(type); 

  if (construct != NULL) 
    {
      log_info("Try and instantiate class '%s (%d)'", type, GetInstanceTypeByName(type));
      ref = (*construct)(); 
    }
  else log_warning("Undefined constructor for class '%s (%d)'", type, GetInstanceTypeByName(type));

  if ((ref != NULL) && (GetInstanceTypeByName(type) != ref->GetInstanceType()))
	log_warning("There might be difficulties to terminate instance of class '%s (%d %d)'", type, GetInstanceTypeByName(type), ref->GetInstanceType());
  if ((ref != NULL) && (ref->IsType() == true)) ref->SetInstanceType(type); 

  return ref; 

};

RET_STATUS ObjectFactory::Register (char* type, AnyObject_Constructor_t constr, AnyObject_Destructor_t destr)
{ 

  RET_STATUS status = STATUS_ERROR;

  if ((constr == NULL) || (destr == NULL))
    {
      log_error("Undefined constructor for class '%s'", type);
      return status;
    }

  ObjectTypeInfo_t info; 

  info.type = GetInstanceTypeByName(type); 
  info.constr = constr; 
  info.destr = destr; 

  if ((status = (this->m_type_list)->AddPair(type, info)) != STATUS_SUCCESS)
    {
      log_error("Unable to register class '%s' to the object factory", type);
    }
  else
    {
      log_debug("Successfully registered class '%s (%d)' to the object factory", type, info.type);
    }

  return status; 

}; 

RET_STATUS ObjectFactory::Terminate (AnyObject* ref) 
{ 

  RET_STATUS status = STATUS_ERROR;

  AnyObject_Destructor_t destruct = this->GetDestructor(ref->GetInstanceType()); 

  if (destruct != NULL) 
    {
      log_info("Try and terminate instance '%s (%d)'", ref->GetInstanceName(), ref->GetInstanceType());
      (*destruct)(ref); 
      status = STATUS_SUCCESS;
    }
  else log_warning("Undefined destructor for instance '%s (%d)'", ref->GetInstanceName(), ref->GetInstanceType()); 

  return status; 

};

RET_STATUS ObjectDatabase_Register (char* name, AnyObject* ref) { if (__p_odb == NULL) __p_odb = new ObjectDatabase; log_debug("Try and register '%s' instance", name); if ((ref != NULL) && (ref->IsType() != true)) log_warning("'%s' instance has unclear parentage", name); return __p_odb->Register(name, ref); };
RET_STATUS ObjectDatabase_Remove (char* name) { RET_STATUS status = STATUS_ERROR; if (__p_odb != NULL) status = __p_odb->Remove(name); return status; };
RET_STATUS ObjectDatabase_Remove (uint_t id) { RET_STATUS status = STATUS_ERROR; if (__p_odb != NULL) status = __p_odb->Remove(id); return status; };

RET_STATUS ObjectFactory_Register (char* type, AnyObject_Constructor_t construct, AnyObject_Destructor_t destruct) { if (__p_ofy == NULL) __p_ofy = new ObjectFactory; log_debug("Try and register '%s' class constructor", type); return __p_ofy->Register(type, construct, destruct); };
AnyObject* ObjectFactory_Instantiate (char* type) { log_info("Try and instantiate '%s' class", type); AnyObject* ref = __p_ofy->Instantiate(type); log_debug("ObjectFactory_Instantiate - Reference is '(AnyObject*) %p'", (void*) ref); return ref; };
/* WARNING - The constructor being called by the ObjectFactory must specifically cast to the abstract base class else this intantiate and auto-register in the ObjectDatabase may return mis-aligned references */
AnyObject* ObjectFactory_Instantiate (char* type, char* name) { log_debug("Try and instantiate '%s' class with instance '%s'", type, name); AnyObject* ref = __p_ofy->Instantiate(type); log_debug("ObjectFactory_Instantiate - Reference is '(AnyObject*) %p'", (void*) ref); ObjectDatabase_Register(name, ref); return ref; };
RET_STATUS ObjectFactory_Terminate (AnyObject* ref) { RET_STATUS status = STATUS_ERROR; if ((ref != NULL) && (ref->IsType() == true)) { log_debug("Try and destruct '%s' instance", ref->GetInstanceName()); status = __p_ofy->Terminate(ref); } return status; };

/* Accessor methods */

char* AnyObject::GetInstanceName (void) { return ((char*) this->m_instance_name); };
void AnyObject::SetInstanceName (char* name) { if (name != NULL) sstrncpy(this->m_instance_name, name, STRING_MAX_LENGTH); return; };

ObjectTypeId_t AnyObject::GetInstanceType (void) { return this->m_instance_type; };
void AnyObject::SetInstanceType (ObjectTypeId_t type) { this->m_instance_type = type; return; };
void AnyObject::SetInstanceType (char* type) { return this->SetInstanceType(GetInstanceTypeByName(type)); };

AnyObject_Constructor_t ObjectFactory::GetConstructor (ObjectTypeId_t type) 
{ 

  AnyObject_Constructor_t construct = NULL;
  ObjectTypeInfo_t info; 
  bool found = false;

  for (uint_t index = 0; index < (this->m_type_list)->GetSize(); index += 1)
    {
      (this->m_type_list)->GetValue(info, index);

      if (info.type == type) 
	{
	  found = true;
	  break;
	}
    }

  if (found == true) construct = info.constr;

  return construct; 

};

AnyObject_Constructor_t ObjectFactory::GetConstructor (char* type) { ObjectTypeInfo_t info; info.constr = NULL; (this->m_type_list)->GetValue(info, type); return info.constr; };

AnyObject_Destructor_t ObjectFactory::GetDestructor (ObjectTypeId_t type) 
{ 

  AnyObject_Destructor_t destruct = NULL;
  ObjectTypeInfo_t info;
  bool found = false;

  for (uint_t index = 0; index < (this->m_type_list)->GetSize(); index += 1)
    {
      (this->m_type_list)->GetValue(info, index);

      if (info.type == type) 
	{
	  found = true;
	  break;
	}
    }

  if (found == true) destruct = info.destr;

  return destruct; 

};

AnyObject_Destructor_t ObjectFactory::GetDestructor (char* type) { ObjectTypeInfo_t info; info.destr = NULL; (this->m_type_list)->GetValue(info, type); return info.destr; };

AnyObject* ObjectDatabase_GetInstance (char* name) { log_trace("ObjectDatabase_GetInstance('%s') - Entering method", name); AnyObject* ref = NULL; if (__p_odb != NULL) ref = __p_odb->GetInstance(name); return ref; };
AnyObject* ObjectDatabase_GetInstance (uint_t id) { log_trace("ObjectDatabase_GetInstance('%u') - Entering method", id); AnyObject* ref = NULL; if (__p_odb != NULL) ref = __p_odb->GetInstance(id); return ref; };

/* Miscellaneous methods */
bool AnyObject::IsType (void) { log_trace("AnyObject::IsType - Entering method"); return ((this->m_instance_root == GetInstanceTypeByName(OBJTYPE_ROOT)) ? true : false); };
bool AnyObject::IsType (ObjectTypeId_t type) { return ((this->m_instance_type == type) ? true : false); };
bool AnyObject::IsType (char* type) { log_trace("AnyObject::IsType('%s') - Entering method", type); return ((this->m_instance_type == GetInstanceTypeByName(type)) ? true : false); };

ObjectTypeId_t GetInstanceTypeByName (char* type) { return (ObjectTypeId_t) hash(type); };

/* Constructor methods */

AnyObject::AnyObject (void) { log_trace("AnyObject::AnyObject - Entering method"); this->Initialize(); log_trace("AnyObject::AnyObject - Leaving method"); return; };

/* Destructor method */

AnyObject::~AnyObject (void) { log_trace("AnyObject::~AnyObject - Entering method"); this->SetInstanceName((char*) STRING_UNDEFINED); this->m_instance_root = this->m_instance_type = OBJTYPE_UNDEFINED; log_trace("AnyObject::~AnyObject - Leaving method"); return; }; 

/* Display methods */

}; /* namespace base */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
