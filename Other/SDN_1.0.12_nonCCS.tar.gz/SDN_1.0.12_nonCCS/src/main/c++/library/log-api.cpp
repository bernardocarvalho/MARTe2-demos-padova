/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/log-api.cpp $
* $Id: log-api.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdarg.h> /* va_start, etc. */
#include <syslog.h> /* Log message severity */

/* Local header files */

#include "types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "log-api.h"

/* Constants */

#define LOG_TRACE_ENABLE
#undef LOG_TRACE_ENABLE

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "ccs::log"

/* Type definition */

namespace ccs {

namespace log {

/* Function declaration */

static inline void Message2Stdout (Severity_t severity, const char* source, const char* message, ...) { va_list args; va_start(args, message); vMessage2Stdout (severity, source, message, args); va_end(args); return; };
static inline void Message2Syslog (Severity_t severity, const char* source, const char* message, ...) { va_list args; va_start(args, message); vMessage2Syslog (severity, source, message, args); va_end(args); return; };

/* Global variables */

/* WARNING - The following implies that static initialization can not use the logging callback since
             the linking does not guarantee the initialization order and the use of the callback pointer
             can therefore happen before the pointer is initialized.
*/

static Func_t func_ptr = &vMessage2Syslog;
static Severity_t filter_level = LOG_INFO;

/* Function definition */

void vMessage2Stdout (Severity_t severity, const char* source, const char* message, va_list args) 
{ 

  if (severity > filter_level) return;

  char buffer [1024] = STRING_UNDEFINED;
  char* p_buf = (char*) buffer;
  uint_t size = 1024;

  switch (severity) 
    {
      case LOG_TRACE:   snprintf(p_buf, size, "[%s] ", (char*) "TRACE - ");     break;
      case LOG_DEBUG:   snprintf(p_buf, size, "[%s] ", (char*) "DEBUG - ");     break;
      case LOG_INFO:    snprintf(p_buf, size, "[%s] ", (char*) "INFO - ");      break;
      case LOG_NOTICE:  snprintf(p_buf, size, "[%s] ", (char*) "NOTICE - ");    break;
      case LOG_WARNING: snprintf(p_buf, size, "[%s] ", (char*) "WARNING - ");   break;
      case LOG_ERR:     snprintf(p_buf, size, "[%s] ", (char*) "ERROR - ");     break;
      case LOG_CRIT:    snprintf(p_buf, size, "[%s] ", (char*) "CRITICAL - ");  break;
      case LOG_ALERT:   snprintf(p_buf, size, "[%s] ", (char*) "ALERT - ");     break;
      case LOG_EMERG:   snprintf(p_buf, size, "[%s] ", (char*) "EMERGENCY - "); break;
      default: snprintf(p_buf, size, "[%s] ", (char*) "UNDEF - "); break;
    }

  /* Re-align pointer */
  size -= strlen(p_buf); p_buf += strlen(p_buf); 

  vsnprintf(p_buf, size, message, args); size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  if (IsUndefined(source) != true) snprintf(p_buf, size, "[%s]", source);

  sstrncpy(p_buf, (char*) "\n", size); size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  fprintf(stdout, buffer);

  return; 

};

void vMessage2Syslog (Severity_t severity, const char* source, const char* message, va_list args) 
{ 

  if (severity > filter_level) return;

  char buffer [1024] = STRING_UNDEFINED;
  char* p_buf = (char*) buffer;
  uint_t size = 1024;

  snprintf(p_buf, size, "log-lib:%d]", get_process_id()); size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  if (IsUndefined(source) == true) sstrncpy(p_buf, (char*) "[]", size);
  else snprintf(p_buf, size, "[%s]", source);

  /* Re-align pointer */
  size -= strlen(p_buf); p_buf += strlen(p_buf); 

  switch (severity)
    {
      case LOG_TRACE:   snprintf(p_buf, size, "[%s] ", (char*) "trace");     break;
      case LOG_DEBUG:   snprintf(p_buf, size, "[%s] ", (char*) "debug");     break;
      case LOG_INFO:    snprintf(p_buf, size, "[%s] ", (char*) "info");      break;
      case LOG_NOTICE:  snprintf(p_buf, size, "[%s] ", (char*) "notice");    break;
      case LOG_WARNING: snprintf(p_buf, size, "[%s] ", (char*) "warning");   break;
      case LOG_ERR:     snprintf(p_buf, size, "[%s] ", (char*) "error");     break;
      case LOG_CRIT:    snprintf(p_buf, size, "[%s] ", (char*) "critical");  break;
      case LOG_ALERT:   snprintf(p_buf, size, "[%s] ", (char*) "alert");     break;
      case LOG_EMERG:   snprintf(p_buf, size, "[%s] ", (char*) "emergency"); break;
      default: snprintf(p_buf, size, "[%s] ", (char*) "undef"); break;
    }

  /* Re-align pointer */
  size -= strlen(p_buf); p_buf += strlen(p_buf); 

  vsnprintf(p_buf, size, message, args); size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

  syslog(((severity == LOG_TRACE) ? LOG_DEBUG : severity), buffer); 
#if 0
  sstrncpy(p_buf, (char*) "\n", size); size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
  fprintf(stdout, buffer);
#endif
  return; 

};

void vMessage (Severity_t severity, const char* source, const char* message, va_list args) 
{ 
#ifdef LOG_TRACE_ENABLE
  Severity_t old_level = SetFilter(LOG_TRACE); Message2Syslog(LOG_TRACE, LOG_ALTERN_SRC, "Logger::vMessage - Entering method '%p'", func_ptr); SetFilter(old_level); 
#endif
  if (func_ptr != NULL) (*func_ptr)(severity, source, message, args); 
#ifdef LOG_TRACE_ENABLE
  old_level = SetFilter(LOG_TRACE); Message2Syslog(LOG_TRACE, LOG_ALTERN_SRC, "Logger::vMessage - Leaving method"); SetFilter(old_level); 
#endif
  return; 

};

void Message (Severity_t severity, const char* source, const char* message, ...)
{
#ifdef LOG_TRACE_ENABLE
  Severity_t old_level = SetFilter(LOG_TRACE); Message2Syslog(LOG_TRACE, LOG_ALTERN_SRC, "Logger::Message - Entering method '%p'", func_ptr); SetFilter(old_level); 
#endif
  if (func_ptr != NULL) { va_list args; va_start(args, message); (*func_ptr)(severity, source, message, args); va_end(args); } 
#ifdef LOG_TRACE_ENABLE
  old_level = SetFilter(LOG_TRACE); Message2Syslog(LOG_TRACE, LOG_ALTERN_SRC, "Logger::Message - Leaving method"); SetFilter(old_level); 
#endif
  return;

};

/* Initializer methods */

/* Accessor methods */

Func_t SetCallback (Func_t cb) { Func_t old_ptr = func_ptr; func_ptr = cb; return old_ptr; };
Severity_t SetFilter (Severity_t level) { Severity_t old_level = filter_level; filter_level = level; return old_level; };

/* Miscellaneous methods */

/* Constructor methods */

/* Destructor method */

/* Display methods */

}; /* namespace log */

}; /* namespace ccs */

void log_msg (int severity, const char* source, const char* message, ...)
{
#ifdef LOG_TRACE_ENABLE
  Severity_t old_level = SetFilter(LOG_TRACE); Message2Syslog(LOG_TRACE, LOG_ALTERN_SRC, "Logger::Message - Entering method '%p'", ccs::log::func_ptr); SetFilter(old_level); 
#endif
  if (ccs::log::func_ptr != NULL) { va_list args; va_start(args, message); (*ccs::log::func_ptr)((ccs::log::Severity_t) severity, source, message, args); va_end(args); }
#ifdef LOG_TRACE_ENABLE
  old_level = SetFilter(LOG_TRACE); Message2Syslog(LOG_TRACE, LOG_ALTERN_SRC, "Logger::Message - Leaving method"); SetFilter(old_level); 
#endif
  return;

};

#undef LOG_ALTERN_SRC
