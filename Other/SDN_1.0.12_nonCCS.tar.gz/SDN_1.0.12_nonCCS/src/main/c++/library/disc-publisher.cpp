/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/disc-publisher.cpp $
* $Id: disc-publisher.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "mcast-publisher.h"

#include "core-participant.h"
#include "core-publisher.h"
#include "core-subscriber.h"

#include "disc-participant.h"
#include "disc-publisher.h" /* This class definition */

/* Constants */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::disc"

/* Type definition */

namespace sdn {

namespace disc {

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

void Publisher_Impl::Initialize (void)
{

  log_trace("Publisher_Impl::Initialize - Entering method"); 

  /* Initialize attributes */
  this->m_base = NULL; /* mcast::Publisher instance */
  this->m_participant = NULL; /* core::Participant instance */

  log_trace("Publisher_Impl::Initialize - Leaving method"); 

  return;

};

/* Accessor methods */

/* Miscellaneous methods */

RET_STATUS Publisher_Impl::Configure (void)
{

  log_trace("Publisher_Impl::Configure - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  /* Configure base class */
  if (Participant_Configure((Participant*) this) != STATUS_SUCCESS)
    {
      log_error("Publisher_Impl::Configure - Failed to configure participant"); 
      return status;
    }

  /* Create generic publisher, if necessary */
  if ((this->m_base != NULL) && 
      ((strcmp((this->m_base)->GetMCastGroup(), this->GetMCastGroup()) != 0) ||
       ((this->m_base)->GetMCastPort() != this->GetMCastPort()) ||
       ((this->m_base)->GetInterface() != this->GetInterface())))
    {
      log_debug("Publisher_Impl::Configure - Closing mcast::Publisher instance");
      (this->m_base)->Close();
    }

  if (this->m_base == NULL) { log_debug("Publisher::Configure - Creating mcast::Publisher instance"); this->m_base = new mcast::Publisher_Impl (); }
  log_debug("Publisher_Impl::Configure - Configure mcast::Publisher instance");
  (this->m_base)->SetInterface(this->GetInterface()); (this->m_base)->SetMCastGroup(this->GetMCastGroup()); (this->m_base)->SetMCastPort(this->GetMCastPort()); (this->m_base)->Open();

  log_debug("Publisher_Impl::Configure - Defining mcast::Publisher buffer and size");
  (this->m_base)->SetBuffer(this->GetBuffer(), this->GetSize());

  status = STATUS_SUCCESS; 
  
  log_trace("Publisher_Impl::Configure - Leaving method"); 

  return status;

}; 

RET_STATUS Publisher_Impl::Publish (void) 
{ 

  log_trace("Publisher_Impl::Publish - Entering method"); 

  RET_STATUS status = STATUS_ERROR;

  AnyObject* ref = NULL;
  uint_t index = 0;

  while ((ref = ObjectDatabase_GetInstance(index)) != NULL)
    {

      log_info("Publisher_Impl::Publish - Found registered instance");

      sdn::core::Participant_Impl* participant = (sdn::core::Participant_Impl*) ref;
      char* p_buf = (char*) this->GetBuffer(); uint_t max_size = this->GetSize();

      snprintf(p_buf, max_size, "<sdn:message group=\"discovery\" qualifier=\"announce\"><participant host=\"%s\" name=\"%s\" pid=\"%u\" role=\"", this->m_host_name, this->m_prog_name, this->m_prog_id); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      if (ref->IsType(OBJTYPE_CORE_PUBLISHER) == true)
	{
	  log_info("Publisher_Impl::Publish - Hold publisher on '%s'", participant->GetTopicName());
	  strncpy(p_buf, (char*) "publisher\"/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
	}
      else if (ref->IsType(OBJTYPE_CORE_SUBSCRIBER) == true)
	{
	  log_info("Publisher_Impl::Publish - Hold subscriber on '%s'", participant->GetTopicName());
	  strncpy(p_buf, (char*) "publisher\"/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
	}

      /* Serialize topic definition */
      (participant->m_topic)->SerializeType(p_buf, max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      strncpy(p_buf, (char*) "</participant></sdn:message>", max_size);

      /* Publish discovery message on the network */
      log_info("Publisher_Impl::Publish - Message '%s'", (char*) this->GetBuffer());
      if (this->m_base != NULL) (this->m_base)->Publish();

      index += 1;

    }

  status = STATUS_SUCCESS;

  log_trace("Publisher_Impl::Publish - Leaving method"); 

  return status; 

};

RET_STATUS Publisher_Impl::Register (sdn::core::Participant_Impl* ref) 
{ 

  this->m_participant = ref; 

    {

      char* p_buf = (char*) this->GetBuffer(); uint_t max_size = this->GetSize();

      snprintf(p_buf, max_size, "<sdn:message group=\"discovery\" qualifier=\"join\"><participant host=\"%s\" name=\"%s\" pid=\"%u\" role=\"", this->m_host_name, this->m_prog_name, this->m_prog_id); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      if (ref->IsType(OBJTYPE_CORE_PUBLISHER) == true)
	{
	  strncpy(p_buf, (char*) "publisher\"/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
	}
      else if (ref->IsType(OBJTYPE_CORE_SUBSCRIBER) == true)
	{
	  strncpy(p_buf, (char*) "subscriber\"/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
	}

      /* Serialize topic definition */
      (ref->m_topic)->SerializeType(p_buf, max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      strncpy(p_buf, (char*) "</participant></sdn:message>", max_size);

      /* Publish discovery message on the network */
      log_notice("Publisher_Impl::Register - Message '%s'", (char*) this->GetBuffer());
      if (this->m_base != NULL) (this->m_base)->Publish();

    }

  return STATUS_SUCCESS; 

};

RET_STATUS Publisher_Impl::Remove (sdn::core::Participant_Impl* ref) 
{ 

    {

      char* p_buf = (char*) this->GetBuffer(); uint_t max_size = this->GetSize();

      snprintf(p_buf, max_size, "<sdn:message group=\"discovery\" qualifier=\"leave\"><participant host=\"%s\" name=\"%s\" pid=\"%u\" role=\"", this->m_host_name, this->m_prog_name, this->m_prog_id); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      if (ref->IsType(OBJTYPE_CORE_PUBLISHER) == true)
	{
	  strncpy(p_buf, (char*) "publisher\"/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
	}
      else if (ref->IsType(OBJTYPE_CORE_SUBSCRIBER) == true)
	{
	  strncpy(p_buf, (char*) "subscriber\"/>", max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */
	}

      /* Serialize topic definition */
      (ref->m_topic)->SerializeType(p_buf, max_size); max_size -= strlen(p_buf); p_buf += strlen(p_buf); /* Re-align pointer */

      strncpy(p_buf, (char*) "</participant></sdn:message>", max_size);

      /* Publish discovery message on the network */
      log_notice("Publisher_Impl::Remove - Message '%s'", (char*) this->GetBuffer());
      if (this->m_base != NULL) (this->m_base)->Publish();

    }

  this->m_participant = NULL; 

  return STATUS_SUCCESS; 

};

/* Constructor methods */

Publisher_Impl::Publisher_Impl (void) { this->SetInstanceType(OBJTYPE_DISC_PUBLISHER); /* Initialize attributes */ this->Initialize(); return; };
Publisher_Impl::Publisher_Impl (char* iface) { this->SetInstanceType(OBJTYPE_DISC_PUBLISHER); /* Initialize attributes */ this->Initialize(); this->SetInterface(iface); /* Create mcast::Publisher */ this->Configure(); return; };

/* Destructor method */

Publisher_Impl::~Publisher_Impl (void) 
{ 

  log_trace("Publisher_Impl::~Publisher_Impl - Entering method"); 

  /* Release resources */
  if (this->m_base != NULL) delete this->m_base; this->m_base = NULL; 

  log_trace("Publisher_Impl::~Publisher_Impl - Leaving method"); 

  return; 

}; 

}; /* namespace disc */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
