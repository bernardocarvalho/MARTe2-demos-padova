/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/sdn-subscriber.cpp $
* $Id: sdn-subscriber.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Done - Implement Receive with timeout
	
   ToDo - Implement SubscriberThread with spinlock in lieu of blocking reception 
        - Implement packet and latency statistics computation after callback 
 */


/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
#include "sdn-api.h" /* SDN core library - API definition */

#include "sdn-header.h"
#include "sdn-footer.h"
#include "sdn-topic.h"
#include "sdn-packet.h"

#include "core-participant.h"
#include "core-subscriber.h"

#include "disc-publisher.h"

#include "sdn-participant.h"
//#include "sdn-subscriber.h" /* This class definition */

/* Constants */

#define OBJTYPE_SDN_SUBSCRIBER (char*) "sdn::Subscriber_Base"

#define DEFAULT_SUBSCRIBER_TIMEOUT 1000000000 /* 1s */

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::sub"

/* Type definition */

namespace sdn {

class Subscriber_Base : public Participant_Impl /* Base class */
{

  private:

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Do (void) { return this->Receive(); }; /* Specializes virtual method */

    virtual RET_STATUS Receive (uint64_t timeout) = 0; /* Pure virtual method */
    virtual RET_STATUS Receive (void) = 0;           /* Pure virtual method */

    /* Constructor methods */
    Subscriber_Base (void) { this->SetInstanceType(OBJTYPE_SDN_SUBSCRIBER); return; };

    /* Destructor method */
   ~Subscriber_Base (void) {};

}; 

class Subscriber_Impl : public Subscriber_Base
{

  private:

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Configure (void);
    RET_STATUS Receive (uint64_t timeout);
    RET_STATUS Receive (void);

    /* Constructor methods */
    Subscriber_Impl (void) { /* Initialize resources */ this->Initialize(); return; };
    Subscriber_Impl (Metadata_t& mdata) { /* Initialize resources */ this->Initialize(); this->SetMetadata(mdata); return; };
    Subscriber_Impl (const char* name) { /* Initialize resources */ this->Initialize(); this->SetTopicName(name); return; };
    Subscriber_Impl (Topic& topic) { /* Initialize resources */ this->Initialize(); /* WARNING - Topic externally instantiated should not be destroyed upon Participant destruction */ (this->m_base)->m_mdata = topic.m_meta; (this->m_base)->m_topic = &topic; (this->m_base)->m_ext_topic = true; return; };

    /* Destructor method */
   ~Subscriber_Impl (void) { (this->m_disc)->Remove(this->m_base); if (this->m_base != NULL) delete (core::Subscriber_Impl*) this->m_base; this->m_base = NULL; return; };

};
#if 0
typedef class Subscriber_Asyn : public Subscriber_Impl
{

  private:

    base::AnyThread* m_thread; /* Thread to manage subscriber instance */
    Statistics<uint64_t>* m_stats;

    void (* m_cb) (void*); /* Routine called upon topic reception */
    void* m_attr;          /* Routine attribute */

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */
    RET_STATUS Launch (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Launch(); return status; };
    RET_STATUS Terminate (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Terminate(); return status; };

    /* Accessor methods */
    RET_STATUS SetAffinity (uint_t core) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetAffinity(core); return status; };
    RET_STATUS SetCallback (void (* cb)(void*)) { this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { this->m_attr = attr; this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetPriority (uint_t policy, uint_t priority) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetPriority(policy, priority); return status; };

    /* Miscellaneous methods */
    RET_STATUS Preamble (void) { return this->Configure(); };
    RET_STATUS Do (void);

    /* Constructor methods */
    Subscriber_Asyn (void) : Subscriber_Impl() { /* Initialize resources */ this->Initialize(); return; };
    Subscriber_Asyn (Metadata_t& mdata) : Subscriber_Impl(mdata) { /* Initialize resources */ this->Initialize(); return; };
    Subscriber_Asyn (char* name) : Subscriber_Impl(name) { /* Initialize resources */ this->Initialize(); return; };
    Subscriber_Asyn (Topic& topic) : Subscriber_Impl(topic) { /* Initialize resources */ this->Initialize(); return; };

    /* Destructor method */
   ~Subscriber_Asyn (void) { if (this->m_thread != NULL) delete this->m_thread; if (this->m_stats != NULL) delete this->m_stats; };

} SubscriberThread; /* For backward compatibility purposes with v1.0 */
#endif
/* Global variables */

/* Function declaration */

/* Function definition */
#if 0
static void Subscriber_Asyn_Preamble (Subscriber_Asyn* self) { if (self != NULL) self->Preamble(); return; };
static void Subscriber_Asyn_CB (Subscriber_Asyn* self) { if (self != NULL) self->Do(); return; };
#endif
/* Initializer methods */

void Subscriber_Impl::Initialize (void) 
{ 

  log_trace("Subscriber_Impl::Initialize - Entering method");

  /* Initialize attributes */
  this->m_base = NULL; 

  /* Acquire resources */
  log_debug("Subscriber_Impl::Initialize - Creating core::Subscriber instance"); 
  this->m_base = (core::Participant_Impl*) new core::Subscriber_Impl ();

  log_trace("Subscriber_Impl::Initialize - Leaving method");

  return; 

}
#if 0
void Subscriber_Asyn::Initialize (void)
{

  log_trace("Subscriber_Asyn::Initialize - Entering method");

  /* Create thread instance */
  char thread_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  snprintf(thread_name, STRING_MAX_LENGTH, "Subscriber_Asyn_%s", this->GetTopicName());

  this->m_thread = new base::AnyThread ((char*) thread_name);
  (this->m_thread)->SetPreamble((void (*) (void*)) &Subscriber_Asyn_Preamble, (void*) this); 
  (this->m_thread)->SetCallback((void (*) (void*)) &Subscriber_Asyn_CB, (void*) this);
  (this->m_thread)->SetPeriod(0L); /* Blocking callback */

  this->m_stats = new Statistics<uint64_t> (); (this->m_stats)->Reset();

  this->m_cb = NULL; this->m_attr = NULL;

  log_trace("Subscriber_Asyn::Initialize - Leaving method");

  return; 

};
#endif
/* Accessor methods */

bool Subscriber_Iface::IsInitialized (void) { return (this->p_impl)->IsInitialized(); };
    
char* Subscriber_Iface::GetInterface (void) { return (this->p_impl)->GetInterface(); };
char* Subscriber_Iface::GetTopicName (void) { return (this->p_impl)->GetTopicName(); };
uint_t Subscriber_Iface::GetTopicSize (void) { return (this->p_impl)->GetTopicSize(); };
    
RET_STATUS Subscriber_Iface::SetInterface (const char* name) { return (this->p_impl)->SetInterface(name); };
RET_STATUS Subscriber_Iface::SetTopicName (const char* name) { return (this->p_impl)->SetTopicName(name); };
RET_STATUS Subscriber_Iface::SetMetadata (Metadata_t& mdata) { return (this->p_impl)->SetMetadata(mdata); };
    
RET_STATUS Subscriber_Iface::CopyTopicInstance (void* instance, uint_t size) { return (this->p_impl)->CopyTopicInstance(instance, size); };
void* Subscriber_Iface::GetTopicHeader (void) { return (this->p_impl)->GetTopicHeader(); };
void* Subscriber_Iface::GetTopicFooter (void) { return (this->p_impl)->GetTopicFooter(); };
void* Subscriber_Iface::GetTopicInstance (void) { return (this->p_impl)->GetTopicInstance(); };
    
RET_STATUS Subscriber_Iface::SetCallback (void (* cb)(void*)) { return (this->p_impl)->SetCallback(cb); };
RET_STATUS Subscriber_Iface::SetCallback (void (* cb)(void*), void* attr) { return (this->p_impl)->SetCallback(cb, attr); };

/* Miscellaneous methods */

RET_STATUS Subscriber_Iface::Configure (void)
{ 

  RET_STATUS status = STATUS_ERROR; 

  status = (this->p_impl)->Configure();

  /* For backward compatibility purposes with v1.0 */
  this->m_topic = ((this->p_impl)->m_base)->m_topic;
  this->m_packet = ((this->p_impl)->m_base)->m_packet; 
  if (this->m_packet != NULL) this->m_header = (this->m_packet)->GetHeader();
  if (this->m_packet != NULL) this->m_footer = (this->m_packet)->GetFooter();

  return status; 

};

RET_STATUS Subscriber_Iface::Receive (uint64_t timeout) { return (this->p_impl)->Receive(timeout); };
RET_STATUS Subscriber_Iface::Receive (void) { return (this->p_impl)->Receive(); };
    
RET_STATUS Subscriber_Impl::Configure (void)
{ 

  log_trace("Subscriber_Impl::Configure - Entering method");

  RET_STATUS status = STATUS_ERROR;

  /* Configure base class */
  if (Participant_Configure((Participant_Impl*) this) != STATUS_SUCCESS)
    {
      log_error("Subscriber_Impl::Configure - Failed to configure participant"); 
      return status;
    }
  
  log_debug("Subscriber_Impl::Configure - Configure core::Subscriber instance"); 
  if ((this->m_base)->Configure() != STATUS_SUCCESS)
    {
      log_error("Subscriber_Impl::Configure - Failed to configure core::Subscriber instance"); 
      return status;
    }

  log_debug("Subscriber_Impl::Configure - Notify disc::Publisher instance");
  (this->m_disc)->Register(this->m_base);

  status = STATUS_SUCCESS; 
  
  return status; 

};

RET_STATUS Subscriber_Impl::Receive (uint64_t timeout)
{ 

  log_trace("Subscriber_Impl::Receive - Entering method");

  RET_STATUS status = STATUS_ERROR; 

  status = ((core::Subscriber_Impl*) this->m_base)->Receive(timeout);

  log_trace("Subscriber_Impl::Receive - Leaving method");

  return status; 

};

RET_STATUS Subscriber_Impl::Receive (void) 
{ 

  log_trace("Subscriber_Impl::Receive - Entering method");

  RET_STATUS status = STATUS_ERROR; 

  status = ((core::Subscriber_Impl*) this->m_base)->Receive();
      
  log_trace("Subscriber_Impl::Receive - Leaving method");

  return status; 

};
#if 0
RET_STATUS Subscriber_Asyn::Do (void)
{

  log_trace("Subscriber_Asyn::Do - Entering method");

  RET_STATUS status = STATUS_ERROR;

  /* ToDo - Spinlock mode when knowing the expected period */

  if (this->GetTopicInstance() == NULL)
    {
      log_debug("Subscriber_Asyn::Do - Skip execution - No topic instance defined");
      wait(DEFAULT_SUBSCRIBER_TIMEOUT);
    }
#if 0
  else if (this->Receive() != STATUS_SUCCESS) /* Blocking receive */
#else
  else if (this->Receive(DEFAULT_SUBSCRIBER_TIMEOUT) != STATUS_SUCCESS) /* Blocking receive with timeout */
#endif
    {
      log_warning("Subscriber_Asyn::Do - Subscriber::Receive failed");
    }
  else 
    {
      log_debug("Subscriber_Asyn::Do - Subscriber::Receive successful at '%lu'", get_time());

      /* Callback, if any */
      if (this->m_cb != NULL) (*(this->m_cb))(this->m_attr);

      /* Compute statistics */
      Header_t* p_header = (Header_t*) this->GetTopicHeader();

      if (p_header->recv_time > p_header->send_time)
	{
	  uint64_t latency = p_header->recv_time - p_header->send_time;

	  if ((this->m_stats)->PushSample(latency) == true)
	    {
	      log_info("Subscriber_Asyn::Do - Latency statistics over '%u' samples are '%lu %lu %lu %lu' [nsec]", (this->m_stats)->GetSize(), (this->m_stats)->GetAvg(), (this->m_stats)->GetStd(), (this->m_stats)->GetMin(), (this->m_stats)->GetMax());
	      (this->m_stats)->Reset();
	    }
	}

      status = STATUS_SUCCESS;
    }

  log_trace("Subscriber_Asyn::Do - Leaving method");

  return status; 

};
#endif
/* Constructor methods */

Subscriber_Iface::Subscriber_Iface (void)
{

  log_trace("Subscriber_Iface::Subscriber_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Subscriber_Impl ();

  log_trace("Subscriber_Iface::Subscriber_Iface - Leaving method"); 

  return;

};

  Subscriber_Iface::Subscriber_Iface (Metadata_t& mdata)
{

  log_trace("Subscriber_Iface::Subscriber_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Subscriber_Impl (mdata);

  log_trace("Subscriber_Iface::Subscriber_Iface - Leaving method"); 

  return;

};

Subscriber_Iface::Subscriber_Iface (const char* name)
{

  log_trace("Subscriber_Iface::Subscriber_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Subscriber_Impl (name);

  log_trace("Subscriber_Iface::Subscriber_Iface - Leaving method"); 

  return;

};

Subscriber_Iface::Subscriber_Iface (Topic& topic)
{

  log_trace("Subscriber_Iface::Subscriber_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Subscriber_Impl (topic);

  log_trace("Subscriber_Iface::Subscriber_Iface - Leaving method"); 

  return;

};

/* Destructor method */

Subscriber_Iface::~Subscriber_Iface (void)
{
        
  log_trace("Subscriber_Iface::~Subscriber_Iface - Entering method");
        
  /* Release resources */
  if (this->p_impl != NULL) delete this->p_impl; this->p_impl= NULL;
        
  log_trace("Subscriber_Iface::~Subscriber_Iface - Leaving method");
        
  return;
        
};

/* Display methods */

}; /* namespace sdn */

#undef LOG_ALTERN_SRC
