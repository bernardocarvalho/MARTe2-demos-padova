/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/library/core-publisher.cpp $
* $Id: core-publisher.cpp 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */
#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */
#include "sdn-ucast.h" /* SDN core library - API definition (sdn::ucast) */
#include "sdn-core.h" /* SDN core library - API definition (sdn::core) */

#include "sdn-packet.h"
#include "sdn-header.h"
#include "sdn-topic.h"

#include "core-participant.h"
#include "core-publisher.h" /* This class definition */

/* Constants */

#ifndef UNIT_VERSION
#define UNIT_VERSION UNIT_VERSION_UID(1,0,0)
#endif

#define USE_PACKET_FOOTER
#if UNIT_VERSION < UNIT_VERSION_UID(2,0,0)
#undef USE_PACKET_FOOTER
#endif

#define DEFAULT_PUBLISHER_PERIOD 1000000000L /* 1Hz */
#define DEFAULT_PUBLISHER_WAIT_PERIOD 10000L

#undef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC "sdn::core"

/* Type definition */

namespace sdn {

namespace core {

/* Global variables */

/* Function declaration */

/* Function definition */

static void Publisher_Asyn_Preamble (Publisher_Asyn* self) { if (self != NULL) self->Preamble(); return; };
static void Publisher_Asyn_CB (Publisher_Asyn* self) { if (self != NULL) self->Do(); return; };

/* Initializer methods */

void Publisher_Asyn::Initialize (void)
{

  log_trace("Publisher_Asyn::Initialize - Entering method");

  /* Create thread instance */
  char thread_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  snprintf(thread_name, STRING_MAX_LENGTH, "Publisher_Asyn_%s", this->GetTopicName());

  this->m_thread = new AnyThread ((char*) thread_name);
  (this->m_thread)->SetPreamble((void (*) (void*)) &Publisher_Asyn_Preamble, (void*) this); 
  (this->m_thread)->SetCallback((void (*) (void*)) &Publisher_Asyn_CB, (void*) this);
  (this->m_thread)->SetPeriod(DEFAULT_PUBLISHER_PERIOD);

  this->m_cb = NULL; this->m_attr = NULL;
  this->m_accuracy = DEFAULT_PUBLISHER_WAIT_PERIOD;
  this->m_synchronous = false; this->m_trigger = false;

  log_trace("Publisher_Asyn::Initialize - Leaving method");

  return; 

};

/* Initializer methods */

RET_STATUS Publisher_Asyn::Launch (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Launch(); return status; };
RET_STATUS Publisher_Asyn::Terminate (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Terminate(); return status; };

/* Accessor methods */

bool Publisher_Iface::IsInitialized (void) { return (this->p_impl)->IsInitialized(); };
    
char* Publisher_Iface::GetInterface (void) { return (this->p_impl)->GetInterface(); };
char* Publisher_Iface::GetTopicName (void) { return (this->p_impl)->GetTopicName(); };
uint_t Publisher_Iface::GetTopicSize (void) { return (this->p_impl)->GetTopicSize(); };
    
RET_STATUS Publisher_Iface::SetInterface (char* name) { return (this->p_impl)->SetInterface(name); };
RET_STATUS Publisher_Iface::SetTopicName (char* name) { return (this->p_impl)->SetTopicName(name); };
RET_STATUS Publisher_Iface::SetMetadata (Metadata_t& mdata) { return (this->p_impl)->SetMetadata(mdata); };
    
RET_STATUS Publisher_Iface::CopyTopicInstance (void* instance, uint_t size) { return (this->p_impl)->CopyTopicInstance(instance, size); };
void* Publisher_Iface::GetTopicHeader (void) { return (this->p_impl)->GetTopicHeader(); };
void* Publisher_Iface::GetTopicFooter (void) { return (this->p_impl)->GetTopicFooter(); };
void* Publisher_Iface::GetTopicInstance (void) { return (this->p_impl)->GetTopicInstance(); };
    
RET_STATUS Publisher_Iface::SetCallback (void (* cb)(void*)) { return (this->p_impl)->SetCallback(cb); };
RET_STATUS Publisher_Iface::SetCallback (void (* cb)(void*), void* attr) { return (this->p_impl)->SetCallback(cb, attr); };

RET_STATUS Publisher_Asyn::SetAffinity (uint_t core) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetAffinity(core); return status; };

RET_STATUS Publisher_Asyn::SetPeriod (uint64_t period, int64_t phase, uint64_t accuracy) 
{ 

  RET_STATUS status = STATUS_ERROR; 

  if (period == 0L)
    {
      this->m_accuracy = accuracy;
      this->m_trigger = false;
      this->m_synchronous = true;
    }

  if (this->m_thread != NULL) 
    { 
      (this->m_thread)->SetAccuracy(accuracy); 
      (this->m_thread)->SetPhase(phase); 
      status = (this->m_thread)->SetPeriod(period); 
    } 

  return status; 

};

RET_STATUS Publisher_Asyn::SetPriority (uint_t policy, uint_t priority) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetPriority(policy, priority); return status; };

/* Miscellaneous methods */

RET_STATUS Publisher_Iface::Configure (void) { return (this->p_impl)->Configure(); };
RET_STATUS Publisher_Iface::Publish (void) { return (this->p_impl)->Publish(); };
    
RET_STATUS Publisher_Impl::Configure (void) 
{ 

  log_trace("Publisher_Impl::Configure - Entering method");

  RET_STATUS status = STATUS_ERROR;

  /* Configure base class */
  if (Participant_Configure((Participant_Impl*) this) != STATUS_SUCCESS)
    {
      log_error("Publisher_Impl::Configure - Failed to configure participant"); 
      return status;
    }
#ifdef USE_PACKET_FOOTER  
  /* Prepare footer fields */
  char host_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;
  char prog_name [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  if (get_host_name(host_name) != STATUS_SUCCESS)
    {
      log_warning("get_host_name() failed");
    }
  else
    {
      log_debug("Host name is '%s'", host_name);
    }

  if (get_program_name(prog_name) != STATUS_SUCCESS)
    {
      log_warning("get_program_name() failed");
    }
  else
    {
      log_debug("Program name is '%s'", prog_name);
    }

  char source_id [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  snprintf((char*) source_id, STRING_MAX_LENGTH, "%s@%s", (char*) prog_name, (char*) host_name);

  uint_t source_uid = hash((char*) source_id);

  log_info("Set packet.footer.source_uid to '%u' (derived from '%s')", source_uid, (char*) source_id);

  ((this->m_packet)->GetFooter())->SetSourceUID(source_uid);
#endif
  /* Bug 7919 - Return error in case interface is invalid */
  if (net_is_interface_valid(this->GetInterface()) != true) 
    { 
      log_error("Publisher_Impl::Configure - Currently defined interface '%s' is not valid", this->GetInterface()); 
      return status; 
    }

  /* WARNING - This code does not allow for changing between MCAST and UCAST participants at runtime */

  /* Create generic publisher, if necessary */
  if ((this->m_base != NULL) && 
      ((strcmp((this->m_base)->GetAddress(), (this->m_topic)->GetMCastGroup()) != 0) ||
       ((this->m_base)->GetPort() != (this->m_topic)->GetMCastPort()) ||
       ((this->m_base)->GetSize() != (this->m_packet)->GetSize())))
    {
      log_debug("Publisher_Impl::Configure - Closing base::Publisher instance");
      (this->m_base)->Close();
    }

  if (this->m_base == NULL) 
    { 
      if (sdn_is_mcast_address((this->m_topic)->GetMCastGroup()) == true) { log_debug("Publisher::Configure - Creating mcast::Publisher instance"); this->m_base = (base::Publisher_Iface*) new mcast::Publisher (); }
      if (sdn_is_ucast_address((this->m_topic)->GetMCastGroup()) == true) { log_debug("Publisher::Configure - Creating ucast::Publisher instance"); this->m_base = (base::Publisher_Iface*) new ucast::Publisher (); }
    }

  log_debug("Publisher_Impl::Configure - Configuring base::Publisher instance");
  (this->m_base)->SetInterface(this->GetInterface()); (this->m_base)->SetAddress((this->m_topic)->GetMCastGroup()); (this->m_base)->SetPort((this->m_topic)->GetMCastPort()); (this->m_base)->Open();
  log_debug("Publisher_Impl::Configure - Defining base::Publisher buffer and size");
  (this->m_base)->SetBuffer((this->m_packet)->GetInstance(), (this->m_packet)->GetSize());

  status = STATUS_SUCCESS; 
  
  log_trace("Publisher_Impl::Configure - Leaving method");

  return status; 

};

RET_STATUS Publisher_Impl::Publish (void) 
{ 

  log_trace("Publisher_Impl::Publish - Entering method");

  RET_STATUS status = STATUS_ERROR;

  if (this->m_topic == NULL) /* Instantiated in sdn::core::Publisher::Configure */
    {
      log_error("Publisher_Impl::Publish - Un-initialized topic");
      return status;
    }
  else if ((this->m_topic)->IsInitialized() != true) /* Incomplete metadata: name only must be supported by XML topic definition file, else metadata must be complete enough */
    {
      log_error("Publisher_Impl::Publish - Un-initialized topic '%s'", (this->m_topic)->GetName());
      return status;
    }

  /* Update packet header - Only the timestamp now - Do the counter after */
  //((this->m_packet)->GetHeader())->UpdateInstance(); 
  ((this->m_packet)->GetHeader())->SetTimestamp(); /* Update only the timestamp */
#ifdef USE_PACKET_FOOTER  
  /* Update packet footer */
  ((this->m_packet)->GetFooter())->SetTopicCRC((this->m_topic)->GetInstanceChecksum()); 
#endif
  /* Invoke callback, if any */
  if (this->m_cb != NULL) { log_trace("Publisher_Impl::Publish - Invoke callback"); (*(this->m_cb))(this->m_attr); }

  /* Bug 7919 - mcast::Subscriber is not initialized in case of wrong interface */
  if (this->m_base != NULL) status = (this->m_base)->Publish(); 

  /* Update packet header - Prepare for next iteration, if any */
  ((this->m_packet)->GetHeader())->IncrCounter(); 

  log_trace("Publisher_Impl::Publish - Leaving method");

  return status;

};

RET_STATUS Publisher_Asyn::Do (void)
{

  log_trace("Publisher_Asyn::Do - Entering method");

  RET_STATUS status = STATUS_ERROR;

  while ((this->m_synchronous == true) && (__sync_val_compare_and_swap(&(this->m_trigger), true, false) == false)) wait_for(this->m_accuracy);

  if (this->GetTopicInstance() == NULL)
    {
      log_debug("Publisher_Asyn::Do - Skip execution - No topic instance defined");
      return status;
    }

  /* ToDo - Should be waiting for external trigger in case of synchronous operation */

  /* Callback, if any */
  if (this->m_cb != NULL) (*(this->m_cb))(this->m_attr);

  if (this->Publish() != STATUS_SUCCESS)
    {
      log_warning("Publisher_Asyn::Do - Publisher::Publish failed");
    }
  else 
    {
      log_debug("Publisher_Asyn::Do - Publisher::Publish successful at '%lu'", get_time());

      status = STATUS_SUCCESS;
    }

  log_trace("Publisher_Asyn::Do - Leaving method");

  return status; 

};

/* Constructor methods */

Publisher_Iface::Publisher_Iface (void)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl ();

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (Metadata_t& mdata)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (mdata);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (char* name)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (name);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Iface::Publisher_Iface (Topic& topic)
{

  log_trace("Publisher_Iface::Publisher_Iface - Entering method"); 

  /* Initialize attributes */
  this->p_impl = new Publisher_Impl (topic);

  log_trace("Publisher_Iface::Publisher_Iface - Leaving method"); 

  return;

};

Publisher_Base::Publisher_Base (void) { this->SetInstanceType(OBJTYPE_CORE_PUBLISHER); /* Initialize resources */ this->Initialize(); return; };

/* Destructor method */

Publisher_Iface::~Publisher_Iface (void)
{
        
  log_trace("Publisher_Iface::~Publisher_Iface - Entering method");
        
  /* Release resources */
  if (this->p_impl != NULL) delete this->p_impl; this->p_impl= NULL;
        
  log_trace("Publisher_Iface::~Publisher_Iface - Leaving method");
        
  return;
        
};

Publisher_Impl::~Publisher_Impl (void) 
{ 

  if (this->m_base != NULL)
    {
      /* ToDo - Call appropriate destructor */
      delete this->m_base; this->m_base = NULL; 
    }

  return; 

};

Publisher_Asyn::~Publisher_Asyn (void) { if (this->m_thread != NULL) delete this->m_thread; this->m_thread = NULL; return; };

/* Display methods */

}; /* namespace core */

}; /* namespace sdn */
#if 0
void* sdn_create_publisher (char* topic_name)
{

  sdn::Publisher* self = new sdn::Publisher (topic_name);

  self->Configure();

  return (void*) self;

};

RET_STATUS sdn_publish_topic (void* publisher, void* buffer, uint_t size)
{

  sdn::Publisher* self = (sdn::Publisher*) publisher; /* Warning */

  self->CopyTopicInstance(buffer, size);

  return self->Publish();

};
#endif
#undef LOG_ALTERN_SRC
