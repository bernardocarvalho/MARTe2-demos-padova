#ifndef CORE_PARTICIPANT_H
#define CORE_PARTICIPANT_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/core-participant.h $
* $Id: core-participant.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/*
  ToDo - Topic externally instantiated should not be destroyed upon Participant destruction 
*/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "sdn-topic.h"
#include "sdn-packet.h"

/* Constants */

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace base {

class AnyObject; /* Forward class declaration */

}; /* namespace base */

namespace core {

class Participant_Impl : public base::AnyObject
{

  private:

    char m_iface_name [STRING_MAX_LENGTH];
#if 0
    char m_topic_name [STRING_MAX_LENGTH];
#endif
    /* Initializer methods */
    void Initialize (void);

  public:

    Metadata_t m_mdata; /* To collect all metadata information */

    bool m_ext_topic; /* Topic externally provided */

    Packet* m_packet;
    Topic* m_topic;

    void (* m_cb) (void*); /* Routine called as part of message handling */
    void* m_attr;          /* Routine attribute */

    /* Initializer methods */

    /* Accessor methods */
    bool IsInitialized (void) { return (this->m_topic)->IsInitialized(); };

    char* GetInterface (void) { return (char*) this->m_iface_name; };
    char* GetTopicName (void) { return (char*) this->m_mdata.name; };
    uint_t GetTopicSize (void) { return this->m_mdata.size; };

    RET_STATUS SetInterface (const char* name);
    RET_STATUS SetMetadata (Metadata_t& mdata);
    RET_STATUS SetTopicName (const char* name);

    virtual RET_STATUS CopyTopicInstance (void* instance, uint_t size) = 0; /* Pure virtual method */ /* The data payload and not the instance of the class */
    void* GetTopicHeader (void) { return (void*) ((this->m_packet != NULL) ? ((this->m_packet)->GetHeader())->GetInstance() : NULL); }; /* The data payload and not the instance of the class */
    void* GetTopicFooter (void) { return (void*) ((this->m_packet != NULL) ? ((this->m_packet)->GetFooter())->GetInstance() : NULL); }; /* The data payload and not the instance of the class */
    void* GetTopicInstance (void) { return (void*) ((this->m_packet != NULL) ? (this->m_packet)->GetPayload() : NULL); }; /* The data payload and not the instance of the class */

    RET_STATUS SetCallback (void (* cb)(void*)) { this->m_cb = cb; return STATUS_SUCCESS; }; /* Routine called as part of message handling */
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { this->m_attr = attr; this->m_cb = cb; return STATUS_SUCCESS; }; /* Routine called as part of message handling */

    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) = 0;        /* Pure virtual method */
    virtual RET_STATUS Configure (void) = 0; /* Pure virtual method */

    /* Constructor methods */
    Participant_Impl (void);

    /* Destructor method */
   ~Participant_Impl (void);

   /* Display methods */

};

/* Global variables */

/* Function declaration */

RET_STATUS Participant_Configure (Participant_Impl* self);

/* Function definition */

}; /* namespace core */

}; /* namespace sdn */

using namespace sdn::core; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* CORE_PARTICIPANT_H */
