#ifndef CORE_PUBLISHER_H
#define CORE_PUBLISHER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/core-publisher.h $
* $Id: core-publisher.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "sdn-base.h" /* Privately scoped base classes definition */

//#include "mcast-participant.h"
//#include "mcast-publisher.h"

#include "core-participant.h"

#include "sdn-packet.h"
#include "sdn-header.h"
#include "sdn-topic.h"

/* Constants */

#define OBJTYPE_CORE_PUBLISHER (char*) "sdn::core::Publisher_Base"

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace core {

class Publisher_Base : public Participant_Impl /* Base class */
{

  private:

    /* Initializer methods */
    void Initialize (void) {};

  public:

    /* Initializer methods */

    /* Accessor methods */
    RET_STATUS CopyTopicInstance (void* instance, uint_t size) { RET_STATUS status = STATUS_ERROR; if ((this->m_topic)->GetSize() >= size) { memcpy(this->GetTopicInstance(), instance, size); status = STATUS_SUCCESS; } return status; };

    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) { return this->Publish(); }; /* Specializes virtual method */
    virtual RET_STATUS Publish (void) = 0; /* Pure virtual method */

    /* Constructor methods */
    Publisher_Base (void);

    /* Destructor method */
   ~Publisher_Base (void) { return; };

}; 

class Publisher_Impl : public Publisher_Base
{

  private:

    base::Publisher_Iface* m_base; /* Instantiate and publish to MCAST or UCAST socket */

    /* Initializer methods */
    void Initialize (void) { this->m_base = NULL; return; };

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    virtual RET_STATUS Configure (void);
    virtual RET_STATUS Publish (void);

    /* Constructor methods */
    Publisher_Impl (void) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Impl (Metadata_t& mdata) { /* Initialize resources */ this->Initialize(); this->SetMetadata(mdata); return; };
    Publisher_Impl (char* name) { /* Initialize resources */ this->Initialize(); this->SetTopicName(name); return; };
    Publisher_Impl (Topic& topic) { /* Initialize resources */ this->Initialize(); /* WARNING - Topic externally instantiated should not be destroyed upon Participant destruction */ this->m_mdata = topic.m_meta; this->m_topic = &topic; this->m_ext_topic = true; return; };

    /* Destructor method */
   ~Publisher_Impl (void);

};

typedef class Publisher_Asyn : public Publisher_Impl
{

  private:

    AnyThread* m_thread; /* Thread to manage publisher instance */

    uint64_t m_accuracy;
    bool m_synchronous;  /* Publication is triggered when topic is externally updated */
    volatile bool m_trigger;  /* Publication is triggered when topic is externally updated */

    void (* m_cb) (void*); /* Routine called before topic publication  */
    void* m_attr;          /* Routine attribute */

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */
    RET_STATUS Launch (void);
    RET_STATUS Terminate (void);

    /* Accessor methods */
    RET_STATUS SetAffinity (uint_t core);
    RET_STATUS SetCallback (void (* cb)(void*)) { this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { this->m_attr = attr; this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetPeriod (uint64_t period, int64_t phase = 0L, uint64_t accuracy = DEFAULT_THREAD_ACCURACY);
    RET_STATUS SetPriority (uint_t policy, uint_t priority);

    /* Miscellaneous methods */
    RET_STATUS Preamble (void) { return this->Configure(); };
    RET_STATUS Do (void);
    RET_STATUS Trigger (void) { return ((__sync_val_compare_and_swap(&(this->m_trigger), false, true)) ? STATUS_ERROR : STATUS_SUCCESS); };

    /* Constructor methods */
    Publisher_Asyn (void) : Publisher_Impl() { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (Metadata_t& mdata) : Publisher_Impl(mdata) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (char* name) : Publisher_Impl(name) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (Topic& topic) : Publisher_Impl(topic) { /* Initialize resources */ this->Initialize(); return; };

    /* Destructor method */
   ~Publisher_Asyn (void);

} PublisherThread; /* For backward compatibility purposes with v1.0 */

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace core */

}; /* namespace sdn */

using namespace sdn::core; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#if 0
/* Warning - Opaque pointers bear the risk of segfault when casting. The object returned should include both reference and type identifier */
void* sdn_create_publisher (char* topic_name);
RET_STATUS sdn_publish_topic (void* publisher, void* buffer, uint_t size);
#endif

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* CORE_PUBLISHER_H */
