#ifndef BASE64_H
#define BASE64_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/base64.h $
* $Id: base64.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Base64 encoding and decoding functions
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "types.h" /* Condensed integer type definition, RET_STATUS, etc. */
#include "tools.h"

/* Constants */

/* Type definition */

/* Global variables */

/* 6-bits values are mapped to the following symbols */
static const char __base64_alphabet [] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; 

/*
 '+' ASCII character corresponds to integer 43
 '/' ASCII character corresponds to integer 47
 '[0-9]' correspond to [48-57]
 '[A-Z]' correspond to [65-90]
 '[a-z]' correspond to [97-122]
*/

/* ASCII character - 43 is mapped to */
static const uint8_t __base64_reverse [] = { 
  62, 
 255, 255, 255, /* Invalid - These ASCII characters are not part of the base64 alphabet */
  63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61,   
 255, 255, 255, 255, 255, 255, 255, /* Invalid */
   0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 
 255, 255, 255, 255, 255, 255, /* Invalid */
  26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51
}; 

/* Function declaration */

/* Function definition */

static inline uint_t compute_encoded_buffer_size (uint_t size) { return (uint_t) (4 * ((size / 3) + (((size % 3) == 0) ? 0 : 1))); };
static inline uint_t compute_binary_buffer_size (char* encoded_buffer) { uint_t buffer_size = strlen(encoded_buffer); return (uint_t) ((buffer_size / 4 * 3) - ((encoded_buffer[buffer_size] == '=') ? 1 : 0) - ((encoded_buffer[buffer_size - 1] == '=') ? 1 : 0)); };

static inline void encode_block (uint8_t* binary_block, char* encoded_block) /* 24-bits in, 4 char out */
{

  uint_t index = 0;

  index = (binary_block[0] >> 2) & 0x3F; encoded_block[0] = __base64_alphabet[index];
  index = ((binary_block[0] << 4) & 0x30) + ((binary_block[1] >> 4) & 0x0F); encoded_block[1] = __base64_alphabet[index];
  index = ((binary_block[1] << 2) & 0x3C) + ((binary_block[2] >> 6) & 0x03); encoded_block[2] = __base64_alphabet[index];
  index = binary_block[2] & 0x3F; encoded_block[3] = __base64_alphabet[index];

}

static inline void decode_block (uint8_t* binary_block, char* encoded_block) /* 24-bits out, 4 char in */
{

  char encoded_bits [4]; /* Do not modify the encoded buffer ! */

  for (uint_t index = 0; index < 4; index += 1) if ((encoded_block[index] >= 43) && (encoded_block[index] <= 122)) encoded_bits[index] = encoded_block[index] - 43; /* Offset the ASCII characters to the lowest in the alphabet */

  binary_block[0] = ((__base64_reverse[(uint_t) encoded_bits[0]] << 2) & 0xFC) + ((__base64_reverse[(uint_t) encoded_bits[1]] >> 4) & 0x03);
  binary_block[1] = ((__base64_reverse[(uint_t) encoded_bits[1]] << 4) & 0xF0) + ((encoded_bits[2] == '=') ? 0 : ((__base64_reverse[(uint_t) encoded_bits[2]] >> 2) & 0x0F));
  binary_block[2] = ((encoded_bits[2] == '=') ? 0 : ((__base64_reverse[(uint_t) encoded_bits[2]] << 6) & 0xC0)) + ((encoded_bits[3] == '=') ? 0 : (__base64_reverse[(uint_t) encoded_bits[3]] & 0x3F));

}

static inline uint_t base64_encode (uint8_t* binary_buffer, uint_t binary_size, char* encoded_buffer, uint_t buffer_size) 
{

  uint_t size = compute_encoded_buffer_size(binary_size);

  if (buffer_size < size + 1) { /* sstrncpy(encoded_buffer, STRING_UNDEFINED, buffer_size); */ return 0; } /* Null terminated string */

  uint8_t* p_in = binary_buffer;
  char* p_out = encoded_buffer;

  while (binary_size > 3) { encode_block(p_in, p_out); p_in += 3; p_out += 4; binary_size -= 3; }

  if (binary_size == 1) { uint8_t binary_bits [3]; binary_bits[0] = p_in[0]; binary_bits[1] = 0; binary_bits[2] = 0; encode_block((uint8_t*) binary_bits, p_out); p_out[2] = '='; p_out[3] = '='; p_out += 4; }
  if (binary_size == 2) { uint8_t binary_bits [3]; binary_bits[0] = p_in[0]; binary_bits[1] = p_in[1]; binary_bits[2] = 0; encode_block((uint8_t*) binary_bits, p_out); p_out[3] = '='; p_out += 4; }

  *p_out = 0; /* Null terminated string */

  return size;

};

static inline uint_t base64_decode (uint8_t* binary_buffer, uint_t binary_size, char* encoded_buffer, uint_t buffer_size) 
{

  uint_t size = compute_binary_buffer_size(encoded_buffer);

  if (buffer_size > strlen(encoded_buffer)) buffer_size = strlen(encoded_buffer); /* Null terminated string */

  if (buffer_size % 4 != 0) return 0; 

  if (binary_size < compute_binary_buffer_size(encoded_buffer)) return 0; 

  uint8_t* p_out = binary_buffer;
  char* p_in = encoded_buffer;

  while ((binary_size > 3) && (buffer_size > 4)) { decode_block(p_out, p_in); p_in += 4; p_out += 3; binary_size -= 3; buffer_size -= 4; }

  /* The last encoded block */
  if ((binary_size > 2) && (p_in[2] != '=') && (p_in[3] != '=')) { decode_block(p_out, p_in); p_in += 4; p_out += 3; }
  if ((binary_size > 1) && (p_in[2] != '=') && (p_in[3] == '=')) { uint8_t binary_bits [3]; decode_block((uint8_t*) binary_bits, p_in); p_out[0] = binary_bits[0]; p_out[1] = binary_bits[1]; p_in += 4; p_out += 2; }
  if ((binary_size > 0) && (p_in[2] == '=') && (p_in[3] == '=')) { uint8_t binary_bits [3]; decode_block((uint8_t*) binary_bits, p_in); p_out[0] = binary_bits[0]; p_in += 4; p_out += 1; }

  return size;

};

#endif /* BASE64_H */

