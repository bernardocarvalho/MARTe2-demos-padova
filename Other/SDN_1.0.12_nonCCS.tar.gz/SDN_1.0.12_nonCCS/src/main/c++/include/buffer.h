#ifndef BUFFER_H
#define BUFFER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/buffer.h $
* $Id: buffer.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Memory management classes
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* ToDo - Atomic operations for FIFO management */

/* Global header files */

#include <string.h> /* memcpy, etc. */

/* Local header files */

#include "types.h"

/* Constants */

#define DEFAULT_BUFFER_SIZE 1024
#define DEFAULT_BUFFER_WIDTH  32

/* Type definition */

class BlockMemory /* Buffer of memory blocks */
{ 

  private:

    volatile bool m_lock; /* Locking flag for atomic operations */

    uint_t m_size;  /* Size of individual memory blocks */
    uint_t m_width; /* Number of contiguous memory blocks */

    uint8_t* m_buffer; /* The allocated memory buffer */

    /* Initializer methods */
    void Allocate (void) { uint_t size = this->m_width * this->m_size; this->m_buffer = new uint8_t [size]; return; }
    void Reset (void) { uint_t size = this->m_width * this->m_size; memset(this->m_buffer, 0, size); return; };

  protected:

  public:

    /* Initializer methods */

    /* Accessor methods */
    uint_t GetSize (void) { return this->m_size; };
    uint_t GetWidth (void) { return this->m_width; };

    void* GetDataBlockReference (uint_t index) { void* ref = NULL; if (index < this->m_width) ref = ((void*) &(this->m_buffer[index * this->m_size])); return ref; };

    RET_STATUS GetDataBlock (void* block, uint_t index) { RET_STATUS status = STATUS_ERROR; if (index < this->m_width) { memcpy(block, this->GetDataBlockReference(index), this->m_size); status = STATUS_SUCCESS; } return status; };
    RET_STATUS PutDataBlock (void* block, uint_t index) { RET_STATUS status = STATUS_ERROR; if (index < this->m_width) { memcpy(this->GetDataBlockReference(index), block, this->m_size); status = STATUS_SUCCESS; } return status; };
	
    /* Miscellaneous methods */
    bool AcquireLock (void) { /* Take lock */ while (__sync_val_compare_and_swap(&(this->m_lock), false, true)); return true; };
    bool ReleaseLock (void) { return __sync_val_compare_and_swap(&(this->m_lock), true, false); };
    bool TryLock (void) { return ((__sync_val_compare_and_swap(&(this->m_lock), false, true)) ? false : true); };

    /* Constructor methods */ 
    BlockMemory (void) { this->m_size = DEFAULT_BUFFER_SIZE; this->m_width = DEFAULT_BUFFER_WIDTH; this->Allocate(); this->Reset(); this->m_lock = false; return; };
    BlockMemory (uint_t size) { this->m_size = size; this->m_width = DEFAULT_BUFFER_WIDTH; this->Allocate(); this->Reset(); this->m_lock = false; return; };
    BlockMemory (uint_t size, uint_t width) { this->m_size = size; this->m_width = width; this->Allocate(); this->Reset(); this->m_lock = false; return; };

    /* Destructor method */
   ~BlockMemory () { if (this->m_buffer != NULL) delete [] this->m_buffer; this->m_lock = false; return; };

};

template <class Type> class Buffer {

  private:

    volatile bool m_lock; /* Locking flag for atomic operations */
    uint_t m_size;
    Type  m_default;
    Type* m_buffer;
    Type* m_copy;

    /* Initializer methods */
    void Allocate (void) { this->m_buffer = (Type*) NULL; this->m_buffer = new Type [this->m_size]; if (this->m_buffer != NULL) { uint_t size = this->m_size * sizeof(Type); memset(this->m_buffer, 0, size); } return; }

  protected:

  public:

    /* Initializer methods */
    void Reset (void) { for (uint_t index = 0; index < this->m_size; index += 1) PutData(this->m_default, index); return; };
    void Initialize (Type& data) { this->m_default = data; this->Reset(); return; };

    /* Accessor methods */
    uint_t GetSize (void) { return m_size; };
    Type GetData (uint_t index) { return this->m_buffer[index]; };

    void GetData (Type& data, uint_t index) { data = this->m_buffer[index]; return; };
    void PutData (Type& data, uint_t index) { this->m_buffer[index] = data; return; };

    /* Miscellaneous methods */
    bool AcquireLock (void) { /* Take lock */ while (__sync_val_compare_and_swap(&(this->m_lock), false, true)); return true; };
    bool ReleaseLock (void) { return __sync_val_compare_and_swap(&(this->m_lock), true, false); };
    bool TryLock (void) { return ((__sync_val_compare_and_swap(&(this->m_lock), false, true)) ? false : true); };

    /* Constructor methods */ 
    Buffer (void) { this->m_size = DEFAULT_BUFFER_SIZE; this->Allocate(); this->m_lock = false; return; };
    Buffer (uint_t size) { this->m_size = size; this->Allocate(); this->m_lock = false; return; };
    Buffer (uint_t size, Type& data) { this->m_size = size; this->Allocate(); this->Initialize(data); this->m_lock = false; return; };

    /* Destructor method */
   ~Buffer () { if (this->m_buffer != NULL) delete [] this->m_buffer; this->m_lock = false; return; };

};

template <class Type> class CircularBuffer : public Buffer<Type> {

  private:

    uint_t m_index;

    /* Initializer methods */
    void Initialize (void) { this->m_index = 0; return; };

  protected:

  public:

    /* Initializer methods */

    /* Accessor methods */
    RET_STATUS PushData (Type& data) { this->PutData(data, this->m_index); this->m_index += 1; if (m_index == this->GetSize()) this->m_index = 0; return STATUS_SUCCESS; };
    RET_STATUS PushData (Type& data_in, Type& data_out) { this->GetData(data_out, this->m_index); this->PutData(data_in, this->m_index); this->m_index += 1; if (this->m_index == this->GetSize()) this->m_index = 0; return STATUS_SUCCESS; };

    /* Miscellaneous methods */

    /* Constructor methods */
    CircularBuffer () : Buffer<Type> ((uint_t) DEFAULT_BUFFER_SIZE) { this->Initialize(); return; };
    CircularBuffer (uint_t size) : Buffer<Type> (size) { this->Initialize(); return; };
    CircularBuffer (uint_t size, Type data) : Buffer<Type> (size, data) { this->Initialize(); return; };

    /* Destructor method */
   ~CircularBuffer () { /* Nothing further to do than the default base class destructor */ }; 

};

class BlockMemory_FIFO : public BlockMemory { /* First-In-First-Out buffer management */

  private:

    uint_t m_count, m_head, m_tail;

    /* Initializer methods */
    void Initialize (void) { this->m_count = this->m_head = this->m_tail = 0; return; };

  protected:

  public:

    /* Initializer methods */

    /* Accessor methods */
    bool IsEmpty (void) { return (this->m_count == 0); };
    bool IsFull (void)  { return (this->m_count == this->GetWidth()); };

    uint_t GetCount (void) { return this->m_count; };

    void* GetInDataBlockReference (void) { void* ref = NULL; if (!this->IsFull()) { ref = this->GetDataBlockReference(this->m_tail); } return ref; };
    void ReleaseInDataBlockReference (void) { this->m_count += 1; this->m_tail += 1; if (this->m_tail == this->GetWidth()) this->m_tail = 0; return; };

    void* GetOutDataBlockReference (void) { void* ref = NULL; if (!this->IsEmpty()) { ref = this->GetDataBlockReference(this->m_head); } return ref; };
    void ReleaseOutDataBlockReference (void) { this->m_count -= 1; this->m_head += 1; if (this->m_head == this->GetWidth()) this->m_head = 0; return; };

    RET_STATUS PullDataBlock (void* block) { if (this->IsEmpty()) return STATUS_ERROR; this->GetDataBlock(block, this->m_head); this->m_count -= 1; this->m_head += 1; if (this->m_head == this->GetWidth()) this->m_head = 0; return STATUS_SUCCESS; };
    RET_STATUS PushDataBlock (void* block) { if (this->IsFull())  return STATUS_ERROR; this->PutDataBlock(block, this->m_tail); this->m_count += 1; this->m_tail += 1; if (this->m_tail == this->GetWidth()) this->m_tail = 0; return STATUS_SUCCESS; };

    RET_STATUS PullDataBlock (void* block, int64_t timeout) { return STATUS_ERROR; };
    RET_STATUS PushDataBlock (void* block, int64_t timeout) { return STATUS_ERROR; };

    /* Miscellaneous methods */

    /* Constructor methods */
    BlockMemory_FIFO (void) : BlockMemory () { this->Initialize(); return; };
    BlockMemory_FIFO (uint_t size) : BlockMemory (size) { this->Initialize(); return; };
    BlockMemory_FIFO (uint_t size, uint_t width) : BlockMemory (size, width) { this->Initialize(); return; };

    /* Destructor method */
   ~BlockMemory_FIFO (void) { /* Nothing further to do than the default base class destructor */ }; 

};

template <class Type> class FIFOBuffer : public Buffer<Type> { /* First-In-First-Out buffer management */

  private:
#if 0
    uint_t m_count, m_head, m_tail;
#else
    volatile uint_t m_count, m_head, m_tail;
#endif
    /* Initializer methods */
    void Initialize (void) { this->m_count = this->m_head = this->m_tail = 0; return; };

  protected:

  public:

    /* Initializer methods */
    void Initialize (Type& data) { return this->Buffer<Type>::Initialize(data); };
#if 0
    /* Accessor methods */
    bool IsEmpty (void) { if (m_count == 0) return true; else return false; };
    bool IsFull (void) { if (m_count == this->GetSize()) return true; else return false; };

    RET_STATUS PullData (Type& data) { if (IsEmpty()) return STATUS_ERROR; this->GetData(data, this->m_head); this->m_count -= 1; this->m_head += 1; if (this->m_head == this->GetSize()) this->m_head = 0; return STATUS_SUCCESS; };
    RET_STATUS PushData (Type& data) { if (IsFull())  return STATUS_ERROR; this->PutData(data, this->m_tail); this->m_count += 1; this->m_tail += 1; if (this->m_tail == this->GetSize()) this->m_tail = 0; return STATUS_SUCCESS; };
#else
    bool IsEmpty (void) { return __sync_bool_compare_and_swap(&m_count, 0, 0); };
    bool IsFull (void) { uint_t size = this->GetSize(); return __sync_bool_compare_and_swap(&m_count, size, size); };

    RET_STATUS PullData (Type& data) { if (IsEmpty()) return STATUS_ERROR; this->GetData(data, this->m_head); __sync_fetch_and_sub(&m_count, 1); __sync_fetch_and_add(&m_head, 1); uint_t size = this->GetSize(); __sync_bool_compare_and_swap(&m_head, size, 0); return STATUS_SUCCESS; };
    RET_STATUS PushData (Type& data) { if (IsFull())  return STATUS_ERROR; this->PutData(data, this->m_tail); __sync_fetch_and_add(&m_count, 1); __sync_fetch_and_add(&m_tail, 1); uint_t size = this->GetSize(); __sync_bool_compare_and_swap(&m_tail, size, 0); return STATUS_SUCCESS; };
#endif
    /* Miscellaneous methods */

    /* Constructor methods */
    FIFOBuffer () : Buffer<Type> ((uint_t) DEFAULT_BUFFER_SIZE) { this->Initialize(); return; };
    FIFOBuffer (uint_t size) : Buffer<Type> (size) { this->Initialize(); return; };

    /* Destructor method */
   ~FIFOBuffer () { /* Nothing further to do than the default base class destructor */ }; 

};

template <class Type> class LIFOBuffer : public Buffer<Type> { /* Last-In-First-Out buffer management */

  private:

    uint_t m_top;

    /* Initializer methods */
    void Initialize (void) { this->m_top = 0; return; };

  protected:

  public:

    /* Initializer methods */
    void Initialize (Type& data) { return this->Buffer<Type>::Initialize(data); };

    /* Accessor methods */
    bool IsEmpty (void) { if (this->m_top == 0) return true; else return false; };
    bool IsFull (void) { if (this->m_top == this->GetSize()) return true; else return false; };

    RET_STATUS PullData (Type& data) { if (IsEmpty()) return STATUS_ERROR; this->m_top -= 1; this->GetData(data, this->m_top); return STATUS_SUCCESS; };
    RET_STATUS PushData (Type& data) { if (IsFull())  return STATUS_ERROR; this->PutData(data, this->m_top); this->m_top += 1; return STATUS_SUCCESS; };

    /* Miscellaneous methods */

    /* Constructor methods */
    LIFOBuffer () : Buffer<Type> ((uint_t) DEFAULT_BUFFER_SIZE) { this->Initialize(); return; };
    LIFOBuffer (uint_t size) : Buffer<Type> (size) { this->Initialize(); return; };

    /* Destructor method */
   ~LIFOBuffer () { /* Nothing further to do than the default base class destructor */ }; 

};

template <class Type> struct RankedDataType
{

    uint64_t rank; /* uint64_t chosen to be able to use this for time-based sorting of samples */
    Type value;

};


template <class Type> class HIFOBuffer : public Buffer< RankedDataType<Type> > /* Highest(rank)-In-First-Out uint64_t chosen for rank to be able to use this for time-based sorting of samples */
{ 

  private:

    bool m_invert;
    uint_t m_count, m_head, m_tail;

    /* Initializer methods */
    void Initialize (void) { this->m_count = this->m_head = this->m_tail = 0; return; };

    /* Accessor methods */
    uint64_t GetRank (uint_t index) { struct RankedDataType<Type> temp; this->GetData(temp, index); return temp.rank; };

  protected:

  public:

    /* Initializer methods */
    void Initialize (Type& data) { struct RankedDataType<Type> temp; temp.rank = 0; temp.value = data; return this->Buffer< RankedDataType<Type> >::Initialize(temp); };

    /* Accessor methods */
    void Invert (bool invert) { this->m_invert = invert; return; };

    bool IsEmpty (void) { if (m_count == 0) return true; else return false; };
    bool IsFull (void) { if (m_count == this->GetSize()) return true; else return false; };

    RET_STATUS PullData (Type& data) { if (IsEmpty()) return STATUS_ERROR; struct RankedDataType<Type> temp; this->GetData(temp, m_head); data = temp.value; this->m_count -= 1; this->m_head += 1; if (this->m_head == this->GetSize()) this->m_head = 0; return STATUS_SUCCESS; };
    RET_STATUS PushData (Type& data) { if (IsFull())  return STATUS_ERROR; struct RankedDataType<Type> temp; temp.rank = 0; temp.value = data; this->PutData(temp, this->m_tail); this->m_count += 1; this->m_tail += 1; if (this->m_tail == this->GetSize()) this->m_tail = 0; return STATUS_SUCCESS; };
    RET_STATUS PushData (Type& data, uint64_t rank) 
    {

      RET_STATUS status = STATUS_ERROR;

      if (IsEmpty()) { struct RankedDataType<Type> temp; temp.rank = rank; temp.value = data; this->PutData(temp, this->m_tail); this->m_count += 1; this->m_tail += 1; if (this->m_tail == this->GetSize()) this->m_tail = 0; status = STATUS_SUCCESS; return status; }

      /* Index identifies the tail of the queue */
      uint_t index = this->m_tail;

      if (IsFull()) /* Head and tail markers are identical */
	{
	  /* Index identifies most recent data of smallest rank */
	  index = ((this->m_tail == 0) ? this->GetSize() : this->m_tail) - 1;

	  if ((this->m_invert == false) ? (rank <= this->GetRank(index)) : (rank >= this->GetRank(index))) { return status; }; /* Discard data - Keep older data having same or higher rank */
	}
      else /* Insert data wherever appropriate */
	{
	  /* Index identifies the tail of the queue */
	  index = this->m_tail;

	  this->m_count += 1; this->m_tail += 1; if (this->m_tail == this->GetSize()) this->m_tail = 0;
	}

      struct RankedDataType<Type> temp; temp.rank = rank; temp.value = data;

      /* Insert newest data at the tail of the queue */
      this->PutData(temp, index); /* Insert at the place of the most recent data of smallest rank */

      /* Swap until data of same or higher rank is found */
      uint_t swap = ((index == 0) ? this->GetSize() : index) - 1; 

      while (((this->m_invert == false) ? (rank > this->GetRank(swap)) : (rank < this->GetRank(swap))) && (index != this->m_head)) 
	{ 
	  struct RankedDataType<Type> copy; this->GetData(copy, swap); 

	  PutData(temp, swap); PutData(copy, index); 

	  index = ((index == 0) ? this->GetSize() : index) - 1; 
	  swap = ((index == 0) ? this->GetSize() : index) - 1; 
	}

      status = STATUS_SUCCESS; 

      return status;
    };

    /* Miscellaneous methods */

    /* Constructor methods */
    HIFOBuffer (void) : Buffer< RankedDataType<Type> > ((uint_t) DEFAULT_BUFFER_SIZE) { this->Initialize(); this->m_invert = false; return; };
    HIFOBuffer (uint_t size) : Buffer< RankedDataType<Type> > (size) { this->Initialize(); this->m_invert = false; return; };
    //HIFOBuffer (bool invert) : Buffer<RankedDataType<Type>> ((uint_t) DEFAULT_BUFFER_SIZE) { this->Initialize(); this->m_invert = invert; return; };
    HIFOBuffer (uint_t size, bool invert) : Buffer< RankedDataType<Type> > (size) { this->Initialize(); this->m_invert = invert; return; };

    /* Destructor method */
   ~HIFOBuffer () { /* Nothing further to do than the default base class destructor */ }; 
#if 0
   /* Display methods */
   void Show (void) { printf("Data is ' "); for (uint_t index = 0; index < this->GetSize(); index += 1) printf("%d ", this->GetRank(index)); printf("'\n"); return; };
#endif
};

/* Global variables */

/* Function declaration */

/* Function definition */

#endif /* BUFFER_H */

