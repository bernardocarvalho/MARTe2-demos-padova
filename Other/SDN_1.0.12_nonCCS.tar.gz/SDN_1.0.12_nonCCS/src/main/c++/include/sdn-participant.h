#ifndef SDN_PARTICIPANT_H
#define SDN_PARTICIPANT_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-participant.h $
* $Id: sdn-participant.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "any-object.h" /* Root object class definition */
#include "sdn-base.h" /* Base classes definition */

#include "core-participant.h"

#include "disc-publisher.h"

/* Constants */

#ifdef __cplusplus

/* Type definition */

namespace sdn {

class Participant_Impl : public base::AnyObject
{
        
  private:
        
    /* Initializer methods */
    void Initialize (void);
        
  public:
        
    core::Participant_Impl* m_base; /* Reference to core::Participant */
    disc::Publisher_Impl* m_disc; /* Instantiate and publish to disc::Publisher */
        
    /* Initializer methods */
        
    /* Accessor methods */
    bool IsInitialized (void) { return (this->m_base)->IsInitialized(); };
        
    char* GetInterface (void) { return (this->m_base)->GetInterface(); };
    char* GetTopicName (void) { return (this->m_base)->GetTopicName(); };
    uint_t GetTopicSize (void) { return (this->m_base)->GetTopicSize(); };
        
    RET_STATUS SetInterface (const char* name) { RET_STATUS status = STATUS_ERROR; if (this->m_base != NULL) status = (this->m_base)->SetInterface(name); return status; };
    RET_STATUS SetTopicName (const char* name) { RET_STATUS status = STATUS_ERROR; if (this->m_base != NULL) status = (this->m_base)->SetTopicName(name); return status; };
    RET_STATUS SetMetadata (Metadata_t& mdata) { RET_STATUS status = STATUS_ERROR; if (this->m_base != NULL) status = (this->m_base)->SetMetadata(mdata); return status; };
        
    RET_STATUS CopyTopicInstance (void* instance, uint_t size) { RET_STATUS status = STATUS_ERROR; if (this->m_base != NULL) status = (this->m_base)->CopyTopicInstance(instance, size); return status; };
    void* GetTopicHeader (void) { void* ref = NULL; if (this->m_base != NULL) ref = (this->m_base)->GetTopicHeader(); return ref; }; /* The data payload and not the instance of the class */
    void* GetTopicFooter (void) { void* ref = NULL; if (this->m_base != NULL) ref = (this->m_base)->GetTopicFooter(); return ref; }; /* The data payload and not the instance of the class */
    void* GetTopicInstance (void) { void* ref = NULL; if (this->m_base != NULL) ref = (this->m_base)->GetTopicInstance(); return ref; }; /* The data payload and not the instance of the class */
        
    RET_STATUS SetCallback (void (* cb)(void*)) { RET_STATUS status = STATUS_ERROR; if (this->m_base != NULL) status = (this->m_base)->SetCallback(cb); return status; };
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { RET_STATUS status = STATUS_ERROR; if (this->m_base != NULL) status = (this->m_base)->SetCallback(cb, attr); return status; };

    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) = 0;        /* Pure virtual method */
    virtual RET_STATUS Configure (void) = 0; /* Pure virtual method */
        
    /* Constructor methods */
    Participant_Impl (void);
        
    /* Destructor method */
   ~Participant_Impl (void);
        
    /* Display methods */
        
};
    
/* Global variables */

/* Function declaration */

RET_STATUS Participant_Configure (Participant_Impl* self);

/* Function definition */

}; /* namespace sdn */

using namespace sdn; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* SDN_PARTICIPANT_H */
