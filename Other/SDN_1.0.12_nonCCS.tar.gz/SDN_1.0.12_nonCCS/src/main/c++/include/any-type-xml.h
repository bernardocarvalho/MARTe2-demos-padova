#ifndef ANY_TYPE_XML_H
#define ANY_TYPE_XML_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/any-type-xml.h $
* $Id: any-type-xml.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "any-type.h" /* Runtime datatype definition */

#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

//#include "sdn-base.h" /* Privately scoped case classes definition */

/* Constants */

#define AnyType_XML sdn::base::AnyType /* For backward compatibility purposes with v1.0 */

/* Type definition */

namespace sdn {

namespace base {

typedef struct ExtTypeInfo { /* For each attribute within a structure, the name will be defined externally as keyword in LUTable */

  uint32_t rank; /* Attribute rank within the structure */
  char desc [STRING_MAX_LENGTH]; /* Attribute free description string */
  char qual [STRING_MAX_LENGTH]; /* Attribute qualifier */
  char unit [STRING_MAX_LENGTH]; /* Attribute unit */
  char mult [STRING_MAX_LENGTH]; /* Attribute multiplicity string */

} ExtTypeInfo_t;

class AnyType : public ccs::base::AnyType 
{

  private:

    LUTable<ExtTypeInfo_t>* m_type_ext; /* Extended attribute look-up table */

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */
    RET_STATUS AddExtAttribute (char* rank, char* name, char* desc, char* qual, char* unit, char* mult);
    RET_STATUS Load (char* file_path); /* Specializes virtual method - XML format - Dependency to libxml2 */

    /* Accessor methods */
    char* GetAttributeDescription (uint_t rank);
    char* GetAttributeDescription (char* name) { return this->GetAttributeDescription(this->GetAttributeRank(name)); };

    char* GetAttributeQualifier (uint_t rank);
    char* GetAttributeQualifier (char* name) { return this->GetAttributeQualifier(this->GetAttributeRank(name)); };

    char* GetAttributeUnit (uint_t rank);
    char* GetAttributeUnit (char* name) { return this->GetAttributeUnit(this->GetAttributeRank(name)); };

    char* GetAttributeMultiplicity (uint_t rank);
    char* GetAttributeMultiplicity (char* name) { return this->GetAttributeMultiplicity(this->GetAttributeRank(name)); };

    /* Miscellaneous methods */
    RET_STATUS Compress (void); /* Would the type definition be incomplete */

    /* Constructor methods */
    AnyType (void); /* Type definition using the class API */
    AnyType (char* name); /* Type introspection from declaration file */

    /* Destructor method */
   ~AnyType (void) { /* Nothing further than the default destructor */ return; };

    /* Display methods */
    uint_t SerializeType (char* buffer, int max_size = STRING_MAX_LENGTH); /* Specializes virtual method - XML format */
    uint_t SerializeType (void) { char buffer [2048] = STRING_UNDEFINED; return this->SerializeType((char*) buffer, 2048); }; /* Only interested in hash key */

};

/* Global variables */

/* Function declaration */

RET_STATUS AnyType_LocateTypeDefinition (char* name, char* file_path, uint_t max_size = PATH_MAX_LENGTH);
RET_STATUS AnyType_LoadTypeDefinition (AnyType* self, char* file_path); /* XML format - Dependency to libxml2 to be managed by the calling application */

/* Function definition */

}; /* namespace base */

}; /* namespace sdn */

using namespace sdn::base;

#endif /* ANY_TYPE_XML_H */
