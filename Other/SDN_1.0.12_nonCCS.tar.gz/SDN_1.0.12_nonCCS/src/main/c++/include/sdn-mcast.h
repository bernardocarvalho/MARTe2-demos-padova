#ifndef SDN_MCAST_H
#define SDN_MCAST_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-mcast.h $
* $Id: sdn-mcast.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

//#include "sdn-base.h" /* Favour PIMPL design pattern to avoid exposing the structure through the public interface */

#include "base-participant.h"
#include "base-publisher.h"  
#include "base-subscriber.h" 

//#include "mcast-participant.h" /* Favour PIMPL design pattern to avoid exposing the structure through the public interface */
//#include "mcast-publisher.h"   /* Favour PIMPL design pattern to avoid exposing the structure through the public interface */
//#include "mcast-subscriber.h"  /* Favour PIMPL design pattern to avoid exposing the structure through the public interface */

/* Constants */

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace mcast {

class Publisher_Impl;   /* Forward class declaration */
class Subscriber_Impl;  /* Forward class declaration */

typedef base::Participant_Iface Participant;

typedef class Publisher_Iface : public base::Publisher_Iface
{

  private:

    Publisher_Impl* p_impl;

  public:

    /* Initializer methods */

    /* Accessor methods */
    virtual const char* GetInterface (void); /* Specializes virtual method */
    virtual const char* GetAddress (void) { return this->GetMCastGroup(); }; /* Specializes virtual method (base::Participant) */
    virtual uint_t GetPort (void) { return this->GetMCastPort(); }; /* Specializes virtual method (base::Participant) */
    virtual const char* GetMCastGroup (void); /* Specializes virtual method */
    virtual uint_t GetMCastPort (void); /* Specializes virtual method */

    virtual void SetInterface (const char* iface); /* Specializes virtual method */
    virtual void SetAddress (const char* addr) { return this->SetMCastGroup(addr); }; /* Specializes virtual method (base::Participant) */
    virtual void SetPort (uint_t port) { return this->SetMCastPort(port); }; /* Specializes virtual method (base::Participant) */
    virtual void SetMCastGroup (const char* group); /* Specializes virtual method */
    virtual void SetMCastPort (uint_t port); /* Specializes virtual method */

    virtual void* GetBuffer (void); /* Specializes virtual method */
    virtual uint_t GetSize (void); /* Specializes virtual method */
    virtual void SetBuffer (void* buffer, uint_t size); /* Specializes virtual method */

    virtual RET_STATUS SetCallback (void (* cb)(void*)); /* Specializes virtual method */ /* Routine called before message publication */
    virtual RET_STATUS SetCallback (void (* cb)(void*), void* attr); /* Specializes virtual method */ /* Routine called before message publication */

    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) { return this->Publish(); }; /* Specializes virtual method */
    virtual RET_STATUS Open (void);  /* Specializes virtual method */
    virtual RET_STATUS Close (void); /* Specializes virtual method */

    virtual RET_STATUS Publish (void* buffer, uint_t size); /* Specializes virtual method */
    virtual RET_STATUS Publish (void); /* Specializes virtual method */

    /* Constructor methods */
    Publisher_Iface (void);
    Publisher_Iface (const char* iface, const char* group, uint_t port);

    /* Destructor method */
    virtual ~Publisher_Iface (void); /* Note - virtual destructor to ensure that sdn::core::Participant deleting this would call upon the appropriate destructor */

} Publisher; /* For backward compatibility purposes with v1.0 */ 

typedef class Subscriber_Iface : public base::Subscriber_Iface
{

  private:

    Subscriber_Impl* p_impl;

  public:

    /* Initializer methods */

    /* Accessor methods */
    virtual const char* GetInterface (void); /* Specializes virtual method */
    virtual const char* GetAddress (void) { return this->GetMCastGroup(); }; /* Specializes virtual method (base::Participant) */
    virtual uint_t GetPort (void) { return this->GetMCastPort(); }; /* Specializes virtual method (base::Participant) */
    virtual const char* GetMCastGroup (void); /* Specializes virtual method */
    virtual uint_t GetMCastPort (void); /* Specializes virtual method */

    virtual void SetInterface (const char* iface); /* Specializes virtual method */
    virtual void SetAddress (const char* addr) { return this->SetMCastGroup(addr); }; /* Specializes virtual method (base::Participant) */
    virtual void SetPort (uint_t port) { return this->SetMCastPort(port); }; /* Specializes virtual method (base::Participant) */
    virtual void SetMCastGroup (const char* group); /* Specializes virtual method */
    virtual void SetMCastPort (uint_t port); /* Specializes virtual method */

    virtual void* GetBuffer (void); /* Specializes virtual method */
    virtual uint_t GetSize (void); /* Specializes virtual method */
    virtual void SetBuffer (void* buffer, uint_t size); /* Specializes virtual method */

    virtual uint_t GetTimeout (void); /* Specializes virtual method */
    virtual void SetTimeout (uint_t timeout); /* Specializes virtual method */

    bool IsUpdated (void); /* Successful Receive */

    virtual RET_STATUS SetCallback (void (* cb)(void*)); /* Specializes virtual method */ /* Routine called upon message reception */
    virtual RET_STATUS SetCallback (void (* cb)(void*), void* attr); /* Specializes virtual method */ /* Routine called upon message reception */

    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) { return this->Receive(); }; /* Specializes virtual method */
    virtual RET_STATUS Open (void);  /* Specializes virtual method */
    virtual RET_STATUS Close (void); /* Specializes virtual method */

    virtual RET_STATUS Receive (void* buffer, uint_t size, uint64_t timeout); /* Specializes virtual method */ /* Blocking wait with configurable timeout */
    virtual RET_STATUS Receive (void* buffer, uint_t size);                   /* Specializes virtual method */ /* Blocking wait */

    virtual RET_STATUS Receive (uint64_t timeout); /* Specializes virtual method */ /* Blocking wait with configurable timeout - Buffer and size defined using sdn::mcast::Participant::SetBuffer() */
    virtual RET_STATUS Receive (void);             /* Specializes virtual method */ /* Blocking wait - Buffer and size defined using sdn::mcast::Participant::SetBuffer() */

    /* Constructor methods */
    Subscriber_Iface (void);
    Subscriber_Iface (const char* iface, const char* group, uint_t port);

    /* Destructor method */
    virtual ~Subscriber_Iface (void); /* Note - virtual destructor to ensure that sdn::core::Participant deleting this would call upon the appropriate destructor */

} Subscriber; /* For backward compatibility purposes with v1.0 */

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace mcast */

}; /* namespace sdn */

using namespace sdn::mcast; /* Allow for declaring intention only with including this header file */

extern "C" {
    
#endif /* __cplusplus */
    
    /* ToDo - Insert C API declaration */
    
#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* SDN_MCAST_H */
