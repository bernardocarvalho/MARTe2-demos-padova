#ifndef DISC_SUBSCRIBER_H
#define DISC_SUBSCRIBER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/disc-subscriber.h $
* $Id: disc-subscriber.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "mcast-subscriber.h"

#include "disc-participant.h"

#ifdef __cplusplus

/* Constants */

#define OBJTYPE_DISC_SUBSCRIBER (char*) "sdn::disc::Subscriber_Base"

/* Type definition */

namespace sdn {

namespace disc {

typedef class Subscriber_Impl : public Participant
{

  private:

    sdn::mcast::Subscriber_Impl* m_base; /* Listen on discovery channel */

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Configure (void); /* Specializes virtual method */
    RET_STATUS Do (void) { return this->Receive(); }; /* Specializes virtual method */
    RET_STATUS Receive (void);
    RET_STATUS Receive (uint_t timeout);

    /* Constructor methods */
    Subscriber_Impl (void) { this->SetInstanceType(OBJTYPE_DISC_SUBSCRIBER); /* Initialize attributes */ this->Initialize(); return; };
    Subscriber_Impl (char* iface) { this->SetInstanceType(OBJTYPE_DISC_SUBSCRIBER); /* Initialize attributes */ this->Initialize(); this->SetInterface(iface); /* Create mcast::Subscriber */ this->Configure(); return; };

    /* Destructor method */
    virtual ~Subscriber_Impl (void); /* Note - virtual destructor */

} Subscriber;

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace disc */

}; /* namespace sdn */

using namespace sdn::disc; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* DISC_SUBSCRIBER_H */
