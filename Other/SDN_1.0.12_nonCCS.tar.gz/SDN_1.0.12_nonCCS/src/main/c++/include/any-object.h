#ifndef SDN_BASE_ANY_OBJECT_H
#define SDN_BASE_ANY_OBJECT_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/any-object.h $
* $Id: any-object.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h" /* Misc. helper functions, e.g. hash, etc. */

#include "sdn-base.h" /* Privately scoped base classes definition */

/* Constants */

/* WARNING - The constructor being called by the ObjectFactory must specifically cast to the abstract base class */
/* WARNING - Dynamic cast due to virtual inheritance to be able to assemble Cfgable and Msgable classes */ 
#define REGISTER_CLASS_WITH_OBJECT_FACTORY(ClassName) \
extern "C" { \
AnyObject* The_##ClassName##_Constructor (void) { \
  log_trace("The_" #ClassName "_Constructor - Entering routine"); \
  ClassName* ref = new ClassName (); \
  if ((ref != NULL) && (ref->AnyObject::IsType() != true)) log_warning("The_" #ClassName "_Constructor - Instance has unclear parentage to base class"); \
  else log_debug("The_" #ClassName "_Constructor - Reference is '(" #ClassName "*) %p'", (void*) ref); \
  log_trace("The_" #ClassName "_Constructor - Leaving routine"); \
  return (AnyObject*) ref;					 \
}; \
void The_##ClassName##_Destructor (AnyObject* ref) { \
  log_trace("The_" #ClassName "_Destructor - Entering routine"); \
  if (ref != NULL) delete (ClassName*) ref;			 \
  log_trace("The_" #ClassName "_Destructor - Leaving routine"); \
  return; \
};								\
bool The_##ClassName##_IsRegistered = ( ObjectFactory_Register((char*) #ClassName, (AnyObject_Constructor_t) &The_##ClassName##_Constructor, (AnyObject_Destructor_t) &The_##ClassName##_Destructor) == STATUS_SUCCESS ); \
}

#define OBJTYPE_UNDEFINED (ObjectTypeId_t) 0
#define OBJTYPE_ROOT      (char*) "AnyObject"

/* Type definition */

namespace sdn {

namespace base {

typedef uint_t ObjectTypeId_t;
typedef uint64_t ObjectUId_t;

/* WARNING - Must be virtual due to virtual inheritance to be able to assemble Cfgable and Msgable classes */ 
class AnyObject
{

  private:

    char m_instance_name [STRING_MAX_LENGTH];
    ObjectTypeId_t m_instance_root; /* Immutable attribute - Used to detect inheritance from this base class */
    ObjectTypeId_t m_instance_type;

    /* Initializer methods */
    void Initialize (void);

  protected:

  public:

    /* Initializer methods */

    /* Accessor methods */
    char* GetInstanceName (void);
    void SetInstanceName (char* name);

    ObjectUId_t GetInstanceUid (void) { uint64_t id = 0; sscanf(this->GetInstanceName(), "%lu", &id); return (ObjectUId_t) id; };
    void SetInstanceUId (ObjectUId_t id) { char name [STRING_MAX_LENGTH] = STRING_UNDEFINED; snprintf(name, STRING_MAX_LENGTH, "%lu", (uint64_t) id); this->SetInstanceName(name); return; };
    void SetInstanceUId (void) { return this->SetInstanceUId(get_time()); };

    ObjectTypeId_t GetInstanceType (void);
    void SetInstanceType (ObjectTypeId_t type);
    void SetInstanceType (char* type);

    /* Miscellaneous methods */
    bool IsType (void);
    bool IsType (ObjectTypeId_t type);
    bool IsType (char* type);

    /* Constructor methods */
    AnyObject (void);

    /* Destructor method */
    virtual ~AnyObject (void); /* Note - virtual destructor */

};

class ObjectDatabase : public LUTable<AnyObject*>
{

  private:

  protected:

  public:

    /* Initializer methods */
    RET_STATUS Register (char* name, AnyObject* ref) { if ((ref != NULL) && (ref->IsType() == true)) ref->SetInstanceName(name); return this->AddPair(name, ref); }; /* Do not invoke any instance method to allow for storing anything */
    RET_STATUS Remove (uint_t id) { return this->Clear(id); };
    RET_STATUS Remove (char* name) { return this->Clear(name); };

    /* Accessor methods */
    uint_t GetInstanceId (char* name) { return this->GetIndex(name); };

    AnyObject* GetInstance (uint_t id) { return this->GetValue(id); };
    AnyObject* GetInstance (char* name) { return this->GetValue(name); };
    //RET_STATUS GetInstance (char* name, AnyObject*& ref) { return this->GetValue(ref, name); };

    /* Miscellaneous methods */

    /* Constructor methods */
    ObjectDatabase (void) { AnyObject* ref = NULL; this->SetDefault(ref); this->Clear(); return; };

    /* Destructor method */
   ~ObjectDatabase (void) { /* Nothing further than base class destructor */ return; }; 

    /* Display methods */

};

typedef AnyObject* (*AnyObject_Constructor_t) (void);
typedef void (*AnyObject_Destructor_t) (AnyObject*);

/* Global variables */

/* Function declaration */

/* ToDo - Evaluate whether to make those static inline ... */

ObjectTypeId_t GetInstanceTypeByName (char* type);

AnyObject* ObjectFactory_Instantiate (char* type); /* Instantiate object with class name */
AnyObject* ObjectFactory_Instantiate (char* type, char* name); /* Instantiate object with class name and register in the object database */
RET_STATUS ObjectFactory_Register (char* type, AnyObject_Constructor_t construct, AnyObject_Destructor_t destruct); /* Register constructor with class name */
RET_STATUS ObjectFactory_Terminate (AnyObject* ref); /* Destroy object by reference */

RET_STATUS ObjectDatabase_Register (char* name, AnyObject* ref);
static inline RET_STATUS ObjectDatabase_Register (AnyObject* ref) { RET_STATUS status = STATUS_ERROR; if ((ref != NULL) && (ref->IsType() == true)) { ref->SetInstanceUId(); status = ObjectDatabase_Register(ref->GetInstanceName(), ref); } return status; };

RET_STATUS ObjectDatabase_Remove (char* name);
RET_STATUS ObjectDatabase_Remove (uint_t id);
static inline RET_STATUS ObjectDatabase_Remove (AnyObject* ref) { RET_STATUS status = STATUS_ERROR; if ((ref != NULL) && (ref->IsType() == true)) status = ObjectDatabase_Remove(ref->GetInstanceName()); return status; };

AnyObject* ObjectDatabase_GetInstance (char* name);
AnyObject* ObjectDatabase_GetInstance (uint_t id);

/* Function definition */

/* Initializer methods */

/* Accessor methods */

/* Miscellaneous methods */

/* Constructor methods */

/* Destructor method */

/* Display method */

}; /* namespace base */

}; /* namespace sdn */

using namespace sdn::base; 

#endif /* SDN_BASE_ANY_OBJECT_H */

