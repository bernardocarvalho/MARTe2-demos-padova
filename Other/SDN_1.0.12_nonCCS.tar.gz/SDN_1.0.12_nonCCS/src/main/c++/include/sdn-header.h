#ifndef SDN_HEADER_H
#define SDN_HEADER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-header.h $
* $Id: sdn-header.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

//#include "sdn-base.h" /* Privately scoped case classes definition */
#include "any-type-xml.h" /* Type introspection from XML file */

/* Constants */

#define DATATYPE_DEFINITION_FROM_XML_FILE /* For backward compatibility purposes with v1.0 */

#define DEFAULT_SDN_HEADER_UID (char*) "SDN"

typedef enum SDNHeader_AttributeId : uint_t {

  SDN_HEADER_HEADER_UID = 0,
  //SDN_HEADER_HEADER_VERSION,
  SDN_HEADER_HEADER_SIZE,
  SDN_HEADER_TOPIC_UID,
  SDN_HEADER_TOPIC_VERSION,
  SDN_HEADER_TOPIC_SIZE,
  SDN_HEADER_COUNTER,
  SDN_HEADER_SEND_TIME,
  SDN_HEADER_RECV_TIME,

} SDNHeader_AttributeId_t;

#define sdn_header sdn::Header /* For backward compatibility purposes with v1.0 */
#define SDNHeader_t sdn::Header_t /* For backward compatibility purposes with v1.0 */

/* Type definition */

namespace sdn {

typedef struct {

  char     header_uid [8];
  //char     header_version [4];
  uint32_t header_size;
  uint32_t topic_uid;
  //char     topic_version [4];
  uint32_t topic_version;
  uint32_t topic_size;
  uint64_t topic_counter;
  uint64_t send_time;
  uint64_t recv_time;
  //char     reserved [8];

} Header_t;
#ifdef DATATYPE_DEFINITION_FROM_XML_FILE
class Header : public sdn::base::AnyType
#else
class Header : public ccs::base::AnyType
#endif
{

  private:
#if 0
    SDNHeader_t* m_struct;
#endif
  public:

    /* Initializer methods */
    void Initialize (void);

    /* Accessor methods */
    char* HasInstanceIndex (void);
    char* HasInstanceTimestamp (void);

    bool IsValid (void* buffer) { uint_t offset = this->AnyType::GetAttributeOffset(SDN_HEADER_HEADER_UID); return ((strncmp((((char*) buffer) + offset), DEFAULT_SDN_HEADER_UID, strlen(DEFAULT_SDN_HEADER_UID)) == 0) ? true : false); };
    bool IsValid (void) { return this->IsValid(this->AnyType::GetInstance()); };

    SDNHeader_t* GetInstance (void) { return (SDNHeader_t*) this->AnyType::GetInstance(); };
    void SetInstance (void* instance) { this->AnyType::SetInstance(instance); this->Initialize(); return; };

    uint64_t GetCounter (void) { uint64_t* attr = (uint64_t*) this->AnyType::GetAttributeReference(SDN_HEADER_COUNTER); return *attr; };
    void IncrCounter (void) { uint64_t* attr = (uint64_t*) this->AnyType::GetAttributeReference(SDN_HEADER_COUNTER); *attr += 1; return; };

    uint64_t GetTimestamp (void) { uint64_t* attr = (uint64_t*) this->AnyType::GetAttributeReference(SDN_HEADER_SEND_TIME); return *attr; };
    void SetTimestamp (uint64_t time) { uint64_t* attr = (uint64_t*) this->AnyType::GetAttributeReference(SDN_HEADER_SEND_TIME); *attr = time; return; };
    void SetReceiveTimestamp (uint64_t time) { uint64_t* attr = (uint64_t*) this->AnyType::GetAttributeReference(SDN_HEADER_RECV_TIME); *attr = time; return; };
    void SetTimestamp (void) { return this->SetTimestamp(get_time()); };
    void SetReceiveTimestamp (void) { return this->SetReceiveTimestamp(get_time()); };

    uint_t GetTopicSize (void) { uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_SIZE); return *attr; };
    void SetTopicSize (uint_t size) { uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_SIZE); *attr = (uint32_t) size; return; };

    uint_t GetTopicUID (void) { uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_UID); return *attr; };
    void SetTopicUID (uint_t uid) { uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_UID); *attr = (uint32_t) uid; return; };

    //char* GetTopicVersion (void) { return (char*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_VERSION); };
    uint32_t GetTopicVersion (void) { uint32_t* attr = (uint32_t*) this->AnyType::GetAttributeReference(SDN_HEADER_TOPIC_VERSION); return *attr; };

    void SetTopicVersion (char* version);
    void SetTopicVersion (uint32_t version);

    /* Miscellaneous methods */
    void ClearInstance (void);
    void UpdateInstance (void) { this->SetTimestamp(); this->IncrCounter(); return; };

    /* Constructor methods */
    Header (void);

    /* Destructor method */
   ~Header (void) { /* Nothing further */ };

    /* Display methods */

};

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace sdn */

#endif /* SDN_HEADER_H */
