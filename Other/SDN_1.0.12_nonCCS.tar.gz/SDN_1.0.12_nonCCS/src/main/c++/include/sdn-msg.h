#ifndef SDN_MSG_H
#define SDN_MSG_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-msg.h $
* $Id: sdn-msg.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h> /* sscanf, printf, etc. */
#include <string.h> /* strncpy, etc. */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

/* Constants */

#define DEFAULT_MSG_LENGTH 1024

#define DISCOVERY_MSG_HEADER (char*) "PVER#2.0\nMGRP#DISCOVERY\n"
#define DISCOVERY_MSG_HEADER_SIZE strlen(DISCOVERY_MSG_HEADER)

#define DISCOVERY_MSG_JOIN_CMD  (char*) "CMD#ANNOUNCE\n"
#define DISCOVERY_MSG_LEAVE_CMD (char*) "CMD#LEAVE\n"
                          
#define QUERY_MSG (char*) "PVER#2.0\nMGRP#DISCOVERY\nCMD#QUERY\nTNAME#ALL\n\n"
#define QUERY_MSG_FMT "PVER#2.0\nMGRP#DISCOVERY\nCMD#QUERY\nTNAME#%s\n\n"
#define QUERY_MSG_SIZE strlen(QUERY_MSG)

#define sdn_msg sdn::Message /* For backward compatibility purposes with CCSv5.2 */
#define sdn_discovery_msg sdn::DiscoveryMsg /* For backward compatibility purposes with CCSv5.2 */
#define sdn_query_msg sdn::QueryMsg /* For backward compatibility purposes with CCSv5.2 */

/* Type definition */

namespace sdn {

class Message
{

  private:

    bool m_allocated;
    uint8_t* m_instance;
    uint_t m_size;

    /* Initializer methods */
    void Initialize (void) { this->m_allocated = false; this->m_instance = NULL; this->m_size = DEFAULT_MSG_LENGTH; return; };

  public:

    /* Initializer methods */
    virtual void ClearInstance (void) { if (this->m_instance != NULL) memset(this->m_instance, 0, this->m_size); return; };
    virtual RET_STATUS CopyInstance (void* instance) { if (this->m_instance != NULL) memcpy(this->m_instance, instance, this->m_size); return STATUS_SUCCESS; };
    virtual RET_STATUS CreateInstance (void) { this->DeleteInstance(); this->m_instance = new uint8_t [this->m_size]; this->m_allocated = true; return STATUS_SUCCESS; };
#if 0 /* Warning - Recursion risk - Specializing CreateInstance (void) and calling CreateInstance (void*, uint_t) */
    virtual RET_STATUS CreateInstance (void* instance, uint_t size) { this->SetSize(size); this->CreateInstance(); this->CopyInstance(instance); return STATUS_SUCCESS; };
#else
    virtual RET_STATUS CreateInstance (void* instance, uint_t size) { this->SetSize(size); this->DeleteInstance(); this->m_instance = new uint8_t [this->m_size]; this->m_allocated = true; this->CopyInstance(instance); return STATUS_SUCCESS; };
#endif
    virtual void DeleteInstance (void) { if ((this->m_allocated == true) && (this->m_instance != NULL)) delete [] this->m_instance; this->m_allocated = false; this->m_instance = NULL; return; };

    /* Accessor methods */
    virtual void* GetInstance (void) { return this->m_instance; };
    virtual void SetInstance (void* instance) { if (this->m_instance != instance) this->DeleteInstance(); this->m_instance = (uint8_t*) instance; return; };
    virtual void SetInstance (void* instance, uint_t size) { this->SetSize(size); this->SetInstance(instance); return; };

    uint_t GetSize (void) { return this->m_size; };
    void SetSize (uint_t size) { this->m_size = size; return; };

    /* Miscellaneous methods */

    /* Constructor methods */
    Message (void) { this->Initialize(); return; };

    /* Destructor method */
   ~Message (void) { this->DeleteInstance(); return; };

    /* Display methods */

};

class DiscoveryMsg : public Message
{

  private:

    uint8_t* m_copy;

    char* m_cmd;
    char* m_resp;
    char* m_host;
    char* m_part;
    char* m_role;
    char* m_size;
    char* m_topic;
    char* m_version;
    char* m_mcast_group;
    char* m_mcast_port;

  public:

    /* Initializer methods */

    /* Accessor methods */
    char* GetCommand (void) { return this->m_cmd; };
    char* GetResponse (void) { return this->m_resp; };
    char* GetHostname (void) { return this->m_host; };
    char* GetParticipant (void) { return this->m_part; };
    char* GetRole (void) { return this->m_role; };
    char* GetTopicName (void) { return this->m_topic; };
    //char* GetTopicVersion (void) { return this->m_version; };
    uint_t GetTopicVersion (void) { uint_t vers = 0; sscanf(this->m_version, "%u", &vers); return vers; };
    uint_t GetTopicSize (void) { uint_t size = 0; sscanf(this->m_size, "%u", &size); return size; };
    char* GetMCastGroup (void) { return this->m_mcast_group; };
    uint_t GetMCastPort (void) { uint_t port = 0; sscanf(this->m_mcast_port, "%d", &port); return port; };

    /* Miscellaneous methods */
    bool IsValid (void* buffer) { char* p_buf = (char*) buffer; return ((strncmp(p_buf, DISCOVERY_MSG_HEADER, DISCOVERY_MSG_HEADER_SIZE) == 0) ? true : false); };
    bool IsValid (void) { return ((this->Parse() != STATUS_SUCCESS) ? false : true); };

    bool IsJoin (void) { return ((strcmp(this->GetCommand(), "ANNOUNCE") == 0) ? true : false); };
    bool IsLeave (void) { return ((strcmp(this->GetCommand(), "LEAVE") == 0) ? true : false); };
    bool IsQuery (void) { return ((strcmp(this->GetCommand(), "QUERY") == 0) ? true : false); };
    bool IsPublisher (void) { return ((strcmp(this->GetRole(), "PUB") == 0) ? true : false); };
    bool IsSubscriber (void) { return ((strcmp(this->GetRole(), "SUB") == 0) ? true : false); };
    bool IsResponse (void) { return ((strcmp(this->GetResponse(), "1") == 0) ? true : false); };

    RET_STATUS Parse (void* buffer);
    RET_STATUS Parse (void) { return this->Parse(this->GetInstance()); };

    /* Constructor methods */
    DiscoveryMsg (void) { this->m_copy = NULL; this->m_cmd = this->m_resp = this->m_role = this->m_size = this->m_topic = NULL; return; };

    /* Destructor method */
   ~DiscoveryMsg (void) { return; };

    /* Display methods */
    //void Show (void) { log_info("Discovery message '%s'", this->GetInstance()); return; };

};

class QueryMsg : public Message
{

  private:

    char m_topic_name [STRING_MAX_LENGTH]; /* SDN topic name */

  public:

    /* Initializer methods */
    RET_STATUS CreateInstance (void) { char msg [STRING_MAX_LENGTH] = STRING_UNDEFINED; snprintf((char*) msg, STRING_MAX_LENGTH, QUERY_MSG_FMT, (char*) this->m_topic_name); return this->sdn_msg::CreateInstance((void*) msg, strlen(msg)); }; /* Warning - Recursion risk */

    /* Accessor methods */

    /* Miscellaneous methods */

    /* Constructor methods */
    QueryMsg (void);
    QueryMsg (char* topic);

    /* Destructor method */
   ~QueryMsg (void) { return; };

    /* Display methods */

};

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace sdn */

#endif /* SDN_MSG_H */
