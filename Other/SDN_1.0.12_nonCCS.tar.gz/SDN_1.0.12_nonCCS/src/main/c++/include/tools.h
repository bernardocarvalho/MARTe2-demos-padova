#ifndef TOOLS_H
#define TOOLS_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/tools.h $
* $Id: tools.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Some useful POSIX wrappers or routines
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */
#ifndef LINT /* MARTe2 Integration */
#include <ctype.h> /* toupper, etc. */
#include <dlfcn.h> /* dlopen, dlsym, etc. */
#include <errno.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h> /* fopen, etc. */
#include <stdlib.h> /* getenv, etc. */
#include <string.h> /* strerror, etc. */
#include <time.h> /* timespec, etc. */
#include <unistd.h> /* setuid, getuid, etc. */

#include <sys/mman.h> /* mlockall, etc. */
#include <sys/stat.h> /* mkdir, etc. */
#include <sys/types.h>
#endif
/* Local header files */

#include "types.h" /* Condensed integer type definition, RET_STATUS, etc. */
#include "hash.h" /* Misc. helper function, e.g. bitmap rotation and hash key generation, etc. */

/* Constants */

#define DEFAULT_THREAD_SCHEDULING_AFFINITY 0
#define DEFAULT_THREAD_SCHEDULING_POLICY SCHED_FIFO
#define DEFAULT_THREAD_SCHEDULING_PRIORITY 0

#define DEFAULT_WAIT_UNTIL_SLEEP_LIMIT 100000
#define DEFAULT_WAIT_UNTIL_SLEEP_PERIOD 10000

/* Type definition */

/* Global variables */

/* Function declaration */

static inline RET_STATUS resolve_variable_string (char* in_str, char* out_str, uint_t max_size);
static inline char* sstrncpy (char* dst, const char* src, int size); /* Safe strncpy */
static inline int get_process_id (void);

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline RET_STATUS resolve_variable_string (char* in_str, char* out_str) { return resolve_variable_string(in_str, out_str, STRING_MAX_LENGTH); };
static inline RET_STATUS resolve_variable_string (char* inout_str);
static inline RET_STATUS resolve_variable_path (char* inout_path);

#endif

/* Function definition */

/* File IO related functions */

static inline bool exist (char* file) { FILE* file_handle = fopen(file, "r"); if (file_handle == NULL) return false; else fclose(file_handle); return true; };

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline bool exist (char* file_path, char* file_name) { char file [PATH_MAX_LENGTH]; snprintf(file, PATH_MAX_LENGTH, "%s/%s", file_path, file_name); return exist((char*) file); };
static inline bool exist (char* file_path, char* file_prefix, char* file_suffix) { char file [PATH_MAX_LENGTH]; snprintf(file, PATH_MAX_LENGTH, "%s/%s%s", file_path, file_prefix, file_suffix); return exist((char*) file); };

#endif

static inline RET_STATUS create_path (char* path, mode_t mode = 0777)
{

  RET_STATUS status = STATUS_ERROR;

  /* Take a copy of the parameter - strtok replaces '/' by '/0' */
  char cpy_path [PATH_MAX_LENGTH] = STRING_UNDEFINED; sstrncpy(cpy_path, path, PATH_MAX_LENGTH);
  char tmp_path [PATH_MAX_LENGTH] = STRING_UNDEFINED; char* p_path = tmp_path;

  if (cpy_path[0] == '/') /* There is no starting '/' character */
    {
      tmp_path[0] = '/'; p_path += 1;
    }

  if (cpy_path[strlen(cpy_path)-1] != '/') /* There is no trailing '/' character */
    {
      cpy_path[strlen(cpy_path)] = '/';
      cpy_path[strlen(cpy_path)+1] = 0;
    }

  char* p_first = NULL;
  char* p_curr = cpy_path;
  char* p_next = NULL;

  /* Clear process umask */
  mode_t mask = umask(0);

  while ((p_first = strtok_r(p_curr, "/", &p_next)) != NULL)
    {
      p_curr = NULL;

      snprintf(p_path, STRING_MAX_LENGTH, "%s/", p_first); p_path = tmp_path + strlen(tmp_path);

      if ((mkdir(tmp_path, mode) != 0) && (errno != EEXIST))
	{
	  status = STATUS_ERROR;
	  break;
	}
      else
	{
	  status = STATUS_SUCCESS;
	}
    }

  /* Restore process umask */
  umask(mask);

  return status;

};

/* String related functions */

static inline char* strupper (char* s) { char* p = s; for (; *p; ++p) *p = toupper( *p ); return s; };
static inline char* strlower (char* s) { char* p = s; for (; *p; ++p) *p = tolower( *p ); return s; };
static inline char* sstrncpy (char* dst, const char* src, int size) { if (size > 0) { strncpy(dst, src, size); dst[size-1] = 0; } return dst; }; /* Safe strncpy */

/* Time related functions */

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline void ns_to_timespec (uint64_t nsec, struct timespec& time) { time.tv_sec = nsec / 1000000000L; time.tv_nsec = nsec - (1000000000L * time.tv_sec); return; };
static inline uint64_t timespec_to_ns (uint32_t sec, uint32_t nsec) { return (1000000000L * (uint64_t) sec) + (uint64_t) nsec; };
static inline uint64_t timespec_to_ns (struct timespec& time) { return timespec_to_ns(time.tv_sec, time.tv_nsec); };

static inline uint64_t get_time (void) { struct timespec time; clock_gettime(CLOCK_REALTIME, &time); return timespec_to_ns(time); };

#else

static inline void ns_to_timespec (uint64_t nsec, struct timespec* time) { time->tv_sec = nsec / 1000000000L; time->tv_nsec = nsec - (1000000000L * time->tv_sec); return; };
static inline uint64_t timespec_to_ns (struct timespec* time) { return (1000000000L * (uint64_t) time->tv_sec) + (uint64_t) time->tv_nsec; };

static inline uint64_t get_time (void) { struct timespec time; clock_gettime(CLOCK_REALTIME, &time); return timespec_to_ns(&time); };

#endif

static inline uint64_t ceil_time (uint64_t time) { return 1000000000L * (1 + (time / 1000000000L)); }; /* Higher integral second */
static inline uint64_t floor_time (uint64_t time) { return 1000000000L * (time / 1000000000L); }; /* Lower integral second */
static inline uint64_t trunc_time (uint64_t time) { uint64_t sec = floor_time(time); return (((time - sec) < 500000000L) ? sec : ceil_time(time)); }; /* Closest integral second */

static inline uint64_t wait_for (uint32_t sec, uint64_t nsec) { if ((sec != 0) || (nsec != 0)) { struct timespec time; time.tv_sec = sec; while (nsec >= 1000000000L) { time.tv_sec += 1; nsec -= 1000000000L; } time.tv_nsec = nsec; nanosleep(&time, NULL); } return get_time(); };
static inline uint64_t wait (uint32_t sec, uint64_t nsec) { return wait_for(sec, nsec); };

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline uint64_t floor_time (uint64_t time, uint64_t resolution) { return resolution * (time / resolution); }; /* Lower integral resolution */
static inline uint64_t ceil_time (uint64_t time, uint64_t resolution) { return resolution + floor_time(time, resolution); }; /* Higher integral resolution */

static inline uint64_t wait_for (uint64_t interval) { return wait_for(0,interval); };
static inline uint64_t wait (uint64_t interval) { return wait_for(0,interval); };

#endif

static inline uint64_t wait_until (uint64_t till, uint64_t accuracy)
{

  uint64_t time = get_time();

  if (time > till) 
    return time;

  /* Sleep till some time before target */
  while ((time < till) && ((till - time) > DEFAULT_WAIT_UNTIL_SLEEP_LIMIT)) /* Larger than 100us */
    {
      time = wait_for(0,accuracy); /* nanosleep */
    }

  /* Spin till target has been reached */
  while (time < till)
    {
      time = get_time();
    }

  return time;

};

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline uint64_t wait_until (uint64_t till) { return wait_until(till, DEFAULT_WAIT_UNTIL_SLEEP_PERIOD); };

static inline void format_time (struct timespec& time, char* buffer, bool short_form)
{

  char* p_buf = buffer;

  if (time.tv_sec == 0)
    {
      sstrncpy(p_buf, (char*) "Undefined", STRING_MAX_LENGTH);
    }
  else if (short_form == true)
    {
      /* Format timestamp */
      strftime(p_buf, STRING_MAX_LENGTH, "%Y%m%d%H%M%S", localtime(&(time.tv_sec))); p_buf = buffer + strlen(buffer); /* Re-align */
    }
  else
    {
      /* Format timestamp */
      strftime(p_buf, STRING_MAX_LENGTH, "%FT%T.", localtime(&(time.tv_sec))); p_buf = buffer + strlen(buffer); /* Re-align */
      snprintf(p_buf, STRING_MAX_LENGTH, "%.9ld", time.tv_nsec); p_buf = buffer + strlen(buffer); /* Re-align */
    }

  return;

};

static inline void format_time (struct timespec& time, char* buffer) { return format_time(time, buffer, false); };
static inline void format_time (uint64_t time, char* buffer, bool short_form) { struct timespec time_spec; ns_to_timespec(time, time_spec); return format_time(time_spec, buffer, short_form); };
static inline void format_time (uint64_t time, char* buffer) { return format_time(time, buffer, false); };
static inline void format_time (char* buffer) { return format_time(get_time(), buffer); };

#else

static inline void format_time (struct timespec* time, char* buffer, bool short_form)
{

  char* p_buf = buffer;

  if (time->tv_sec == 0)
    {
      strncpy(p_buf, "Undefined", STRING_MAX_LENGTH);
    }
  else if (short_form == true)
    {
      /* Format timestamp */
      strftime(p_buf, STRING_MAX_LENGTH, "%Y%m%d%H%M%S", localtime(&(time->tv_sec))); p_buf = buffer + strlen(buffer); /* Re-align */
    }
  else
    {
      /* Format timestamp */
      strftime(p_buf, STRING_MAX_LENGTH, "%FT%T.", localtime(&(time->tv_sec))); p_buf = buffer + strlen(buffer); /* Re-align */
      snprintf(p_buf, STRING_MAX_LENGTH, "%.9ld", time->tv_nsec); p_buf = buffer + strlen(buffer); /* Re-align */
    }

  return;

};

#endif

/* Thread related functions */

static inline int get_current_core (void) { return sched_getcpu(); };
static inline int get_process_id (void) { return getpid(); };
static inline pthread_t get_thread_id (void) { return pthread_self(); };

static inline RET_STATUS lock_memory_page (void)
{

  RET_STATUS status = STATUS_ERROR;

  /* Lock current and future allocated memory pages */
  if (mlockall(MCL_CURRENT|MCL_FUTURE) == 0)
    {
      status = STATUS_SUCCESS;
    }

  return status;

};

static inline RET_STATUS set_thread_priority (pthread_t tid, int policy, int priority) /* Some thread */
{

  RET_STATUS status = STATUS_ERROR;
  struct sched_param sp;

  /* Assign scheduling policy and priority */
  sp.sched_priority = priority;

  if (pthread_setschedparam(tid, policy, &sp) == 0)
    {
      status = STATUS_SUCCESS;
    }

  return status;

};

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline RET_STATUS set_thread_priority (int policy, int priority) { return set_thread_priority(get_thread_id(), policy, priority); }; /* Calling thread */
static inline RET_STATUS set_thread_priority (void) { return set_thread_priority(DEFAULT_THREAD_SCHEDULING_POLICY, DEFAULT_THREAD_SCHEDULING_PRIORITY); }; /* Calling thread */

#endif

static inline RET_STATUS release_priviledges (void)
{

  RET_STATUS status = STATUS_ERROR;

  /* Release superuser priviledges */
  if (setuid(getuid()) == 0)
    {
      status = STATUS_SUCCESS;
    }
   
  return status;

};

static inline RET_STATUS set_thread_affinity_to_core (pthread_t tid, int core_id) /* Should be able to call this iteratively */
{

  RET_STATUS status = STATUS_ERROR;
  int num_cores = sysconf(_SC_NPROCESSORS_ONLN);

  if (core_id < 0 || core_id >= num_cores)
    {
      return status;
    }

  cpu_set_t cpuset; 

  CPU_ZERO(&cpuset); 
  CPU_SET(core_id, &cpuset);

  if (pthread_setaffinity_np(tid, sizeof(cpu_set_t), &cpuset) == 0)
    {
      status = STATUS_SUCCESS;
    }
  
  return status;

};

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline RET_STATUS set_thread_affinity_to_core (int core_id) { return set_thread_affinity_to_core(get_thread_id(), core_id); }; /* Calling thread */
static inline RET_STATUS set_thread_affinity_to_core (void) { return set_thread_affinity_to_core(DEFAULT_THREAD_SCHEDULING_AFFINITY); }; /* Calling thread */

#endif

/* Miscellaneous functions */

static inline RET_STATUS get_env_variable (char* env_name, char* env_var, uint_t max_size)
{

  RET_STATUS status = STATUS_ERROR;

  if ((getenv(env_name) == NULL) || (strlen(getenv(env_name)) == 0))
    {
    }
  else if (strlen(getenv(env_name)) >= max_size) /* Warning - strlen does not count trailing '\0' */
    {
    }
  else
    {
      sstrncpy(env_var, getenv(env_name), max_size);
      status = STATUS_SUCCESS;
    }
    
  return status;

};

static inline RET_STATUS set_env_variable (char* env_name, char* env_var)
{

  RET_STATUS status = STATUS_ERROR;

  /* Try and resolve variable, if encessary */
  //resolve_variable_path(env_var);

  if (setenv(env_name, env_var, 1) != 0) 
    { 
    }
  else
    {
      status = STATUS_SUCCESS;
    }
    
  return status;

};

static inline bool is_variable_string (char* str) { return (((*str == '$')) ? true : false); };

static inline RET_STATUS resolve_variable_string (char* in_str, char* out_str, uint_t max_size) /* Currently limited to ${..}/suffix */
{

  RET_STATUS status = STATUS_ERROR;

  if (strlen(in_str) >= max_size) /* Warning - strlen does not count trailing '\0' */
    {
      return status;
    }

  sstrncpy(out_str, in_str, max_size);

  if (is_variable_string(in_str) != true)
    {
      status = STATUS_SUCCESS;
      return status;
    }

  {

  /* Extract environment variable name */
  char* p_suf = NULL;
  char* p_env = NULL;

  p_env = strtok_r(out_str, "${}/", &p_suf);

  if ((getenv(p_env) == NULL) || (strlen(getenv(p_env)) == 0)) /* Warning - strlen */
    { 
      /* Error - Unable to resolve environment variable */
    }
  else if (strlen(getenv(p_env)) >= max_size) /* Warning - strlen does not count trailing '\0' */
    {
      /* Warning - Environment variable is longer than output buffer - Do nothing */
    }
  else
    {
      char path_env [max_size];
      char path_suf [max_size];
	      
      sstrncpy(path_env, getenv(p_env), max_size);

      if (*p_suf != 0) 
	{
	  sstrncpy(path_suf, p_suf, max_size);
	  snprintf(out_str, max_size, ((*p_suf == '/') ? "%s%s" : "%s/%s"), path_env, path_suf);
	}
      else
	{
	  sstrncpy(out_str, path_env, max_size);
	}
    }

  status = STATUS_SUCCESS;

  }

  return status;

};

#ifdef __cplusplus /* Only allow for overloading for C++ code base */

static inline RET_STATUS get_env_variable (char* env_name, char* env_var) { return get_env_variable(env_name, env_var, STRING_MAX_LENGTH); };

static inline RET_STATUS resolve_variable_string (char* inout_str)
{

  RET_STATUS status = STATUS_ERROR;

  if (inout_str == NULL) return status;

  char tmp_str [STRING_MAX_LENGTH];

  strncpy(tmp_str, inout_str, STRING_MAX_LENGTH);

  status = resolve_variable_string(inout_str, tmp_str, STRING_MAX_LENGTH);

  strncpy(inout_str, tmp_str, STRING_MAX_LENGTH);

  return status;

};

static inline RET_STATUS resolve_variable_path (char* inout_path)
{

  RET_STATUS status = STATUS_ERROR;

  if (inout_path == NULL) return status;

  char tmp_path [PATH_MAX_LENGTH];

  strncpy(tmp_path, inout_path, PATH_MAX_LENGTH);

  status = resolve_variable_string(inout_path, tmp_path, PATH_MAX_LENGTH);

  strncpy(inout_path, tmp_path, PATH_MAX_LENGTH);

  return status;

};

#endif

static inline RET_STATUS get_ccs_version (char* version) { return get_env_variable((char*) "CODAC_VERSION", version); };
static inline RET_STATUS get_host_name (char* host_name) { return get_env_variable((char*) "HOSTNAME", host_name); };

static inline RET_STATUS get_program_name (char* prog_name)
{

  RET_STATUS status = STATUS_ERROR;

  char p_link[256] = "";
  ssize_t size = 0;

  if ((size = readlink("/proc/self/exe", p_link, sizeof(p_link))) == -1)
    {
      return status;
    }

  char* p_first = NULL;
  char* p_curr = p_link;
  char* p_next = NULL;

  while (strtok_r(p_curr, "/", &p_next) != NULL)
    {
      p_first = p_curr;
      p_curr = p_next;
    }

  strcpy(prog_name, p_first);

  status = STATUS_SUCCESS;

  return status;

};

static inline RET_STATUS load_shared_library (char* library)
{

  RET_STATUS status = STATUS_ERROR;

  /* Load library */
  char lib_name [STRING_MAX_LENGTH]; sstrncpy(lib_name, library, STRING_MAX_LENGTH); 
  void* lib_handle = dlopen(lib_name, RTLD_NOW);

  if (lib_handle != NULL)
    {
      status = STATUS_SUCCESS;
    }

  return status;

};

#endif /* TOOLS_H */

