#ifndef SDN_PUBLISHER_H
#define SDN_PUBLISHER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-publisher.h $
* $Id: sdn-publisher.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */
#if 1 /* For backward compatibility purposes with v1.0 - This file can become part of the public API and that below be moved to the implementation file */
#include "sdn-api.h" /* SDN core library - API definition */
#else
#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "any-object.h" /* Root object class definition */
#include "sdn-base.h" /* Base classes definition */

#include "core-participant.h"
#include "core-publisher.h"

#include "disc-publisher.h"

#include "sdn-participant.h"

/* Constants */

#define OBJTYPE_SDN_PUBLISHER (char*) "sdn::Publisher_Base"

#ifdef __cplusplus

/* Type definition */

namespace sdn {

class Publisher_Base : public Participant_Impl /* Base class */
{

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Do (void) { return this->Publish(); }; /* Specializes virtual method */
    virtual RET_STATUS Publish (void) = 0; /* Pure virtual method */

    /* Constructor methods */
    Publisher_Base (void) { this->SetInstanceType(OBJTYPE_SDN_PUBLISHER); return; };

    /* Destructor method */
   ~Publisher_Base (void) {};

}; 

class Publisher_Impl : public Publisher_Base
{

  private:

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Configure (void);
    RET_STATUS Publish (void);

    /* Constructor methods */
    Publisher_Impl (void) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Impl (Metadata_t& mdata) { /* Initialize resources */ this->Initialize(); this->SetMetadata(mdata); return; };
    Publisher_Impl (const char* name) { /* Initialize resources */ this->Initialize(); this->SetTopicName(name); return; };
    Publisher_Impl (Topic& topic) { /* Initialize resources */ this->Initialize(); /* WARNING - Topic externally instantiated should not be destroyed upon Participant destruction */ (this->m_base)->m_mdata = topic.m_meta; (this->m_base)->m_topic = &topic; (this->m_base)->m_ext_topic = true; return; };

    /* Destructor method */
   ~Publisher_Impl (void) { (this->m_disc)->Remove(this->m_base); if (this->m_base != NULL) delete (core::Publisher_Impl*) this->m_base; this->m_base = NULL; return; };

};
#if 0
typedef class Publisher_Asyn : public Publisher_Impl
{

  private:

    base::AnyThread* m_thread; /* Thread to manage publisher instance */

    uint64_t m_accuracy;
    bool m_synchronous;  /* Publication is triggered when topic is externally updated */
    volatile bool m_trigger;  /* Publication is triggered when topic is externally updated */

    void (* m_cb) (void*); /* Routine called before topic publication  */
    void* m_attr;          /* Routine attribute */

    /* Initializer methods */
    void Initialize (void);

  public:

    /* Initializer methods */
    RET_STATUS Launch (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Launch(); return status; };
    RET_STATUS Terminate (void) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->Terminate(); return status; };

    /* Accessor methods */
    RET_STATUS SetAffinity (uint_t core) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetAffinity(core); return status; };
    RET_STATUS SetCallback (void (* cb)(void*)) { this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { this->m_attr = attr; this->m_cb = cb; return STATUS_SUCCESS; };
    RET_STATUS SetPeriod (uint64_t period, int64_t phase = 0L, uint64_t accuracy = DEFAULT_THREAD_ACCURACY);
    RET_STATUS SetPriority (uint_t policy, uint_t priority) { RET_STATUS status = STATUS_ERROR; if (this->m_thread != NULL) status = (this->m_thread)->SetPriority(policy, priority); return status; };

    /* Miscellaneous methods */
    RET_STATUS Preamble (void) { return this->Configure(); };
    RET_STATUS Do (void);
    RET_STATUS Trigger (void) { return ((__sync_val_compare_and_swap(&(this->m_trigger), false, true)) ? STATUS_ERROR : STATUS_SUCCESS); };

    /* Constructor methods */
    Publisher_Asyn (void) : Publisher_Impl() { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (Metadata_t& mdata) : Publisher_Impl(mdata) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (const char* name) : Publisher_Impl(name) { /* Initialize resources */ this->Initialize(); return; };
    Publisher_Asyn (Topic& topic) : Publisher_Impl(topic) { /* Initialize resources */ this->Initialize(); return; };

    /* Destructor method */
   ~Publisher_Asyn (void) { if (this->m_thread != NULL) delete this->m_thread; this->m_thread = NULL; return; };

} PublisherThread; /* For backward compatibility purposes with v1.0 */
#endif
/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace sdn */

using namespace sdn; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */
#endif
#endif /* SDN_PUBLISHER_H */
