#ifndef LOG_API_H
#define LOG_API_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/log-api.h $
* $Id: log-api.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Some useful POSIX wrappers or routines
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdarg.h> /* va_start, etc. */
#include <syslog.h> /* Log message severity */

/* Local header files */

#include "types.h" /* Misc. type definition, e.g. RET_STATUS */

/* Constants */

#ifndef LOG_ALTERN_SRC
#define LOG_ALTERN_SRC ""
#endif

#ifndef LOG_TRACE
#define LOG_TRACE 8 /* LOG_DEBUG+1 */
#endif

#ifndef LOG_ERROR
#define LOG_ERROR LOG_ERR
#endif

#ifndef LOG_EMERGENCY
#define LOG_EMERGENCY LOG_EMERG
#endif

#ifndef LOG_CRITICAL
#define LOG_CRITICAL LOG_CRIT
#endif

#ifndef LOG_CASUAL
#define LOG_CASUAL LOG_INFO
#endif

#ifndef log_trace
#ifdef LOG_TRACE_ENABLE
#define log_trace(arg_msg, ...) { char source [STRING_MAX_LENGTH] = STRING_UNDEFINED; snprintf(source, STRING_MAX_LENGTH, "%s line %d", __FILE__, __LINE__); log_msg(LOG_TRACE, (char*) source, (char*) arg_msg, ## __VA_ARGS__); }
#else
#define log_trace(arg_msg...) {}
#endif
#endif

#ifndef log_debug
#ifdef LOG_DEBUG_ENABLE
#define log_debug(arg_msg, ...) { char source [STRING_MAX_LENGTH] = STRING_UNDEFINED; snprintf(source, STRING_MAX_LENGTH, "%s line %d", __FILE__, __LINE__); log_msg(LOG_DEBUG, (char*) source, (char*) arg_msg, ## __VA_ARGS__); }
#else
#define log_debug(arg_msg...) {}
#endif
#endif

#ifndef log_info
#define log_info(arg_msg, ...) log_msg(LOG_INFO, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifndef log_notice
#define log_notice(arg_msg, ...) log_msg(LOG_NOTICE, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifndef log_warning
#define log_warning(arg_msg, ...) log_msg(LOG_WARNING, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifndef log_error
#define log_error(arg_msg, ...) log_msg(LOG_ERROR, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifndef log_critical
#define log_critical(arg_msg, ...) log_msg(LOG_CRITICAL, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifndef log_alert
#define log_alert(arg_msg, ...) log_msg(LOG_ALERT, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifndef log_emergency
#define log_emergency(arg_msg, ...) log_msg(LOG_EMERGENCY, LOG_ALTERN_SRC, arg_msg, ## __VA_ARGS__)
#endif

#ifdef __cplusplus

/* Type definition */

namespace ccs {

namespace log {

typedef int Severity_t;
typedef void (*Func_t) (Severity_t, const char*, const char*, va_list);

/* Global variables */

/* Function declaration */

void vMessage2Stdout (Severity_t severity, const char* source, const char* message, va_list args);
void vMessage2Syslog (Severity_t severity, const char* source, const char* message, va_list args);

/* WARNING - Confusion in case of log_level(<format>, '0') argument which can be interpreted as '(va_list) NULL'.
             The methods are named differently to ensure that the log_level macros are all pointing to the same
             method in any condition.
 */

void vMessage (Severity_t severity, const char* source, const char* message, va_list args);
void Message (Severity_t severity, const char* source, const char* message, ...);

Func_t SetCallback (Func_t cb); 
Severity_t SetFilter (Severity_t level);

/* Function definition */

static inline Func_t SetStdout (void) { return SetCallback(&vMessage2Stdout); };
static inline Func_t SetSyslog (void) { return SetCallback(&vMessage2Syslog); };

}; /* namespace log */

}; /* namespace ccs */

using namespace ccs::log; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

void log_msg (int severity, const char* source, const char* message, ...);

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* LOG_API_H */

