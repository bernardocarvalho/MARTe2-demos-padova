#ifndef SDN_DISC_H
#define SDN_DISC_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-disc.h $
* $Id: sdn-disc.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

//#include "sdn-base.h"   /* Favour PIMPL design pattern to avoid exposing the structure through the public interface */
//#include "sdn-mcast.h"  /* SDN core library - API definition (sdn::mcast) */

#include "sdn-topic.h"

#include "disc-participant.h"
#include "disc-publisher.h"
#include "disc-subscriber.h"

/* Constants */

/* Type definition */

/* Global variables */

/* Function declaration */

/* Function definition */

#endif /* SDN_DISC_H */
