#ifndef BASE_PARTICIPANT_H
#define BASE_PARTICIPANT_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/base-participant.h $
* $Id: base-participant.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

/* Constants */

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace base {

typedef class Participant_Iface /* Interface definition */
{

  public:

    /* Initializer methods */

    /* Accessor methods */
    //virtual const char* GetInterfaceAddress (void) = 0; /* Pure virtual method */
    virtual const char* GetInterface (void) = 0; /* Pure virtual method */
    virtual const char* GetAddress (void) = 0;   /* Pure virtual method */
    virtual uint_t GetPort (void) = 0; /* Pure virtual method */

    virtual void SetInterface (const char* iface) = 0; /* Pure virtual method */
    virtual void SetAddress (const char* addr) = 0;    /* Pure virtual method */
    virtual void SetPort (uint_t port) = 0; /* Pure virtual method */

    virtual void* GetBuffer (void) = 0; /* Pure virtual method */
    virtual uint_t GetSize (void) = 0;  /* Pure virtual method */
    virtual void SetBuffer (void* buffer, uint_t size) = 0; /* Pure virtual method */

    virtual RET_STATUS SetCallback (void (* cb)(void*)) = 0; /* Pure virtual method */
    virtual RET_STATUS SetCallback (void (* cb)(void*), void* attr) = 0; /* Pure virtual method */

    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) = 0;    /* Pure virtual method */
    virtual RET_STATUS Open (void) = 0;  /* Pure virtual method */
    virtual RET_STATUS Close (void) = 0; /* Pure virtual method */

    /* Constructor methods */
    Participant_Iface (void) {};

    /* Destructor method */
    virtual ~Participant_Iface (void) {}; /* Note - virtual destructor to ensure that sdn::core::Participant deleting this would call upon the appropriate destructor */

} Participant;

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace ucast */

}; /* namespace sdn */

using namespace sdn::base; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* BASE_PARTICIPANT_H */
