#ifndef SDN_CORE_API_H
#define SDN_CORE_API_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-api.h $
* $Id: sdn-api.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*                 CS 90 046
*                 13067 St. Paul-lez-Durance Cedex
*                 France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

//#include "sdn-mcast.h" /* SDN core library - API definition (sdn::mcast) */
//#include "sdn-core.h"  /* SDN core library - API definition (sdn::core) */
//#include "sdn-disc.h"  /* SDN core library - API definition (sdn::disc) */

//#include "sdn-header.h" /* Favour forward class declaration*/
//#include "sdn-footer.h" /* Favour forward class declaration*/
#include "sdn-topic.h" 
//#include "sdn-packet.h" /* Favour forward class declaration*/ /* For backward compatibility purposes with v1.0 - Deprecated */

/* Constants */

#ifdef __cplusplus

#define SDNParticipant sdn::Participant /* For backward compatibility purposes with v1.0 */
//#define SDNPublisher sdn::Publisher   /* SDNPublisher class name used in MARTe namespace */
//#define SDNSubscriber sdn::Subscriber /* SDNSubscriber class name used in MARTe namespace */

/* Type definition */

namespace sdn {

class Header; /* Forward class declaration */
class Footer; /* Forward class declaration */
class Packet; /* Forward class declaration */

class Publisher_Impl;  /* Forward class declaration */
class Subscriber_Impl; /* Forward class declaration */

typedef class Participant_Iface
{

  public:

    Header* m_header; /* The instance of the class */ /* For backward compatibility purposes with v1.0 */
    Footer* m_footer; /* The instance of the class */ /* For backward compatibility purposes with v1.0 */
    Topic* m_topic;   /* The instance of the class */ /* For backward compatibility purposes with v1.0 */
    Packet* m_packet; /* The instance of the class */ /* For backward compatibility purposes with v1.0 - Deprecated */

    /* Initializer methods */

    /* Accessor methods */
    virtual bool IsInitialized (void) = 0; /* Pure virtual method */ /* Successfully configured */

    virtual char* GetInterface (void) = 0; /* Pure virtual method */
    virtual char* GetTopicName (void) = 0; /* Pure virtual method */
    virtual uint_t GetTopicSize (void) = 0; /* Pure virtual method */

    virtual RET_STATUS SetInterface (const char* name) = 0; /* Pure virtual method */
    virtual RET_STATUS SetTopicName (const char* name) = 0; /* Pure virtual method */
    virtual RET_STATUS SetMetadata (Metadata_t& mdata) = 0; /* Pure virtual method */

    virtual RET_STATUS CopyTopicInstance (void* instance, uint_t size) = 0; /* Pure virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicHeader (void) = 0;   /* Pure virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicFooter (void) = 0;   /* Pure virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicInstance (void) = 0; /* Pure virtual method */ /* The data payload and not the instance of the class */

    virtual RET_STATUS SetCallback (void (* cb)(void*)) = 0; /* Pure virtual method */ /* Routine called as part of message handling */
    virtual RET_STATUS SetCallback (void (* cb)(void*), void* attr) = 0; /* Pure virtual method */ /* Routine called as part of message handling */
    
    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) = 0;        /* Pure virtual method */
    virtual RET_STATUS Configure (void) = 0; /* Pure virtual method */

    /* Constructor methods */
    Participant_Iface (void) { /* Initialize attributes */ this->m_header = NULL; this->m_footer = NULL; this->m_topic = NULL; this->m_packet = NULL; return; };

    /* Destructor method */
    virtual ~Participant_Iface (void) {}; /* Note - virtual destructor */

   /* Display methods */

} Participant; /* For backward compatibility purposes with v1.0 */

typedef class Publisher_Iface : public Participant_Iface
{
        
  private:
    
    Publisher_Impl* p_impl;
    
  public:
        
    /* Initializer methods */
        
    /* Accessor methods */
    virtual bool IsInitialized (void); /* Specializes virtual method */
        
    virtual char* GetInterface (void); /* Specializes virtual method */
    virtual char* GetTopicName (void); /* Specializes virtual method */
    virtual uint_t GetTopicSize (void); /* Specializes virtual method */
        
    virtual RET_STATUS SetInterface (const char* name); /* Specializes virtual method */
    virtual RET_STATUS SetTopicName (const char* name); /* Specializes virtual method */
    virtual RET_STATUS SetMetadata (Metadata_t& mdata); /* Specializes virtual method */
        
    virtual RET_STATUS CopyTopicInstance (void* instance, uint_t size); /* Specializes virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicHeader (void);   /* Specializes virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicFooter (void);   /* Specializes virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicInstance (void); /* Specializes virtual method */ /* The data payload and not the instance of the class */
        
    virtual RET_STATUS SetCallback (void (* cb)(void*)); /* Specializes virtual method */ /* Routine called before message publication */
    virtual RET_STATUS SetCallback (void (* cb)(void*), void* attr); /* Specializes virtual method */ /* Routine called before message publication */
        
    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) { return this->Publish(); }; /* Specializes virtual method */
    virtual RET_STATUS Configure (void); /* Specializes virtual method */

    RET_STATUS Publish (void);
    
    /* Constructor methods */
    Publisher_Iface (void);
    Publisher_Iface (Metadata_t& mdata);
    Publisher_Iface (const char* name);
    Publisher_Iface (Topic& topic); /* WARNING - Topic externally instantiated should not be destroyed upon Participant destruction */ 
        
    /* Destructor method */
    virtual ~Publisher_Iface (void); /* Note - virtual destructor */
        
    /* Display methods */
        
} Publisher; /* For backward compatibility purposes with v1.0 */
    
typedef class Subscriber_Iface : public Participant_Iface
{
        
  private:
        
    Subscriber_Impl* p_impl;
        
  public:
        
    /* Initializer methods */
        
    /* Accessor methods */
    virtual bool IsInitialized (void); /* Specializes virtual method */
        
    virtual char* GetInterface (void); /* Specializes virtual method */
    virtual char* GetTopicName (void); /* Specializes virtual method */
    virtual uint_t GetTopicSize (void); /* Specializes virtual method */
        
    virtual RET_STATUS SetInterface (const char* name); /* Specializes virtual method */
    virtual RET_STATUS SetTopicName (const char* name); /* Specializes virtual method */
    virtual RET_STATUS SetMetadata (Metadata_t& mdata); /* Specializes virtual method */
        
    virtual RET_STATUS CopyTopicInstance (void* instance, uint_t size); /* Specializes virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicHeader (void);   /* Specializes virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicFooter (void);   /* Specializes virtual method */ /* The data payload and not the instance of the class */
    virtual void* GetTopicInstance (void); /* Specializes virtual method */ /* The data payload and not the instance of the class */
        
    virtual RET_STATUS SetCallback (void (* cb)(void*)); /* Specializes virtual method */ /* Routine called after message reception */
    virtual RET_STATUS SetCallback (void (* cb)(void*), void* attr); /* Specializes virtual method */ /* Routine called after message reception */
        
    /* Miscellaneous methods */
    virtual RET_STATUS Do (void) { return this->Receive(); }; /* Specializes virtual method */
    virtual RET_STATUS Configure (void); /* Specializes virtual method */
        
    RET_STATUS Receive (void);
    RET_STATUS Receive (uint64_t timeout);

    /* Constructor methods */
    Subscriber_Iface (void);
    Subscriber_Iface (Metadata_t& mdata);
    Subscriber_Iface (const char* name);
    Subscriber_Iface (Topic& topic);
        
    /* Destructor method */
    virtual ~Subscriber_Iface (void); /* Note - virtual destructor */
        
    /* Display methods */
        
} Subscriber; /* For backward compatibility purposes with v1.0 */

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace sdn */

using namespace sdn; /* Allow for declaring intention only with including this header file */

extern "C" {
    
#endif /* __cplusplus */
    
/* ToDo - Insert C API declaration */
    
#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* SDN_CORE_API_H */
