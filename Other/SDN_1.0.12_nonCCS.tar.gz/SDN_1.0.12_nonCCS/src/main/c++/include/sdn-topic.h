#ifndef SDN_TOPIC_H
#define SDN_TOPIC_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-topic.h $
* $Id: sdn-topic.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */
#include "sdn-tools.h"

//#include "sdn-base.h" /* Privately scoped case classes definition */
#include "any-type-xml.h" /* Type introspection from XML file */

/* Constants */

#define SDNTopic sdn::Topic /* For backward compatibility purposes with CCSv5.2 */
#define sdn_topic sdn::Topic /* For backward compatibility purposes with CCSv5.2 */

#define SDNMetadata sdn::Metadata_t /* For backward compatibility purposes with CCSv5.2 */
#define sdn_metadata sdn::Metadata_t /* For backward compatibility purposes with CCSv5.2 */

#define SDNTools_LocateTopicDefinition sdn::Topic_LocateDefinitionFile /* For backward compatibility purposes with CCSv5.2 */

/* Type definition */

namespace sdn {

typedef struct Metadata
{

  char name [STRING_MAX_LENGTH];
  //char vers [STRING_MAX_LENGTH];
  //char desc [STRING_MAX_LENGTH];

  uint_t hash; /* UID computed from name, version, and type definition */
  uint_t size;
  uint_t vers;
  
  /* Derived from topic name */
  char   mcast_group [MAX_IP_ADDR_LENGTH];
  uint_t mcast_port;
    
} Metadata_t; 

class Topic
{

  private:

    sdn::base::AnyType* m_type_def;
    uint8_t* m_instance;

    bool m_allocated;

    /* Initializer methods */
    void Initialize (void);
    RET_STATUS Load (const char* file_path);

  public:

    Metadata_t m_meta; /* To collect all metadata information */

    /* Initializer methods */
    RET_STATUS Configure (void);

    RET_STATUS AddAttribute (uint_t rank, const char* name, const char* type, uint_t mult = 1); /* WARNING - MARTe2 Integration - Interface used by SDNPublisher DataSource */
    template <class Type> RET_STATUS AddAttribute (uint_t rank, const char* name, uint_t mult = 1) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->AddAttribute<Type>(rank, (char*) name, mult); this->SetUID(); return status; };
 
    void ClearInstance (void);
    RET_STATUS CreateInstance (void);
    void DeleteInstance (void) { if ((this->m_type_def != NULL) && ((this->m_type_def)->IsInitialized() == true)) (this->m_type_def)->DeleteInstance(); else if ((this->m_allocated == true) && (this->m_instance != NULL)) delete [] this->m_instance; this->m_instance = NULL; return; };

    /* Accessor methods */
    bool IsInitialized (void) { return (((this->GetSize() != 0) && (this->GetSize() <= MAX_TOPIC_SIZE) && ((this->m_type_def)->IsDefined() == true))? true : false ); };

    char* HasInstanceIndex (void);
    char* HasInstanceTimestamp (void);

    void GetMetadata (Metadata_t& mdata);
    void SetMetadata (Metadata_t& mdata);

    bool IsName (const char* name);
    char* GetName (void);
    void SetName (const char* name);

    uint_t GetInstanceChecksum (void);

    uint_t GetSize (void);
    void SetSize (uint_t size);
    void SetSize (const char* size_str);

    uint_t GetUID (void);
    void SetUID (uint_t hash);
    void SetUID (const char* uid_str);
    void SetUID (void);

    uint_t GetVersion (void);
    void SetVersion (const char* vers);
    void SetVersion (uint_t vers);

    char* GetMCastGroup (void);
    void SetMCastGroup (const char* group); /* Warning - Size of string */

    uint_t GetMCastPort (void);
    void SetMCastPort (uint_t port);
    void SetMCastPort (const char* port_str);

    void* GetInstance (void);
    void SetInstance (void* instance);

    sdn::base::AnyType* GetTypeDefinition (void) { return this->m_type_def; };
    RET_STATUS SetTypeDefinition (sdn::base::AnyType* p_def) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def == NULL) { this->m_type_def = p_def; status = STATUS_SUCCESS; } return status; };

    template <class Type> RET_STATUS GetAttribute (uint_t rank, Type* p_value) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->GetAttribute((uint_t) rank, (Type*) p_value); return status; }; 
    RET_STATUS GetAttribute(uint_t rank, void* p_value) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->GetAttribute(rank, p_value); return status; };
    RET_STATUS GetAttribute(const char* name, void* p_value) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->GetAttribute((char*) name, p_value); return status; };

    template <class Type> RET_STATUS SetAttribute (uint_t rank, Type value) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->SetAttribute((uint_t) rank, (Type) value); return status; }; 
    RET_STATUS SetAttribute(uint_t rank, void* p_value) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->SetAttribute(rank, p_value); return status; };
    RET_STATUS SetAttribute(const char* name, void* p_value) { RET_STATUS status = STATUS_ERROR; if (this->m_type_def != NULL) status = (this->m_type_def)->SetAttribute((char*) name, p_value); return status; };

    /* Miscellaneous methods */

    /* Constructor methods */
    Topic (void);
    Topic (Metadata_t& mdata);
    Topic (const char* name);

    /* Destructor method */
   ~Topic (void);

    /* Display methods */
    uint_t SerializeType (char* buffer, int max_size = STRING_MAX_LENGTH);

    RET_STATUS SerializeInstance (char* buffer, int max_size = STRING_MAX_LENGTH);

};

/* Global variables */

/* Function declaration */

RET_STATUS Topic_LocateDefinitionFile (const char* name, char* file_path, uint_t max_size = PATH_MAX_LENGTH);
RET_STATUS Topic_GenerateMCastAddress (Metadata_t& mdata);
bool Topic_IsMetadataValid (Metadata_t& mdata);

/* 
   Documentation - The topic metadata could be instantiated in short form using 'sdn://<address>:<port>/<name>'.
 */

void Topic_InitializeMetadata (Metadata_t& mdata);
void Topic_InitializeMetadata (Metadata_t& mdata, const char* name);
void Topic_InitializeMetadata (Metadata_t& mdata, const char* name, uint_t size);
void Topic_InitializeMetadata (Metadata_t& mdata, const char* name, uint_t size, const char* addr, uint_t port = DEFAULT_MCAST_PORT);
void Topic_InitializeMetadata (Metadata_t& mdata, const char* name, uint_t size, uint_t vers);

/* Function definition */

static inline bool Topic_IsAddressValid (Metadata_t& mdata) { return sdn_is_address_valid((const char*) mdata.mcast_group); };
static inline bool Topic_IsMCastAddress (Metadata_t& mdata) { return sdn_is_mcast_address((const char*) mdata.mcast_group); };
static inline bool Topic_IsUCastAddress (Metadata_t& mdata) { return sdn_is_ucast_address((const char*) mdata.mcast_group); };

}; /* namespace sdn */

#endif /* SDN_TOPIC_H */
