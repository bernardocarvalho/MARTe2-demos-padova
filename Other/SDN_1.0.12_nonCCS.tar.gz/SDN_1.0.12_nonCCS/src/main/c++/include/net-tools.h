#ifndef NET_TOOLS_H
#define NET_TOOLS_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/net-tools.h $
* $Id: net-tools.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <linux/ethtool.h>
#include <linux/sockios.h>
#ifndef LINT /* MARTe2 Integration */
#include <stdio.h> /* fopen, getline, etc. */
#endif
/* Local header files */

#include "types.h" /* Misc. type definition */
#include "tools.h" /* Misc. helper functions */

//#include "log-wrap.h" /* Syslog wrapper routines */

/* Constants */

typedef enum PortStatistics_Id {

  PORT_STATISTICS_BYTES = 0,
  PORT_STATISTICS_PACKETS,
  PORT_STATISTICS_ERRORS,
  PORT_STATISTICS_DROPPED,
  PORT_STATISTICS_OVERRUN,
  PORT_STATISTICS_FRAME,      /* RX - TX is documented as collisions */
  PORT_STATISTICS_COMPRESSED, /* RX - TX is documented as carrier */
  PORT_STATISTICS_MCAST,      /* RX - TX is documented as compressed */

  PORT_STATISTICS_ARRAY_SIZE,

} PortStatistics_Id;

/* Type definition */

typedef struct PortStatistics {

  uint64_t rx [PORT_STATISTICS_ARRAY_SIZE];
  uint64_t tx [PORT_STATISTICS_ARRAY_SIZE];

} PortStatistics_t;

/* Global variables */

/* Function declaration */

/* Function definition */

static inline RET_STATUS net_get_ip_address (const char* iface_name, char* iface_addr, uint_t max_size = STRING_MAX_LENGTH)
{

  RET_STATUS status = STATUS_ERROR;

  struct ifreq ifr; memset(&ifr, 0, sizeof(ifr));

  sstrncpy(ifr.ifr_name, (char*) iface_name, IFNAMSIZ); 

  int fd_socket = socket(AF_INET, SOCK_DGRAM, 0);

  if (fd_socket < 0) 
    {
      //log_error("net_get_ip_address - socket failed with '%m'");
      return status;
    }

  /* Get address of selected local interface */
  if (ioctl(fd_socket, SIOCGIFADDR, &ifr) < 0)
    {
      //log_error("net_get_ip_address - ioctl(...) failed with '%d - %s'", errno, strerror(errno));
    }
  else
    {
      //log_debug("net_get_ip_address - ioctl SIOCGIFADDR successful with '%s'", inet_ntoa(((struct sockaddr_in*)&if_req.ifr_addr)->sin_addr));
      sstrncpy(iface_addr, inet_ntoa(((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr), max_size);
      status = STATUS_SUCCESS;
    }
  
  close(fd_socket);

  return status;
  
};

static inline RET_STATUS net_get_mac_address (const char* iface_name, char* iface_addr, uint_t max_size = STRING_MAX_LENGTH)
{

  RET_STATUS status = STATUS_ERROR;

  struct ifreq ifr; memset(&ifr, 0, sizeof(ifr));
  struct ethtool_perm_addr* info = (struct ethtool_perm_addr *) malloc(sizeof(struct ethtool_perm_addr) + 6);

  memset(info, 0, sizeof(struct ethtool_perm_addr) + 6);

  info->cmd = ETHTOOL_GPERMADDR;
  info->size = 6;
	
  sstrncpy(ifr.ifr_name, (char*) iface_name, IFNAMSIZ); 

  ifr.ifr_data = (char *) info;

  int fd_socket = socket(AF_INET, SOCK_DGRAM, 0);

  if (fd_socket < 0) 
    {
      //log_error("net_get_mac_address - socket failed with '%m'");
      return status;
    }

  if (ioctl(fd_socket, SIOCETHTOOL, &ifr) < 0) 
    {
      //log_error("net_get_mac_address - ioctl SIOCETHTOOL failed with '%m'");
    }
  else 
    {
      snprintf(iface_addr, max_size, "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x", info->data[0], info->data[1], info->data[2], info->data[3], info->data[4], info->data[5]);
      //log_debug("net_get_mac_address - ioctl SIOCETHTOOL successful with '%s'", iface_addr);
      status = STATUS_SUCCESS;
    }
      
  free(info);
  close(fd_socket);

  return status;
  
};

static inline RET_STATUS net_get_statistics (const char* iface_name, PortStatistics_t& iface_stats)
{

  RET_STATUS status = STATUS_ERROR;
#if 0 /* This call is driver/device specific */
  struct ifreq ifr;
  struct ethtool_stats* info = (struct ethtool_stats *) malloc(sizeof(struct ethtool_stats) + 1000);

  memset(&ifr, 0, sizeof(ifr));
  memset(info, 0, sizeof(struct ethtool_stats) + 1000);

  info->cmd = ETHTOOL_GSTATS;
  info->n_stats = 8;
	
  sstrncpy(ifr.ifr_name, (char*) iface_name, IFNAMSIZ); 

  ifr.ifr_data = (char *) info;

  int fd_socket = socket(AF_INET, SOCK_DGRAM, 0);

  if (fd_socket < 0) 
    {
      //log_error("net_get_statistics - socket failed with '%m'");
      return status;
    }

  if (ioctl(fd_socket, SIOCETHTOOL, &ifr) < 0) 
    {
      //log_error("net_get_statistics - ioctl SIOCETHTOOL failed with '%m'");
    }
  else 
    {
      //log_info("net_get_statistics - ioctl SIOCETHTOOL successful with '%u'", info->n_stats);

      for (uint_t index = 0; index < info->n_stats; index += 1)
	{
	  //log_info("net_get_statistics - ioctl SIOCETHTOOL successful with '%u %lu'", index, info->data[index]);
	}

      status = STATUS_SUCCESS;
    }
      
  free(info);
  close(fd_socket);
#else
  char file_path [STRING_MAX_LENGTH] = "/proc/net/dev";
  FILE* file_handle = fopen((char*) file_path, "r"); /* open( .. , O_RDONLY) */

  if (file_handle < 0)
    {
      //log_error("net_get_statistics - open failed with '%m'");
      return status;
    }

  char* line;
  size_t length;

  while (getline((char**) &line, &length, file_handle) != -1)
    {
      char* p_buf = line; while (*p_buf == ' ') p_buf += 1; /* Skip characters */

      if (strncmp(p_buf, (char*) iface_name, strlen((char*) iface_name)) == 0)
	{

	  p_buf += strlen((char*) iface_name); /* Skip characters */
	  while ((*p_buf < '0') || (*p_buf > '9'))  p_buf += 1; /* Skip characters */

	  /* Fill statistics buffer - We should now have space-separated numbers */
	  {

	    char* temp_ptr = NULL;
	    char* next_ptr = NULL;

	    uint64_t* p_array = (uint64_t*) &iface_stats;

	    while ((next_ptr = strtok_r(p_buf, (const char*) " ", &temp_ptr)) != NULL)
	      {
		p_buf = NULL;
		sscanf(next_ptr, "%lu", p_array); p_array += 1;
	      }

	  }

	  status = STATUS_SUCCESS;

	  break; /* Terminate */

	}

    }

  if (line != NULL) free(line);
 #endif
  return status;
  
};

static inline bool net_is_link_detected (const char* iface_name)
{

  bool status = false;

  struct ifreq ifr;
  struct ethtool_value info;

  memset(&ifr, 0, sizeof(ifr));
  memset(&info, 0, sizeof(info));

  info.cmd = ETHTOOL_GLINK;
	
  sstrncpy(ifr.ifr_name, (char*) iface_name, IFNAMSIZ);

  ifr.ifr_data = (char *) &info;

  int fd_socket = socket(AF_INET, SOCK_DGRAM, 0);

  if (fd_socket < 0) 
    {
      //log_error("net_is_link_detected - socket failed with '%m'");
      return status;
    }

  if (ioctl(fd_socket, SIOCETHTOOL, &ifr) < 0) 
    {
      //log_error("net_is_link_detected - ioctl SIOCETHTOOL failed with '%m'");
    }
  else 
    {
      //log_debug("net_is_link_detected - ioctl SIOCETHTOOL successful with '%u'", info.data);
      status = ((info.data == 1) ? true : false);
    }
      
  close(fd_socket);

  return status;
  
};

/* Bug 8722 - Test validity of network interface */
static inline bool net_is_interface_valid (const char* iface_name)
{

  char iface_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  return ((net_get_mac_address(iface_name, (char*) iface_addr, STRING_MAX_LENGTH) != STATUS_SUCCESS) ? false : true);

};

#endif /* NET_TOOLS_H */
