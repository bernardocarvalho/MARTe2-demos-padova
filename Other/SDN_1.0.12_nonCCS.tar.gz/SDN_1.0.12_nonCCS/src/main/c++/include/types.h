#ifndef TYPES_H
#define TYPES_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/types.h $
* $Id: types.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Some useful common type definition
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdbool.h> /* TRUE and FALSE definition */
#include <stdint.h>  /* Condensed integer type definition */

/* Local header files */

/* Constants */

#define PATH_MAX_LENGTH  256
#define STRING_MAX_LENGTH 64
#define STRING_UNDEFINED  ""

#ifndef IsUndefined
#define IsUndefined(string) (((string == NULL) || (strlen(string) == 0)) ? true : false)
#endif

typedef enum RetStatus {

  RetStatusSuccess = 0,
  RetStatusError,

} RetStatus_t;

#ifndef RET_STATUS
#define RET_STATUS     RetStatus_t
#define STATUS_SUCCESS RetStatusSuccess
#define STATUS_ERROR   RetStatusError
#endif

/* Type definition */

//typedef char string [STRING_MAX_LENGTH]; /* For backward compatibility purposes with SDN library - I.e. re-compiling SDN-based programs on CCSv5.1 */
typedef char charray [STRING_MAX_LENGTH]; /* For backward compatibility purposes with SDN library */
typedef unsigned int uint_t; /* Default length unsigned integer condensed type name */

/* Global variables */

/* Function declaration */

/* Function definition */

#endif /* TYPES_H */

