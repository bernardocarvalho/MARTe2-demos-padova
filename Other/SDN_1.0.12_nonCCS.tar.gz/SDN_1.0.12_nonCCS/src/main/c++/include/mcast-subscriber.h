#ifndef MCAST_SUBSCRIBER_H
#define MCAST_SUBSCRIBER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/mcast-subscriber.h $
* $Id: mcast-subscriber.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*                 CS 90 046
*                 13067 St. Paul-lez-Durance Cedex
*                 France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "mcast-participant.h"

/* Constants */

#define OBJTYPE_MCAST_SUBSCRIBER (char*) "sdn::mcast::Subscriber_Base"

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace mcast {

/* 
   Documentation - sdn::mcast::Subscriber_Impl::SetCallback() used in case Buffer and size defined using sdn::mcast::Participant::SetBuffer()
                   and in case of successful receive. This is meant to be useful for 1. the case where subscribers are being aggregated in a
                   composite class, and 2. in case of multirate messages.
 */

class Subscriber_Impl : public Participant_Impl /* Implementation class */
{

  private:

    volatile bool m_blocking;
    uint_t m_timeout;

    volatile bool m_updated; /* Buffer has been updated */

    /* Initializer methods */
    void Initialize (void) { this->m_blocking = false; this->m_timeout = 0; this->m_updated = false; return; };

  public:

    /* Initializer methods */

    /* Accessor methods */
    uint_t GetTimeout (void) { return this->m_timeout; };
    void SetTimeout (uint_t timeout) { this->m_blocking = true; this->m_timeout = timeout; return; };

    bool IsUpdated (void) { return __sync_val_compare_and_swap(&this->m_updated, true, true); }; /* Successful Receive */

    /* Miscellaneous methods */
    RET_STATUS Open (void);  /* Specializes virtual method */
    RET_STATUS Close (void); /* Specializes virtual method */

    RET_STATUS Receive (void* buffer, uint_t size, uint64_t timeout); /* Blocking wait with configurable timeout */
    RET_STATUS Receive (void* buffer, uint_t size);                   /* Blocking wait */

    RET_STATUS Receive (uint64_t timeout); /* Blocking wait with configurable timeout - Buffer and size defined using sdn::mcast::Participant::SetBuffer() */
    RET_STATUS Receive (void);             /* Blocking wait - Buffer and size defined using sdn::mcast::Participant::SetBuffer() */

    /* Constructor methods */
    Subscriber_Impl (void) { this->SetInstanceType(OBJTYPE_MCAST_SUBSCRIBER); /* Initialize attributes */ this->Initialize(); return; };
    Subscriber_Impl (const char* iface, const char* group, uint_t port) { this->SetInstanceType(OBJTYPE_MCAST_SUBSCRIBER); /* Initialize attributes */ this->Initialize(); this->SetInterface(iface); this->SetMCastGroup(group); this->SetMCastPort(port); /* Open and configure socket */ this->Open(); return; };

    /* Destructor method */
    virtual ~Subscriber_Impl (void) { /* Close socket */ this->Close(); return; }; /* Note - virtual destructor to ensure that sdn::core::Participant deleting this would call upon the appropriate destructor */

};

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace mcast */

}; /* namespace sdn */

using namespace sdn::mcast; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* MCAST_SUBSCRIBER_H */
