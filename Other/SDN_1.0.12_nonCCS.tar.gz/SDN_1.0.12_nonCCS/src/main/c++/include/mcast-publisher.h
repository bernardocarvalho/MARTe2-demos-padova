#ifndef MCAST_PUBLISHER_H
#define MCAST_PUBLISHER_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/mcast-publisher.h $
* $Id: mcast-publisher.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "sdn-base.h" /* Privately scoped base classes definition */

#include "mcast-participant.h"

/* Constants */

#define OBJTYPE_MCAST_PUBLISHER (char*) "sdn::mcast::Publisher_Base"

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace mcast {

class Publisher_Impl : public Participant_Impl /* Implementation class */
{

  private:

    /* Initializer methods */
    void Initialize (void) {};

  public:

    /* Initializer methods */

    /* Accessor methods */

    /* Miscellaneous methods */
    RET_STATUS Open (void);
    RET_STATUS Close (void);

    RET_STATUS Publish (void); /* Specializes virtual method */
    RET_STATUS Publish (void* buffer, uint_t size);

    /* Constructor methods */
    Publisher_Impl (void);
    Publisher_Impl (const char* iface, const char* group, uint_t port);

    /* Destructor method */
    virtual ~Publisher_Impl (void); /* Note - virtual destructor to ensure that sdn::core::Participant deleting this would call upon the appropriate destructor */

};

/* Global variables */

/* Function declaration */

/* Function definition */

}; /* namespace mcast */

}; /* namespace sdn */

using namespace sdn::mcast; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* MCAST_PUBLISHER_H */
