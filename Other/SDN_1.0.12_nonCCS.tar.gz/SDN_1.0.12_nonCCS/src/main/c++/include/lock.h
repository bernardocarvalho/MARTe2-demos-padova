#ifndef LOCK_H
#define LOCK_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/lock.h $
* $Id: lock.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Atomic lock class definition
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "types.h"
#include "tools.h"

/* Constants */

/* Type definition */

class AtomicLock 
{ 

  private:

    volatile bool m_lock; /* Locking flag used with atomic operations */

  protected:

  public:

    /* Initializer methods */

    /* Accessor methods */
    bool GetLock (void) { return this->m_lock; }; /* Test lock state */
	
    /* Miscellaneous methods */
    bool AcquireLock (void) { /* Take lock */ while (__sync_val_compare_and_swap(&(this->m_lock), false, true)); return true; };
    bool AcquireLock (uint64_t timeout) { bool lock = false; uint64_t till_time = get_time() + timeout; while (get_time() < till_time) { if ((lock = this->TryLock()) == true) break; } return lock; };
    bool ReleaseLock (void) { return __sync_val_compare_and_swap(&(this->m_lock), true, false); };
    bool TryLock (void) { return ((__sync_val_compare_and_swap(&(this->m_lock), false, true)) ? false : true); };

    /* Constructor methods */ 
    AtomicLock (void) { this->m_lock = false; return; };
    AtomicLock (bool lock) { this->m_lock = lock; return; };

    /* Destructor method */
   ~AtomicLock (void) { /* Take lock, or wait for lock to be released */ this->AcquireLock(); this->m_lock = false; return; };

};

/* Global variables */

/* Function declaration */

/* Function definition */

#endif /* LOCK_H */

