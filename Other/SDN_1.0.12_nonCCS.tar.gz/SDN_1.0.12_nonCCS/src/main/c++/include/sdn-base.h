#ifndef SDN_BASE_H
#define SDN_BASE_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-base.h $
* $Id: sdn-base.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*				  CS 90 046
*				  13067 St. Paul-lez-Durance Cedex
*				  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Documentation - This file is used to simplify the declaration of foundation classes for compiling the 
   SDN core library. It is not intended to be used by client applications, hence can not be included in
   public header files.
*/

/* Global header files */

/* Local header files */

#include "lu-table.h" /* LUTable template class definition */
#include "any-thread.h" /* Thread management class definition */
#include "any-type.h" /* Runtime datatype definition */
#include "buffer.h" /* Memory management template classes definition */
#include "statistics.h" /* Statistics template class definition */

#include "sdn-common.h" /* Common header file */

#include "any-object.h" /* Root object class definition */
#include "any-type-xml.h" /* Type introspection from XML file */

#include "base-participant.h" /* Interface definition common for sdn::mcast and sdn::ucast participants */
#include "base-publisher.h"   /* Interface definition common for sdn::mcast and sdn::ucast participants */
#include "base-subscriber.h"  /* Interface definition common for sdn::mcast and sdn::ucast participants */

/* Constants */

/* Type definition */

/* Global variables */

/* Function declaration */

/* Function definition */

#endif /* SDN_BASE_H */
