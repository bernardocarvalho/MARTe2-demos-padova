#ifndef STATISTICS_H
#define STATISTICS_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/statistics.h $
* $Id: statistics.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: Statistics computation classes
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <math.h>
#include <limits>

/* Local header files */

#include "types.h"
#include "tools.h"
#include "buffer.h"
#include "sqrti.h"

/* Constants */

#define DEFAULT_WINDOW_SIZE 1024

#define USE_MOVING_WINDOW
//#undef USE_MOVING_WINDOW

/* Type definition */

template <class Type> class Statistics {

  private:

    uint_t m_size;    /* Window size */
    uint_t m_counter; /* Number of samples */

    Type m_Xavg, m_Xdiv, m_Xmax, m_Xmin, m_Xrms, m_Xspl, m_Xstd, m_Xtmp;
#ifdef USE_MOVING_WINDOW
    CircularBuffer<Type>* m_X;   /* Sample buffer */
    CircularBuffer<Type>* m_Xsq; /* Sample buffer */
#endif
    /* Accessor methods */
    Type GetRmsSq (void);

    /* Miscellaneous methods */
    void SetDiv (void);
#ifdef USE_MOVING_WINDOW
    void FindMax (void);
    void FindMin (void);
#else
    void FindMax (void) {};
    void FindMin (void) {};
#endif
  protected:

  public:

    /* Initializer methods */
    void Reset ();

    /* Accessor methods */
    bool PushSample (Type sample);

    Type GetSample (uint_t index) {return this->m_X->GetData(index);};
    Type GetSample (void) { return this->m_Xspl; };
    uint_t GetSize (void) { return this->m_size; };
    Type GetAvg (void);
    Type GetMax (void) { return this->m_Xmax; };
    Type GetMin (void) { return this->m_Xmin; };
    Type GetRms (void);
    Type GetStd (void);
    Type GetSum (void);
    uint_t GetCounter (void) { return this->m_counter; };

    Type GetDiv (void); /* For test purposes */

    /* Miscellaneous methods */

    /* Constructor methods */
    Statistics ();
    Statistics (uint_t size);
    //Statistics (char* name);

    /* Destructor method */
   ~Statistics ();

};

/* Global variables */

/* Function declaration */

/* Function definition */

/* Initializer methods */

template <class Type> void Statistics<Type>::Reset (void)
{

  this->m_counter = 0;

  this->m_Xspl = (Type) 0;
  this->m_Xavg = (Type) 0;
  this->m_Xmax = (Type) std::numeric_limits<Type>::min();
  this->m_Xmin = (Type) std::numeric_limits<Type>::max();
  this->m_Xrms = (Type) 0;
  this->m_Xstd = (Type) 0;
  this->m_Xtmp = (Type) 0;
#ifdef USE_MOVING_WINDOW
  /* Reset sample buffers */
  (this->m_X)->Reset(); (this->m_Xsq)->Reset();
#endif
  return;

}

/* Accessor methods */

template <class Type> bool Statistics<Type>::PushSample (Type sample)
{

//  bool full = false;

  this->m_Xspl = sample;
  //wla -> increment m_counter if < m_size
  this->m_counter += ((this->m_counter < m_size) ? 1 : 0);
#ifdef USE_MOVING_WINDOW
  /* Update sample buffer */
  (this->m_X)->PushData(this->m_Xspl, this->m_Xtmp);

  /* Compute average */
  this->m_Xavg -= this->m_Xtmp; /* Remove oldest sample from the accumulator */
  this->m_Xavg += this->m_Xspl; /* Sum of all sample in time window */

  /* Update max/min, if necessary */
  if (this->m_Xspl > this->m_Xmax) this->m_Xmax = this->m_Xspl; 
  else if (this->m_Xtmp == this->m_Xmax) this->FindMax(); /* The removed sample was the max over the time window */

  if (this->m_Xspl < this->m_Xmin) m_Xmin = m_Xspl;
  else if (this->m_Xtmp == this->m_Xmin) this->FindMin(); /* The removed sample was the min over the time window */

  Type Xsq  = this->m_Xspl * this->m_Xspl; /* Square of the sample */

  /* Update sample buffer */
  (this->m_Xsq)->PushData(Xsq, this->m_Xtmp);

  /* Compute root mean square */
  this->m_Xrms -= this->m_Xtmp; /* Remove oldest sample from the accumulator */
  this->m_Xrms += Xsq;          /* Sum of squares of all samples in time window */
#else
  this->m_Xavg += this->m_Xspl;                /* Sum of all sample in time window */
  this->m_Xrms += this->m_Xspl * this->m_Xspl; /* Sum of squares of all samples in time window */
  if (this->m_Xspl > this->m_Xmax) this->m_Xmax = this->m_Xspl;
  if (this->m_Xspl < this->m_Xmin) this->m_Xmin = this->m_Xspl;
#endif
//  if (this->m_counter == this->m_size) /* Window fully refreshed */
//    {
//      this->m_counter = 0;
//      full = true;
//    }

  return (this->m_counter == this->m_size);

}

template <class Type> Type Statistics<Type>::GetAvg (void)
{

  Type Xavg = this->m_Xavg >> this->m_Xdiv;

  return Xavg;

}

template <> inline float Statistics<float>::GetAvg (void)
{
#if 0 // Warning - m_Xdiv is function of m_size - If the window is incompletely filled the avg will be wrong
  float Xavg = this->m_Xavg * this->m_Xdiv;
#else
  float Xavg = 0;

  if (this->m_counter > 0) 
    {
      Xavg = this->m_Xavg / this->m_counter;
    }
#endif
  return Xavg;

}

template <> inline double Statistics<double>::GetAvg (void)
{
#if 0 // Warning - m_Xdiv is function of m_size - If the window is incompletely filled the avg will be wrong
  double Xavg = this->m_Xavg * this->m_Xdiv;
#else
  double Xavg = 0;
  
  if (this->m_counter > 0) 
    {
      Xavg = this->m_Xavg / this->m_counter;
    }
#endif
  return Xavg;

}

template <class Type> Type Statistics<Type>::GetRmsSq (void)
{

  Type Xrms_sq = this->m_Xrms >> this->m_Xdiv;

  return Xrms_sq;

}

template <> inline float Statistics<float>::GetRmsSq (void)
{
#if 0 // Warning - m_Xdiv is function of m_size - If the window is incompletely filled the rms_sq will be wrong
  float Xrms_sq = this->m_Xrms * this->m_Xdiv;
#else
  float Xrms_sq = 0;
  
  if (this->m_counter > 0) 
    {
      Xrms_sq = this->m_Xrms / this->m_counter;
    }
#endif
  return Xrms_sq;

}

template <> inline double Statistics<double>::GetRmsSq (void)
{
#if 0 // Warning - m_Xdiv is function of m_size - If the window is incompletely filled the rms_sq will be wrong
  double Xrms_sq = this->m_Xrms * this->m_Xdiv;
#else
  double Xrms_sq = 0;

  if (this->m_counter > 0) 
    {
      Xrms_sq = this->m_Xrms / this->m_counter;
    }
#endif
  return Xrms_sq;

}

template <class Type> Type Statistics<Type>::GetRms (void)
{

  Type Xrms_sq = this->GetRmsSq();
  Type Xrms = sqrt(Xrms_sq);

  return Xrms;

}

template <class Type> Type Statistics<Type>::GetStd (void)
{

  Type Xavg = this->GetAvg();
  Type Xavg_sq = Xavg * Xavg;
  Type Xrms_sq = this->GetRmsSq();
  Type Xstd = sqrt(Xrms_sq - Xavg_sq);

  return Xstd;

}

template <class Type> Type Statistics<Type>::GetSum (void) { return this->m_Xavg; }
template <class Type> Type Statistics<Type>::GetDiv (void) { return this->m_Xdiv; }

/* Miscellaneous methods */

template <class Type> void Statistics<Type>::SetDiv (void)
{

  uint_t size = this->m_size;

  this->m_Xdiv = 0;

  while (size > 1)
    {
      size >>= 1;
      this->m_Xdiv += 1;
    }

  return;

}

template <> inline void Statistics<float>::SetDiv (void)
{

  this->m_Xdiv = 1.0 / (float) this->m_size; 

  return;

}

template <> inline void Statistics<double>::SetDiv (void)
{

  this->m_Xdiv = 1.0 / (double) this->m_size; 

  return;

}
#ifdef USE_MOVING_WINDOW
template <class Type> void Statistics<Type>::FindMax (void)
{

  uint_t index = 0;
  
  /* Reset maximum */
  (this->m_X)->GetData(this->m_Xmax, 0);
  
  for (index = 0; index < this->m_size; index += 1)
    {
      (this->m_X)->GetData(this->m_Xtmp, index);
      
      if (this->m_Xtmp > this->m_Xmax)
	{
	  this->m_Xmax = this->m_Xtmp;
	}
    }

  return;

}

template <class Type> void Statistics<Type>::FindMin (void)
{

  uint_t index = 0;

  /* Reset minimum */
  (this->m_X)->GetData(this->m_Xmin, 0);
  
  for (index = 0; index < this->m_size; index += 1)
    {
      (this->m_X)->GetData(this->m_Xtmp, index);
      
      if (this->m_Xtmp < this->m_Xmin)
	{
	  this->m_Xmin = this->m_Xtmp;
	}
    }

  return;

}
#endif
/* Constructor methods */

template <class Type> Statistics<Type>::Statistics ()
{

  this->m_size = DEFAULT_WINDOW_SIZE; this->SetDiv();
#ifdef USE_MOVING_WINDOW
  /* Instantiate sample buffers */
  this->m_X   = new CircularBuffer<Type> (this->m_size, (Type) 0); 
  this->m_Xsq = new CircularBuffer<Type> (this->m_size, (Type) 0); 
#endif
  this->Reset();

}

template <class Type> Statistics<Type>::Statistics (uint_t size)
{

  this->m_size = 1; while (size > 1) { size >>= 1; this->m_size <<= 1; }; this->SetDiv();
#ifdef USE_MOVING_WINDOW
  /* Instantiate sample buffers */
  this->m_X   = new CircularBuffer<Type> (this->m_size, (Type) 0); 
  this->m_Xsq = new CircularBuffer<Type> (this->m_size, (Type) 0); 
#endif
  this->Reset();

}

template <> inline Statistics<float>::Statistics (uint_t size)
{

  this->m_size = size; this->SetDiv();
#ifdef USE_MOVING_WINDOW
  /* Instantiate sample buffers */
  this->m_X   = new CircularBuffer<float> (this->m_size, (float) 0); 
  this->m_Xsq = new CircularBuffer<float> (this->m_size, (float) 0); 
#endif
  this->Reset();

}

template <> inline Statistics<double>::Statistics (uint_t size)
{

  this->m_size = size; this->SetDiv();
#ifdef USE_MOVING_WINDOW
  /* Instantiate sample buffers */
  this->m_X   = new CircularBuffer<double> (this->m_size, (double) 0); 
  this->m_Xsq = new CircularBuffer<double> (this->m_size, (double) 0); 
#endif
  this->Reset();

}

/* Destructor method */

template <class Type> Statistics<Type>::~Statistics ()
{
#ifdef USE_MOVING_WINDOW
  /* Delete sample buffers */
  delete this->m_X; delete this->m_Xsq;
#endif
}

#endif /* STATISTICS_H */

