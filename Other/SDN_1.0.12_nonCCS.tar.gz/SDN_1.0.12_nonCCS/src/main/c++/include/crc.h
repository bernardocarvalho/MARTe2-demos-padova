#ifndef CRC_H
#define CRC_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/crc.h $
* $Id: crc.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: CRC-32 function
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "types.h" /* Condensed integer type definition, RET_STATUS, etc. */

/* Constants */

/* Type definition */

/* Global variables */

static uint32_t __table [256];

static inline bool fill_crc_table (void)
{
   
  for (uint_t table_index = 0; table_index < 256; table_index += 1) 
    {
      uint32_t chksum  = (uint32_t) table_index;

      for (uint_t bit_index = 0; bit_index < 8; bit_index += 1) 
	{
	  if (chksum & 1) chksum = 0xedb88320L ^ (chksum >> 1);
	  else chksum = chksum >> 1;
	}

      __table[table_index] = chksum;
    }

  return true;

};

static bool __init_table = fill_crc_table(); 

/* Function declaration */

/* Function definition */

static inline uint32_t crc (uint8_t* buffer, uint_t size) 
{
  
  uint32_t chksum = 0xffffffffL;
#if 0
  if (__init_table != true) fill_crc_table();
#endif
  for (uint_t index = 0; index < size; index += 1) 
    {
      chksum = __table[(chksum ^ buffer[index]) & 0xff] ^ (chksum >> 8);
    }

  chksum = chksum ^ 0xffffffffL;
     
  return chksum;

};

#endif /* CRC_H */

