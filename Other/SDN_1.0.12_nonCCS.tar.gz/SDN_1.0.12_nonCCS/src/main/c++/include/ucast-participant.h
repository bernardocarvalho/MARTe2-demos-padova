#ifndef UCAST_PARTICIPANT_H
#define UCAST_PARTICIPANT_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/ucast-participant.h $
* $Id: ucast-participant.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*		  CS 90 046
*		  13067 St. Paul-lez-Durance Cedex
*		  France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>

/* Local header files */

#include "constants.h" /* Constants valid for this scope */
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

#include "sdn-base.h" /* Privately scoped case classes definition */

/* Constants */

#ifdef __cplusplus

/* Type definition */

namespace sdn {

namespace ucast {

class Participant_Impl : public base::AnyObject
{

  private:

    /* Initializer methods */
    void Initialize (void);

  public:

    void* m_buffer;
    uint_t m_size;

    char   m_ucast_addr [MAX_IP_ADDR_LENGTH];
    uint_t m_ucast_port;

    char m_if_addr [MAX_IP_ADDR_LENGTH];
    char m_if_name [MAX_IP_ADDR_LENGTH];

    int m_socket; /* Socket handle */

    void (* m_cb) (void*); /* Routine called as part of message handling */
    void* m_attr;          /* Routine attribute */

    /* Initializer methods */

    /* Accessor methods */
    const char* GetAddress (void) { return (const char*) this->m_if_addr; };
    const char* GetInterface (void) { return (const char*) this->m_if_name; };
    const char* GetUCastAddr (void) { return (const char*) this->m_ucast_addr; };
    uint_t GetUCastPort (void) { return this->m_ucast_port; };

    void SetInterface (const char* iface);
    void SetUCastAddr (const char* addr);
    void SetUCastPort (uint_t port);

    void* GetBuffer (void) { return this->m_buffer; };
    uint_t GetSize (void) { return this->m_size; };
    void SetBuffer (void* buffer, uint_t size);

    RET_STATUS SetCallback (void (* cb)(void*)) { this->m_cb = cb; return STATUS_SUCCESS; }; /* Routine called as part of message handling */
    RET_STATUS SetCallback (void (* cb)(void*), void* attr) { this->m_attr = attr; this->m_cb = cb; return STATUS_SUCCESS; }; /* Routine called as part of message handling */

    /* Miscellaneous methods */

    /* Constructor methods */
    Participant_Impl (void);

    /* Destructor method */
    virtual ~Participant_Impl (void); /* Note - virtual destructor to ensure that sdn::core::Participant deleting this would call upon the appropriate destructor */

};

/* Global variables */

/* Function declaration */

RET_STATUS Participant_Open (Participant_Impl* self); /* Common actions */
RET_STATUS Participant_Close (Participant_Impl* self); /* Common actions */

/* Function definition */

}; /* namespace ucast */

}; /* namespace sdn */

using namespace sdn::ucast; /* Allow for declaring intention only with including this header file */

extern "C" {

#endif /* __cplusplus */

/* ToDo - Insert C API declaration */

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* UCAST_PARTICIPANT_H */
