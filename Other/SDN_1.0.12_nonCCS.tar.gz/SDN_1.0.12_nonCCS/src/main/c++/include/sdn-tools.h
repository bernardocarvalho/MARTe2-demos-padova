#ifndef SDN_TOOLS_H
#define SDN_TOOLS_H

/******************************************************************************
* $HeadURL: https://svnpub.iter.org/codac/iter/codac/dev/units/m-sdn-core/branches/v1.0.12_nonCCS/src/main/c++/include/sdn-tools.h $
* $Id: sdn-tools.h 75157 2017-02-01 07:50:36Z bauvirb $
*
* Project	: CODAC Core System
*
* Description	: SDN - Infrastructure tools - Prototype
*
* Author        : Bertrand Bauvir
*
* Copyright (c) : 2010-2016 ITER Organization,
*                 CS 90 046
*                 13067 St. Paul-lez-Durance Cedex
*                 France
*
* This file is part of ITER CODAC software.
* For the terms and conditions of redistribution or use of this software
* refer to the file ITER-LICENSE.TXT located in the top level directory
* of the distribution package.
******************************************************************************/

/* Global header files */

/* Local header files */

#include "tools.h" /* Misc. helper functions, e.g. hash, etc. */
#include "base64.h" /* Misc. helper functions, e.g. base64 encoding, etc. */
#include "crc.h" /* Misc. helper functions, e.g. crc, etc. */
#include "log-api.h" /* Syslog wrapper routines */
#include "net-tools.h" /* Misc. network functions */

#include "constants.h"
#include "sdn-types.h" /* Misc. type definition, e.g. RET_STATUS */

/* Constants */

/* Type definition */

/* Global variables */

/* Function declaration */

/* Function definition */

static inline bool sdn_is_link_detected (void)
{

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  /* Try and retrieve interface identifier from environment */
  return ((get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name) != STATUS_SUCCESS) ? false : net_is_link_detected((char*) iface_name));

};

static inline RET_STATUS sdn_get_mac_address (char* iface_addr, uint_t max_size = STRING_MAX_LENGTH)
{

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  /* Try and retrieve interface identifier from environment */
  return ((get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name) != STATUS_SUCCESS) ? STATUS_ERROR : net_get_mac_address((char*) iface_name, iface_addr, max_size));

};

static inline RET_STATUS sdn_get_statistics (PortStatistics_t& iface_stats)
{

  char iface_name [STRING_MAX_LENGTH] = DEFAULT_IFACE_NAME;

  /* Try and retrieve interface identifier from environment */
  return ((get_env_variable((char*) "SDN_INTERFACE_NAME", (char*) iface_name) != STATUS_SUCCESS) ? STATUS_ERROR : net_get_statistics((char*) iface_name, iface_stats));
  
};

/* Bug 8722 - Test validity of SDN_INTERFACE_NAME */
static inline bool sdn_is_interface_valid (void)
{

  char iface_addr [STRING_MAX_LENGTH] = STRING_UNDEFINED;

  return ((sdn_get_mac_address((char*) iface_addr) != STATUS_SUCCESS) ? false : true);

};

static inline bool sdn_is_address_valid (const char* addr)
{

  bool valid = false;

  char buffer [MAX_IP_ADDR_LENGTH] = STRING_UNDEFINED; sstrncpy((char*) buffer, (char*) addr, MAX_IP_ADDR_LENGTH);

  /* IP address has the form A.B.C.D */
  char* a_str = NULL;
  char* b_str = NULL; 
  char* c_str = NULL;
  char* d_str = NULL;
  char* p_buf = NULL;
  uint_t a = 256;
  uint_t b = 256;
  uint_t c = 256;
  uint_t d = 256;

  a_str = (char*) buffer;
  p_buf = (char*) buffer;

  while (*p_buf != 0) 
    {
      if (*p_buf == '.') 
	{	
	  *p_buf = 0;

	  if (b_str == NULL) b_str = p_buf + 1;
	  else if (c_str == NULL) c_str = p_buf + 1;
	  else if (d_str == NULL) d_str = p_buf + 1;
	}

      /* Three '.' tokens found prior to meeting a ':' */
      if ((*p_buf == ':') && (a_str != NULL) && (b_str != NULL) && (c_str != NULL) && (d_str != NULL)) *p_buf = 0;

      p_buf += 1;
    }

  if ((a_str == NULL) || (b_str == NULL) || (c_str == NULL) || (d_str == NULL))
    {
      /* Wrong format */
      return valid;
    }

  sscanf(a_str, "%u", &a);
  sscanf(b_str, "%u", &b);
  sscanf(c_str, "%u", &c);
  sscanf(d_str, "%u", &d);
#if 0
  if ((a > 255) || (b > 255) || (c > 255) || (d > 255))
#else
  if ((a > 239) || (b > 255) || (c > 255) || (d > 255))
#endif
    {
      /* Wrong format */
      return valid;
    }

  valid = true;

  return valid;

};

static inline bool sdn_is_mcast_address (const char* addr)
{

  bool mcast = false;

  if (sdn_is_address_valid(addr) == true)
    {

      char buffer [MAX_IP_ADDR_LENGTH] = STRING_UNDEFINED; sstrncpy((char*) buffer, (char*) addr, MAX_IP_ADDR_LENGTH);
      char* a_str = (char*) buffer;
      char* p_buf = (char*) buffer;

      while (*p_buf != 0) 
	{
	  if (*p_buf == '.') 
	    {
	      *p_buf = 0; break;
	    }
	  
	  p_buf += 1;
	}

      uint_t a = 0; sscanf(a_str, "%d", &a);

      if ((a >= 224) && (a <= 239)) mcast = true;

    }

  return mcast;

};

static inline bool sdn_is_ucast_address (const char* addr)
{

  bool ucast = false;

  if (sdn_is_address_valid(addr) == true)
    {

      char buffer [MAX_IP_ADDR_LENGTH] = STRING_UNDEFINED; sstrncpy((char*) buffer, (char*) addr, MAX_IP_ADDR_LENGTH);
      char* a_str = (char*) buffer;
      char* p_buf = (char*) buffer;

      while (*p_buf != 0) 
	{
	  if (*p_buf == '.') 
	    {
	      *p_buf = 0; break;
	    }
	  
	  p_buf += 1;
	}

      uint_t a = 0; sscanf(a_str, "%d", &a);

      if (a < 224) ucast = true;

    }

  return ucast;

};

#endif /* SDN_TOOLS_H */
